from pathlib import Path
import json,re,yaml
H=Path('dev_docs/agents/box_code_adoption_batch_35');rows=[]
def record(path,ids,edit):
 p=Path(path);before=p.read_text();after=edit(before);assert before!=after;p.write_text(after);rows.append(dict(path=path,findings=ids,before=before,after=after))
def sweeps(s):
 pattern=r'(fun column\(label: String, s: Settings\): Pair<String, Img> \{\n    val c = canvas\(\)\n)(.*?)(\n\}\n\n// the same columns)'
 def wrap(m):
  b=m[2];assert 'return label to imgFromBytes(png).also { c.close() }' in b
  b=b.replace('return label to imgFromBytes(png).also { c.close() }','return label to imgFromBytes(png)')
  return m[1]+'    try {\n'+''.join('    '+x+'\n' for x in b.splitlines()).rstrip('\n')+'\n    } finally {\n        c.close()\n    }'+m[3]
 s,n=re.subn(pattern,wrap,s,flags=re.S);assert n==26,n
 a='FLine().moveTo(560, 1330).apply { for (i in 0 until 5) lineTo(if (i % 2 == 0) 380.0 else 640.0, 1375.0 + 45 * i) }'
 b='FLine().moveTo(560, 1330).apply {\n    for (i in 0 until 5) {\n        lineTo(if (i % 2 == 0) 380.0 else 640.0, 1375.0 + 45 * i)\n    }\n}'
 assert s.count(a)==26;s=s.replace(a,b)
 return s
record('public/docs/paint_sweeps.md',['170fca19e6cf-01','170fca19e6cf-02'],sweeps)
def solids(s):
 a='fun mesh(e: SolidExpr) = e.buildSolid(q).let { b ->\n    val m = b.solid.toTriMesh(normals = true); b.close(); m\n}'
 b='// toTriMesh copies the geometry before the native build closes.\nfun mesh(e: SolidExpr) = e.buildSolid(q).use { build ->\n    build.solid.toTriMesh(normals = true)\n}'
 assert s.count(a)==1;s=s.replace(a,b)
 a='val build = part.buildSolid(q)\n';i=s.index(a);j=s.index('build.close()',i)
 body=s[i+len(a):j];s=s[:i]+'part.buildSolid(q).use { build ->\n'+''.join('    '+x+'\n' if x else '\n' for x in body.rstrip().splitlines())+'}'+s[j+len('build.close()'):]
 a='val build = (plate + smoothUnion(ball, post, k = 0.28)).buildSolid()\nprintln(build.report())'
 b='(plate + smoothUnion(ball, post, k = 0.28)).buildSolid().use { build ->\n    println(build.report())\n}'
 assert s.count(a)==1;return s.replace(a,b)
record('public/docs/solid_notation.md',['ee7c97ec6dcf-01'],solids)
def gesture(s):
 a='val canvases = ways.map { (_, samples) ->';i=s.index(a);j=s.index('markdown("ways",',i)
 old=s[i:j];new=old.replace(a,'val canvases = mutableListOf<PaintCanvas>()\ntry {\nways.forEach { (_, samples) ->').replace('.also { c ->\n        c.stroke(','.also { c ->\n        canvases += c\n        c.stroke(')
 assert 'canvases += c' in new
 new=new.replace('canvases.forEach { it.close() }','} finally {\n    canvases.forEach { it.close() }\n}')
 return s[:i]+new+s[j:]
# Preserve YAML graph/foreign values; replace only the affected block scalar.
p='dev_docs/agents/transcripts/gesture_paint_replay.yaml';before=Path(p).read_text();node=yaml.compose(before);ed=[]
def walk(n):
 if isinstance(n,yaml.MappingNode):
  for k,v in n.value:
   if k.value=='code' and isinstance(v,yaml.ScalarNode) and 'val canvases = ways.map' in v.value:
    code=gesture(v.value);indent=k.start_mark.column+2;ed.append((v.start_mark.index,v.end_mark.index,'|\n'+''.join(' '*indent+x+'\n' if x else '\n' for x in code.rstrip().splitlines())))
   else:walk(v)
 elif isinstance(n,yaml.SequenceNode):
  for v in n.value:walk(v)
walk(node);assert len(ed)==1
a,b,v=ed[0];after=before[:a]+v+before[b:];Path(p).write_text(after);rows.append(dict(path=p,findings=['1bc3ed402106-01'],before=before,after=after))
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(H.parent/'box_code_adoption_batch_33'/name).read_text().replace('adoption-33','adoption-35').replace('ac1bd079c','a4344fc66');(H/name).write_text(s)
