val target = template.withValues(doubleArrayOf(0.45, 1.90, 0.16)).sampleField(count = 2400, seed = 91)
val fit = template.fitParameters(target, start = doubleArrayOf(0.26, 1.05, 0.34))

fit.report()

/*
fit 3 parameter(s) in 14 iterations (gradient)
  sphereRadius       0.260000  ->      0.450000
  barHeight          1.050000  ->      1.900000
  barRadius          0.340000  ->      0.160000
  loss           2.140904e-02  ->  4.609346e-22
  improvement    4.645e+19x
*/

fit.fitted // an ordinary SolidExpr again: marchable, GLSL-able, printable
