val part = smoothUnion(sphere(0.45), cylinder(1.90, 0.16), k = 0.18)

part.numericSlots()

/*
SmoothUnion/a/Sphere.radius = 0.45
SmoothUnion/b/Cylinder.height = 1.9
SmoothUnion/b/Cylinder.radiusLow = 0.16
SmoothUnion/b/Cylinder.radiusHigh = 0.16
SmoothUnion.k = 0.18
*/

val template =
    part
        .parameterize {
            param("sphereRadius", "SmoothUnion/a/Sphere.radius")
            param("barHeight", "SmoothUnion/b/Cylinder.height")
            param("barRadius") { it.node == "Cylinder" && it.field.startsWith("radius") } // both, tied
        }
        .orThrow()

template.gradientAt(0.9, 0.0, 0.0, template.seed)

// value 0.450000  dPos 1.000, 0.000, 0.000  dParam -1.000, 0.000, 0.000
