/* BOX_CODE_FOLD_0 */
// what every column starts from: the black of the Elegy above
data class Settings(
    val stiffness: Double = 0.5,
    val ragged: Double = 0.5,
    val splay: Double = 0.0,
    val lay: Double = 0.8,
    val run: Double = 1100.0,
    val pickup: Double? = null,
    val push: Double? = null,
    val hairs: Int = 48,
    val bristles: Int? = null,
    val stiff: Double = 0.5,
    val thinner: Double = 0.0,
    val oil: Double = 1.5,
    val amount: Double = 0.5,
    val hiding: Double = 0.65,
    val tilt: Double = 30.0,
    val faster: Double = 1.0,
    val facets: Double? = null,
    val moving: Boolean = true,
    val width: Double = 200.0,
    val hair: Double? = null,
    val cohesion: Double? = null,
    val clumping: Double? = null,
    val splayFan: Double? = null,
    val splayScatter: Double? = null,
    val drying: Double = 1.0,
    val absorbent: Double = 0.0,
    val lamp: Boolean = false,
    val wipeAfter: Double? = null,
    val dry: Boolean = false,
)

// A canvas 50 cm wide and 1.25 m tall; the default brush is 10 cm wide.
fun canvas() = PaintCanvas(300, aspect = 0.4, groundColor = rgb(0.93, 0.9, 0.83), sizeMm = 500.0, seed = 7)
val straight = FLine().moveTo(500, 120).lineTo(510, 900)
val loop = FLine().moveTo(510, 900).apply {
    for (i in 1..480) {
        val a = PI / 2 + 2 * PI * 1.15 * i / 480
        lineTo(510 + 190 * cos(a), 1090 - 190 * sin(a))
    }
}
val scrub = FLine().moveTo(560, 1330).apply {
    for (i in 0 until 5) {
        lineTo(if (i % 2 == 0) 380.0 else 640.0, 1375.0 + 45 * i)
    }
}
val last =
    [1600.0, 1800.0, 2000.0, 2200.0, 2400.0].zipWithNext().mapIndexed { k, (y0, y1) ->
        FLine().moveTo(500.0 + 4 * k, y0).lineTo(504.0 + 4 * k, y1)
    }

// a long straight, a loop that crosses itself, a scrub back and forth, and a last straight in four
// pieces, each faster and lighter: 100, 200, 350, then 600 mm/s, lifting off the canvas at the end
fun gesture(c: PaintCanvas, s: Settings): TimedGesture {
    fun part(line: FLine, speed: Double, vararg pressure: Double) =
        c.gesture(line, speed = speed, pressure = pressure.toList(), tilt = s.tilt, facets = s.facets)
    var g =
        part(straight, 250.0, 0.8, 1.0, 1.0).then(part(loop, 250.0, 1.0, 0.9)).pause(0.1).then(part(scrub, 300.0, 1.1))
    val press = [1.0, 0.8, 0.6, 0.3, -0.2]
    for ((k, speed) in [100.0, 200.0, 350.0, 600.0].withIndex()) g =
        g.then(part(last[k], speed, press[k], press[k + 1]))
    return g.faster(s.faster)
}

fun column(label: String, s: Settings): Pair<String, Img> {
    val c = canvas()
    try {
        if (s.absorbent > 0.0) c.prime(rgb(0.93, 0.9, 0.83), texture = 0.0, absorbent = s.absorbent)
        val config = BrushConfig(
            bristles = s.bristles,
            hair = s.hair,
            stiffness = s.stiffness,
            ragged = s.ragged,
            splay = s.splay,
            lay = s.lay,
            run = s.run,
            pickup = s.pickup,
            push = s.push,
        )
        val black = rgb(0.05, 0.045, 0.04)
        if (s.moving) {
            val brush =
                c.dynamicBrush(BrushKind.HogFlat, s.width, hairs = s.hairs, segments = 6, config = config)
                    .load(
                        black,
                        hiding = s.hiding,
                        stiff = s.stiff,
                        drying = s.drying,
                        thinner = s.thinner,
                        oil = s.oil,
                        amount = s.amount,
                    )
            brush.set(
                cohesion = s.cohesion,
                clumping = s.clumping,
                splayFan = s.splayFan,
                splayScatter = s.splayScatter,
            )
            c.stroke(gesture(c, s), brush)
        } else {
            // an ordinary brush along the same path, with the same pressures; it has no timing or tilt
            val brush =
                c.brush(BrushKind.HogFlat, s.width, config = config)
                    .load(
                        black,
                        hiding = s.hiding,
                        stiff = s.stiff,
                        drying = s.drying,
                        thinner = s.thinner,
                        oil = s.oil,
                        amount = s.amount,
                    )
            c.stroke(straight, brush, pressure = 0.8..1.0)
            c.stroke(loop, brush, pressure = 1.0..0.9)
            c.stroke(scrub, brush, pressure = 1.1..1.1)
            c.stroke(FLine().moveTo(500, 1600).lineTo(516, 2400), brush, pressure = 1.0..0.0)
        }
        // a rag wiped across the bar, the loop and the last stroke after some minutes (infinite: dry first)
        s.wipeAfter?.let { minutes ->
            if (minutes.isInfinite()) c.dry() else c.wait(minutes)
            val rag = c.rag(150.0)
            for (y in [500.0, 1090.0, 2000.0]) c.wipe(FLine().moveTo(250, y).lineTo(760, y + 10), rag, [0.8])
        }
        if (s.dry) c.dry()
        val png = if (s.lamp) c.png(relief = 0.3, light = PaintLight.Gallery) else c.png(relief = 0.3)
        return label to imgFromBytes(png)
    } finally {
        c.close()
    }
}

// the same columns twice: a row with moving hairs above a row with an ordinary brush
fun rows(cells: (moving: Boolean) -> List<Pair<String, Img>>): Img {
    val rows =
        ["moving hairs" to true, "ordinary brush" to false].map { (name, moving) ->
            val strokes = cells(moving)
            name to montage(strokes, columns = strokes.size, cellSide = 750, textScale = 3)
        }
    return montage(rows, columns = 1, cellSide = 4000, textScale = 3)
}
/* BOX_CODE_FOLD_1 */
val strokes = [null, 200.0, 60.0, 20.0, 6.0, 2.0].map {
    column(if (it == null) "smooth" else "facets ${it.toInt()}", Settings(facets = it))
}
val sheet = montage(strokes, columns = strokes.size, cellSide = 750, textScale = 3)
showImg(sheet)
sheet.savePng("/tmp/field-docs-paint-sweep-facets.png")
