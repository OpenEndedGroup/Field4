typealias ScalarField3D = (Vec3) -> Float
