(plate + smoothUnion(ball, post, k = 0.28)).buildSolid().use { build ->
    println(build.report())
}

// hybrid: 1 subtree(s) marched, the rest exact (39552 triangles, genus 4)
//   marched SmoothUnion at edgeLength 0.0416 — a smooth blend's fillet surface lies on neither operand…
