val emitted = scene.toGlsl() // GlslSolid(sdSolid, 174 statements, stepScale 0.4, 2 notes)
println(scene.toRaymarchFragment()) // sphere tracing, a normal, two lights, ready to paste
