import afield.lang.solidsl.*

// Three lobes on the X axis with independent radii.
val template =
    smoothUnion(
            smoothUnion(sphere(0.50), sphere(0.35).at(-0.80, 0.0, 0.0), 0.25),
            sphere(0.42).at(0.80, 0.0, 0.0),
            0.25,
        )
        .parameterize {
            param("middle", "SmoothUnion/a/SmoothUnion/a/Sphere.radius")
            param("left", "SmoothUnion/a/SmoothUnion/b/Translate/Sphere.radius")
            param("right", "SmoothUnion/b/Translate/Sphere.radius")
        }
        .orThrow()

val truth = doubleArrayOf(0.50, 0.35, 0.42)
val seed = doubleArrayOf(0.30, 0.56, 0.20)

// The view from one side: everything right of x = 0.10 is never seen.
val cloud = template.withValues(truth).samplePointCloud(count = 4000, seed = 4).filter { x, _, _ -> x < 0.10 }

// Before the descent: zero iterations, so this is only the gradient at the seed.
val before = template.fitToPointCloud(cloud, seed, SolidFitOptions(iterations = 0))
println("before any step, unconstrained: ${before.unconstrainedParameters}")

val fit = template.fitToPointCloud(cloud, seed)
println(fit.report())

// Each cloud point drawn as a tiny octahedron, so the cloud can sit in a mesh panel.
fun dots(c: SolidPointCloud, r: Float = 0.014f): TriMesh {
    val pos = FloatArray(c.size * 18)
    val faces = intArrayOf(0, 2, 4, 2, 1, 4, 1, 3, 4, 3, 0, 4, 2, 0, 5, 1, 2, 5, 3, 1, 5, 0, 3, 5)
    val idx = IntArray(c.size * 24)
    for (i in 0 until c.size) {
        val x = c.xs[i].toFloat()
        val y = c.ys[i].toFloat()
        val z = c.zs[i].toFloat()
        floatArrayOf(x + r, y, z, x - r, y, z, x, y + r, z, x, y - r, z, x, y, z + r, x, y, z - r).copyInto(pos, i * 18)
        for (k in faces.indices) idx[i * 24 + k] = i * 6 + faces[k]
    }
    return TriMesh(pos, idx)
}

val right = template.names.indexOf("right")
fun m(e: SolidExpr) = e.march(resolution = 96, margin = 0.05)
threeGrid(
    "the cloud  ·  ${cloud.size} points, x < 0.10" to dots(cloud),
    "seed  ·  right = %.2f".format(seed[right]) to m(template.withValues(seed)),
    "fitted  ·  right = %.6f".format(fit.values[right]) to m(fit.fitted),
    "truth  ·  right = %.2f".format(truth[right]) to m(template.withValues(truth)),
    channel = "one_sided",
    columns = 4,
    height = 230,
    view =
        MeshView(width = 250, height = 190, yawDegrees = 0.0, pitchDegrees = 30.0, distance = 3.6, wireframe = false),
    padding = 1.41,
)
