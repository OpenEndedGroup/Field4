import afield.lang.solidsl.*

val truth = sphere(0.62) + cylinder(2.20, 0.28)
val target = truth.sampleField(count = 3000, seed = 17)

val model =
    (cuboid(1.0) + cylinder(1.0, 1.0).turned(y = 1.0))
        .parameterize {
            param("cubeSize") { it.node == "Cuboid" }
            param("barHeight") { it.node == "Cylinder" && it.field == "height" }
            param("barRadius") { it.node == "Cylinder" && it.field.startsWith("radius") }
            param("barTilt") { it.node == "Rotate" && it.field == "y" }
        }
        .orThrow()

val fit = model.fitParameters(
    target,
    doubleArrayOf(1.35, 1.60, 0.42, 25.0),
    SolidFitOptions(method = OptimizeMethod.ADAM, iterations = 6000, learningRate = 0.015),
)

/*
`run.trajectory` is the parameter vector at every recorded iteration, indexed exactly like
`run.losses`. `shapeAt` substitutes one back into the template, so these are the shapes the
optimizer really held -- not six descents truncated at six different caps.
*/
val frames = [0, 150, 500, 1200, 2400, fit.run.trajectory.lastIndex]
val tilt = model.names.indexOf("barTilt")

threeGrid(
    *frames
        .map { i ->
            "iter %d  ·  tilt %.1f deg  ·  loss %.2e".format(i, fit.run.trajectory[i][tilt], fit.run.losses[i]) to
                fit.shapeAt(i).march(resolution = 88, margin = 0.06)
        }
        .toTypedArray(),
    channel = "converging",
    columns = 6,
    height = 210,
    view = MeshView(width = 190, height = 170, yawDegrees = 32.0, pitchDegrees = 22.0, wireframe = true),
)
