import afield.lang.solidsl.*

// A sphere and a cylinder. The model below gets a CUBE and a cylinder.
val truth = sphere(0.62) + cylinder(2.20, 0.28)
val target = truth.sampleField(count = 3000, seed = 17)

val model =
    (cuboid(1.0) + cylinder(1.0, 1.0).turned(y = 1.0))
        .parameterize {
            param("cubeSize") { it.node == "Cuboid" }
            param("barHeight") { it.node == "Cylinder" && it.field == "height" }
            param("barRadius") { it.node == "Cylinder" && it.field.startsWith("radius") }
            param("barTilt") { it.node == "Rotate" && it.field == "y" }
        }
        .orThrow()

val seed = doubleArrayOf(1.35, 1.60, 0.42, 25.0)
val fit = model.fitParameters(
    target,
    seed,
    SolidFitOptions(method = OptimizeMethod.ADAM, iterations = 6000, learningRate = 0.015),
)
println(fit.report())

/*
`margin` is not decoration here. `march`'s window defaults to the shape's OWN bounding box, and
a cuboid's faces lie exactly ON that boundary — the outermost grid samples sit at the zero
crossing, the side faces never close, and the cube renders as a flat sheet. A sphere only touches
its box tangentially, at six points, which is why the fit above gets away with the default.
*/
fun m(e: SolidExpr) = e.march(resolution = 104, margin = 0.06)
threeGrid(
    "model at the seed  ·  loss %.3e".format(fit.initialLoss) to m(model.withValues(seed)),
    "fitted  ·  loss %.3e  (%.1fx)".format(fit.loss, fit.improvementFactor) to m(fit.fitted),
    "target  ·  a SPHERE and a cylinder" to m(truth),
    channel = "partial",
    columns = 3,
    height = 300,
    view = MeshView(width = 320, height = 250, yawDegrees = 32.0, pitchDegrees = 22.0, wireframe = true),
)
