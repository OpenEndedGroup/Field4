import afield.lang.solidsl.*

val q = SolidQuality(segments = 96, edgeLengthFraction = 1.0 / 80.0)

val plate = cuboid(3.2, 2.2, 0.42)
val bores = unionOf(
    [-1.1 to -0.7, 1.1 to -0.7, -1.1 to 0.7, 1.1 to 0.7].map { (x, y) ->
        cylinder(2.0, 0.30, segments = 96).at(x, y, 0.0)
    },
)
val boss = smoothUnion(
    sphere(0.42, segments = 96).at(0.0, 0.0, 0.62),
    cylinder(1.1, 0.26, segments = 96).at(0.0, 0.0, 0.30),
    k = 0.22,
)
val part = (plate - bores) + boss

part.buildSolid(q).use { build ->
    println(build.report())
    val naive = part.marchedMesh(q)
    println("hybrid ${build.solid.triangleCount} triangles, naive ${naive.triangleCount}")

    threeGrid(
        "buildSolid — exact plate, marched boss" to build.solid.toTriMesh(normals = true),
        "marchedMesh — everything approximated" to naive,
        channel = "hybrid",
        columns = 2,
        height = 360,
        view = MeshView(width = 360, height = 300, yawDegrees = 34.0, pitchDegrees = 24.0, wireframe = true),
    )
}
