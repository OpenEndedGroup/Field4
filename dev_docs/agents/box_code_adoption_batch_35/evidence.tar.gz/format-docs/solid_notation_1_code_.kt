val part =
    (cuboid(4, 2.6, 0.7) + cylinder(1.4, 0.8)) -
        cylinder(3.0, 0.42) -
        Profile.rect(2.9, 0.85).offset(0.22).extruded(3.0).at(0, 1.05, -1.5)

part.toScalarField() // (Vec3) -> Float — marchable, and everything mesh_sdf.kt does
part.exactSolid() // Manifold's exact CSG — a guaranteed-closed Solid, or a stated refusal
part.toGlsl() // float sdSolid(vec3 p) — a real-time raymarch of the same source
part.simplified() // a smaller expression that means the same thing
println(part) // Difference(children=[Union(children=[Cuboid(x=4.0, …
