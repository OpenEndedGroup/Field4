val truth = sphere(0.62) + cylinder(2.20, 0.28)
val target = truth.sampleField(count = 3000, seed = 17)

val model =
    (cuboid(1.0) + cylinder(1.0, 1.0).turned(y = 1.0))
        .parameterize {
            param("cubeSize") { it.node == "Cuboid" } // one number, all three extents
            param("barHeight") { it.node == "Cylinder" && it.field == "height" }
            param("barRadius") { it.node == "Cylinder" && it.field.startsWith("radius") }
            param("barTilt") { it.node == "Rotate" && it.field == "y" } // an ANGLE, in degrees
        }
        .orThrow()

val fit = model.fitParameters(
    target,
    start = doubleArrayOf(1.35, 1.60, 0.42, 25.0),
    SolidFitOptions(method = OptimizeMethod.ADAM, iterations = 6000, learningRate = 0.015),
)

fit.report()

/*
fit 4 parameter(s) in 4176 iterations (gradient)
  cubeSize           1.350000  ->      0.855279
  barHeight          1.600000  ->      2.197225
  barRadius          0.420000  ->      0.281335
  barTilt           25.000000  ->     -0.009525
  loss           7.044887e-02  ->  3.766267e-03
  rms distance   2.654221e-01  ->  6.136992e-02
  improvement    18.71x
*/
