println(smoothUnion(a, b, k = 0.0).simplificationReport())

// nodes 3 -> 1, GLSL 19 -> 10 statements, path level set -> exact
