val imagePath: String? = "public/docs/assets/opendlssnr/ink-input.png"
