import afield.graphics.render.neural.OpenDlssNrStudy

val study = OpenDlssNrStudy(renderer, imagePath = "public/docs/assets/opendlssnr/ink-input.png")
study.animate = false
frames {
    try {
        while (true) frame()
    } finally {
        study.close()
    }
}
