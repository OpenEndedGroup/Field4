import afield.graphics.render.neural.*

val pass = OpenDlssNrPass(renderer, width, height)
pass.controls = OpenDlssNrControls(style = 1, tone = 0f, structure = 10f)
// Inside Target.render(command, index), after rendering color:
pass.evaluate(
    command,
    OpenDlssNrInputs(color, OpenDlssNrColorEncoding.LINEAR_LDR),
    OpenDlssNrFrame(frameIndex),
)

// pass.output is a sampled linear RGBA16F texture. Close the pass when its owner stops.
