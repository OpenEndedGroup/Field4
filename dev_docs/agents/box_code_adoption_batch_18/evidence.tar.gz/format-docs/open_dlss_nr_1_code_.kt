// The complete raster study below, launched by open_dlss_nr_cubes.yaml.
