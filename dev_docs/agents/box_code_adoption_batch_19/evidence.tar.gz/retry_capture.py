import sys,asyncio,json,yaml
from pathlib import Path
sys.path.insert(0,str(Path('dev_docs/agents/box_code_adoption_batch_19').resolve()))
import cpu_checks as c
async def main():
 code=yaml.safe_load((c.m.OUT/'capture_order.yaml').read_text())['operations'][0]['create']['properties']['code'].replace('import org.joml.Matrix4f','import afield.math.linalg.Matrix4f')
 await c.m.program('capture_order',code)
 records=[{'resetWait':mode,'actualAuthoredWait':True,'deadlineSecondsForTest':0.05} for mode in ['complete','failure','timeout']]
 for mode in ['complete','failure','timeout']:assert json.loads((c.m.OUT/('reset_'+mode+'_assert.json')).read_text())['ok']
 records.append({'captureOrder':'initial/consecutive/gap','cameraAndObjectValidityVerified':True})
 (c.m.OUT/'verification.json').write_text(json.dumps(records,indent=2)+'\n')
asyncio.run(main())
