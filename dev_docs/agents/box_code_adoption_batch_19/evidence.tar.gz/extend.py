from pathlib import Path
import json,re,yaml
H=Path('dev_docs/agents/box_code_adoption_batch_19');rows=json.loads((H/'changes.json').read_text())
r=next(r for r in rows if r['path'].endswith('flow_grain.yaml'));p=Path(r['path']);s=p.read_text()
a=s.index('    vec4 old = pc.source.v[id*2];');b=s.index('    vec2 velocity = flowVelocity(p)',a)
new='''    vec4 old = pc.source.v[id * 2];
    vec4 smoothVelocity = pc.source.v[id * 2 + 1];
    int generation = pc.tiles.v[slot].z;
    vec2 lower = vec2(pc.tiles.v[slot].xy) * TILE;
    vec2 p = old.xy;
    bool staleGeneration = floatBitsToInt(old.w) != generation;
    bool outsideTile = any(lessThan(p, lower)) || any(greaterThanEqual(p, lower + TILE));
    // Relocation invalidates both the old position and its smoothed velocity.
    if (staleGeneration || outsideTile) {
        vec2 randomInTile = vec2(
            flowRandom(ivec2(id % 640, pc.tiles.v[slot].x), pc.tiles.v[slot].y),
            flowRandom(ivec2(id % 640 + 9923, pc.tiles.v[slot].x), pc.tiles.v[slot].y)
        );
        p = lower + randomInTile * TILE;
        smoothVelocity = vec4(0);
    }
'''
# Restore the scalar indentation when replacing the de-indented shader excerpt.
indent=s[s.rfind('\n',0,a)+1:a];new='\n'.join(indent+line if i else line for i,line in enumerate(new.rstrip('\n').splitlines()))+'\n'+indent
s=s[:a]+new+s[b:];s=s.replace('pc.target.v[id*2]', 'pc.target.v[id * 2]').replace('pc.target.v[id*2+1]', 'pc.target.v[id * 2 + 1]')
# Preserve reviewed semantic edits while taking formatting from the first real formatter pass.
r['after']=s;p.write_text(s)
p=Path('dev_docs/agents/transcripts/threebox.yaml');before=p.read_text();s=before
s=s.replace('              float something;','              float something;\n              uint particleCount;')
a=s.index('              uint idx = gl_GlobalInvocationID.x;');b=s.index('              fieldProbe(length(delta));',a)
new='''              uint idx = gl_GlobalInvocationID.x;
              if (idx >= pc.particleCount) return;
              vec4 seed = pc.inData.a[idx]; // xy position, zw modulation and size.
              float phaseZ = pc.something * seed.z;
              float phaseW = pc.something * seed.w;
              // The y cosine alone uses the slow phase.
              float slowPhaseZ = phaseZ * 0.03;
              vec2 moved = vec2(
                  seed.x * cos(phaseZ) + seed.y * sin(phaseW),
                  -seed.x * sin(phaseW) + seed.y * cos(slowPhaseZ)
              );
              pc.outData.a[idx] = vec4(moved, seed.zw);
              vec2 delta = moved - seed.xy;
''';s=s[:a]+new+s[b:]
s=s.replace('          m.outData = { outData }','          m.outData = { outData }\n          m.particleCount = { N }').replace('m.x = N / 64;','m.x = (N + 63) / 64;')
# Space the quad table without changing its six corners or their order.
s=s.replace('vec2(-1,-1),vec2(1,-1),vec2(1,1),vec2(-1,-1),vec2(1,1),vec2(-1,1)','vec2(-1, -1), vec2(1, -1), vec2(1, 1),\n              vec2(-1, -1), vec2(1, 1), vec2(-1, 1)')
rows.append({'path':str(p),'before':before,'after':s,'findingIds':['e8c0554946df-01','e8c0554946df-02']});p.write_text(s)
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
