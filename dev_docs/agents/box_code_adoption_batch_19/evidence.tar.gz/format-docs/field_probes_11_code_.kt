// Requires the matching compute property above and an inherited renderer.
val N = 16384

val stats = fieldStatsHere(channels = 1)

val positions = defaultBuffer { size = N.vec4s }.buffer
val velocities = defaultBuffer { size = N.vec4s }.buffer
positions.write {
    for (i in 0 until N) {
        val a = Math.random() * Math.PI * 2.0
        val r = 0.15 + 0.75 * Math.random()
        put(vec(Math.cos(a) * r, Math.sin(a) * r, 0.0, 1.0))
    }
}
velocities.write { for (i in 0 until N) put(vec(0.0, 0.0, 0.0, 0.0)) }

val compute = computeModuleHere {}
val step = ComputeMesh()
compute += "step" to step
renderer += "compute" to compute
// Reflected push-constant members resolve once the mesh is attached to its module.
step.positions = { positions }
step.velocities = { velocities }
step.dt = { 0.016f }
step.particleCount = { N }
step.x = (N + 63) / 64
step.y = 1
step.z = 1

// show the GPU-computed aggregates as a small table
frames {
    while (true) {
        stats.latest(0)?.let { s ->
            /* BOX_CODE_FOLD_0 */
            markdown(
                "stats",
                """
                #### speed — channel 0 (GPU)

                | n | mean | σ | min | median | max |
                |---|------|---|-----|--------|-----|
                | ${s.finiteCount} | ${"%.4f".format(s.mean)} | ${"%.4f".format(s.standardDeviation)} | ${"%.4f".format(s.min)} | ${"%.4f".format(s.quantile(0.5))} | ${"%.4f".format(s.max)} |
            """,
            )
            /* BOX_CODE_FOLD_1 */
        }
        frame()
    }
}
