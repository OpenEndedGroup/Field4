// Built and launched from dev_docs/agents/transcripts/threebox.yaml
// (renderer + compute + draw). See the code blocks above.
