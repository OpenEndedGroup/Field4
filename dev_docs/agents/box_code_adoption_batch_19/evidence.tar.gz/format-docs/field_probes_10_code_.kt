val stats = producerBox.fieldStatsHere(channels = 1)
consumerBox.useFieldStats(stats) // include "fieldStats" now resolves as a reader
