fun Box.fieldProbeHere(
    samples: Int = 1024, // reservoir size pulled back to the CPU
    binding: Int = 63, // SSBO binding for FieldProbeBuffer
    descriptorSet: Int = 0,
    enabled: Boolean = true,
    ordinalRange: UIntRange? = null, // probe only a slice of invocations
): ShaderFieldProbe
