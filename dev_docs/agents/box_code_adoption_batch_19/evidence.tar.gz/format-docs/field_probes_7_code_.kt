fun Box.fieldStatsHere(
    channels: Int = 1, // independent distributions (1..64)
    sketchSize: Int = 256, // quantile-sketch resolution (pow2, 16..256)
    maxPartials: Int = 65_536,
    descriptorSet: Int = 0,
    partialBinding: Int = 61,
    resultBinding: Int = 62,
    stateSlots: Int = 8, // GPU-side smoothed/EMA slots
): ShaderFieldStats
