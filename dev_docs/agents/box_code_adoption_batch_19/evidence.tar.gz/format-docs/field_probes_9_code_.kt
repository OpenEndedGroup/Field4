data class FieldScalarStatsSnapshot(
    val calls: Long,
    val finiteCount: Long,
    val invalidCount: Long,
    val nonZeroCount: Long,
    val min: Double,
    val max: Double,
    val mean: Double,
    val variance: Double,
    val sum: Double,
    val sumSquares: Double,
    val standardDeviation: Double,
    val droppedPartials: Long, // >0 means raise maxPartials
    val centroids: List<Pair<Double, Double>>, // (value, weight) sketch
) {
    fun quantile(q: Double): Double

    fun cdf(value: Double): Double
}
