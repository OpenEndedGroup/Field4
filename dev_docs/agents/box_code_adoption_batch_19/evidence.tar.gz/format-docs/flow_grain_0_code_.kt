// The transcript launches the real fluid, editable grain shaders and motion RTT.
