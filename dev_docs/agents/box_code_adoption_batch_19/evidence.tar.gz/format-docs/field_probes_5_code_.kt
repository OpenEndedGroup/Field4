val probe = fieldProbeHere(samples = 4096).display("probe")

// tuning knobs
probe.maxDisplayHz = 12.0 // throttle card refreshes (default 5 Hz)
probe.ordinalRange(0u until 1000u) // restrict which invocations are sampled
probe.configure(samples = 256) // reconfigure live

// When finished: probe.deregister()    // stop and close the display channel

// pull the latest result without a display channel
val snap: FieldProbeSnapshot? = probe.readLatest()

// Optional alternative to polling: receive each snapshot on the read-back thread.
// probe.onSnapshot { snapshot -> println(snapshot.scalarSummary()) }
