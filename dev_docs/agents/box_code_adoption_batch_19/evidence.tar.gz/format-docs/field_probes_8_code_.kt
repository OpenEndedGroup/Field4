val stats = fieldStatsHere(channels = 1)
// ... run the dispatch ...

val s = stats.read(0) // blocking exact read of channel 0

s.mean
s.standardDeviation
s.min
s.max
s.finiteCount
s.quantile(0.5) // median from the GPU sketch
s.cdf(1.0) // fraction of samples <= 1.0

// Alternative: use the most recent asynchronous snapshot when one is available.
stats.latest(0)?.let { recent ->
    println("Latest async mean: ${recent.mean}")
}
