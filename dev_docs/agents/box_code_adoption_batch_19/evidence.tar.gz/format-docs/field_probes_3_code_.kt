// The "probe" display channel on the compute box, recorded live while the
// galaxy above animates. Same transcript: threebox.yaml.
