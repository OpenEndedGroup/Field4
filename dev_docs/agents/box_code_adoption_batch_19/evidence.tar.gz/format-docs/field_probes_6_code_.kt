data class FieldProbeSnapshot(
    val dimensions: Int, // 1=scalar, 2=vec2, 3=vec3, 4=vec4
    val invocationCount: Long, // total fieldProbe(...) calls
    val acceptedCount: Long, // within ordinalRange and matching type
    val finiteCount: Long, // non-NaN, non-Inf
    val sampleCount: Int, // reservoir samples actually returned
    val nanCount: Long,
    val infCount: Long,
    val nonZeroCount: Long,
    val typeMismatchCount: Long,
    val exactMin: DoubleArray, // per component, exact over all invocations
    val exactMax: DoubleArray,
    val samples: List<Vec4>,
)

// derived, on demand:
snap.anyNaN
snap.anyInf
snap.anyNonZero
snap.percentile(0.95) // from the sample
snap.scalarValues()
snap.scalarSummary()
snap.vec3Summary()
snap.summaryHtml(previous = last) // the card (histogram + chips)
