val tiles = TileResidency(columns = 5, rows = 5, tileSize = 4f)
val metadata = IntArray(tiles.capacity * 4)
tiles.moveTo(cameraX, cameraY)
for (i in 0 until tiles.changedCount) {
    val slot = tiles.changed[i]
    // Clear or regenerate this slot's simulation contents.
}
tiles.pack(metadata)
