from pathlib import Path
import json,re
R=Path.cwd();H=R/'dev_docs/agents/box_code_adoption_batch_19';rows=[]
def save(path,after,ids):
 p=R/path;before=p.read_text();assert before!=after,path;rows.append({'path':path,'before':before,'after':after,'findingIds':ids});p.write_text(after)
p='dev_docs/agents/transcripts/flow_grain.yaml';s=(R/p).read_text()
pattern=r'computeTask \{ _, cmd, _ ->\s*computeMemoryBarrier\(cmd, null as VulkanBuffer\?\)\s*graphicsMemoryBarrier\(cmd, null as VulkanBuffer\?\)\s*\}'
s,n=re.subn(pattern,'computeBarrier(graphics = true)',s);assert n==4,n
pattern=r'computeTask \{ _, cmd, _ ->\s*computeMemoryBarrier\(cmd, null as VulkanBuffer\?\)\s*\}'
s,n=re.subn(pattern,'computeBarrier()',s);assert n==1,n
old='''            return mix(mix(readCell(field, cell), readCell(field, cell + ivec2(1,0)), f.x),
            mix(readCell(field, cell + ivec2(0,1)), readCell(field, cell + ivec2(1)), f.x), f.y);'''
new='''            // Cell-centred bilinear interpolation; readCell rejects stale tile generations.
            vec4 lower = mix(readCell(field, cell), readCell(field, cell + ivec2(1, 0)), f.x);
            vec4 upper = mix(readCell(field, cell + ivec2(0, 1)), readCell(field, cell + ivec2(1)), f.x);
            return mix(lower, upper, f.y);''';assert old in s;s=s.replace(old,new)
old='''            return mix(mix(atCell(c),atCell(c+ivec2(1,0)),f.x),mix(atCell(c+ivec2(0,1)),atCell(c+ivec2(1)),f.x),f.y);''';new='''            // The same cell-centred interpolation used by the simulation pass.
            vec2 lower = mix(atCell(c), atCell(c + ivec2(1, 0)), f.x);
            vec2 upper = mix(atCell(c + ivec2(0, 1)), atCell(c + ivec2(1)), f.x);
            return mix(lower, upper, f.y);''';assert old in s;s=s.replace(old,new)
s=s.replace('''                while (frame() && resetFlow.completed < ticket) {}''','''                val resetStarted = System.nanoTime()
                val resetTimeoutNanos = 30_000_000_000L
                while (resetFlow.completed < ticket) {
                    // Ignore a prior failure while this new request is still pending.
                    if (!resetFlow.pending) check(resetFlow.failure == null) { "Reset failed: ${resetFlow.failure}" }
                    check(System.nanoTime() - resetStarted < resetTimeoutNanos) {
                        "Timed out waiting for reset $ticket: ${resetFlow.failure ?: "no frame-boundary consumer"}"
                    }
                    if (!frame()) return@frames
                }''')
s=s.replace('''if (renderer.renderList.modules["flow-strokes"] === module) renderer.renderList.modules.remove("flow-strokes")''','''if (renderer.renderList.modules["flow-strokes"] === module) {
                    renderer.renderList.modules.remove("flow-strokes")
                }''')
save(p,s,['4620ce43d259-01','4620ce43d259-03','4620ce43d259-04','4620ce43d259-05'])
p='public/docs/flow_grain.md';s=(R/p).read_text().replace('// Once per render, after updating pose in place:\nobjects.begin(renderer.frameCounter)','''// Once per render, after updating pose in place:
// Supply the current viewProjection, target width/height and sceneEpoch from your renderer.
history.capture(renderer.frameCounter, viewProjection, width, height, sceneEpoch)
objects.begin(renderer.frameCounter)''');save(p,s,['8286d4e220eb-01'])
p='public/docs/field_probes.md';s=(R/p).read_text();s=s.replace('    float   something;      // a slowly-advancing angle, set from Kotlin','    float   something;      // a slowly-advancing angle, set from Kotlin\n    uint    particleCount;  // valid entries; the final workgroup can include padding')
s=s.replace('    uint idx = gl_GlobalInvocationID.x;','    uint idx = gl_GlobalInvocationID.x;\n    if (idx >= pc.particleCount) return;',1)
a=s.index('    // rotate / mix each particle');b=s.index('    fieldProbe(length(delta));',a)
s=s[:a]+'''    vec4 seed = pc.inData.a[idx];
    float phaseZ = pc.something * seed.z;
    float phaseW = pc.something * seed.w;
    // Only the y cosine uses the slow phase; the other three trigonometric terms do not.
    float slowPhaseZ = phaseZ * 0.03;
    vec2 moved = vec2(
        seed.x * cos(phaseZ) + seed.y * sin(phaseW),
        -seed.x * sin(phaseW) + seed.y * cos(slowPhaseZ)
    );
    pc.outData.a[idx] = vec4(moved, seed.zw); // Carry seed and size unchanged.

    // Distance moved this step, rather than distance per second.
    vec2 delta = moved - seed.xy;
'''+s[b:]
s=s.replace('m.something = { x += 0.01; x.f }','m.particleCount = { N }\nm.something = { x += 0.01; x.f }',1).replace('m.x = N / 64; m.y = 1; m.z = 1','m.x = (N + 63) / 64; m.y = 1; m.z = 1',1)
s=s.replace('''fieldProbeHere(samples = 4096)
    .display("probe")                 // render the card on this display channel
    .onSnapshot { snap -> ... }        // or receive each snapshot yourself''','''val probe = fieldProbeHere(samples = 4096).display("probe")''')
s=s.replace('probe.deregister()                    // stop and close the display channel','// When finished: probe.deregister()    // stop and close the display channel')
s=s.replace('val snap: FieldProbeSnapshot? = probe.readLatest()','''val snap: FieldProbeSnapshot? = probe.readLatest()

// Optional alternative to polling: receive each snapshot on the read-back thread.
// probe.onSnapshot { snapshot -> println(snapshot.scalarSummary()) }''')
s=s.replace('''val s = stats.latest(0)        // most recent async read-back (or null)

s.mean;''','''
s.mean;''')
s=s.replace('''s.cdf(1.0)                     // fraction of samples <= 1.0
```''','''s.cdf(1.0)                     // fraction of samples <= 1.0

// Alternative: use the most recent asynchronous snapshot when one is available.
stats.latest(0)?.let { recent ->
    println("Latest async mean: ${recent.mean}")
}
```''',1)
anchor='This box runs a compute step under `fieldStats` and shows channel 0 as a table:\n'
assert anchor in s
producer='''
Install this exact shader in that box's **compute** property before running its Kotlin.
It uses its own position/velocity layout and records velocity magnitude in world units per second:

```diffstatic {data-lang=glsl}
#version 450
#extension GL_EXT_buffer_reference : require
layout(local_size_x = 64) in;
layout(std430, buffer_reference) buffer Positions { vec4 a[]; };
layout(std430, buffer_reference) buffer Velocities { vec4 a[]; };
layout(push_constant) uniform Step {
    Positions positions;
    Velocities velocities;
    float dt;            // seconds per step
    uint particleCount;
} pc;
{% property "fieldStats" %}

void main() {
    uint i = gl_GlobalInvocationID.x;
    if (i >= pc.particleCount) return;
    vec4 p = pc.positions.a[i];
    vec3 acceleration = vec3(-p.y, p.x, 0.0) * 0.15 - p.xyz * 0.03;
    vec3 velocity = (pc.velocities.a[i].xyz + acceleration * pc.dt) * 0.995;
    pc.positions.a[i] = vec4(p.xyz + velocity * pc.dt, p.w);
    pc.velocities.a[i] = vec4(velocity, 0.0);
    fieldStatsRecord(0u, length(velocity));
}
```
'''
s=s.replace(anchor,anchor+producer)
s=s.replace('''val N = 16384

val stats''','''// Requires the matching compute property above and an inherited renderer.
val N = 16384

val stats''',1)
s=s.replace('step.dt = { 0.016f }\nstep.x = N / 64;','step.dt = { 0.016f }\nstep.particleCount = { N }\nstep.x = (N + 63) / 64;',1)
s=s.replace('var t = 0.0\nframes {','frames {',1).replace('        t += 0.016\n','',1)
save(p,s,['db9cad39b79a-01','db9cad39b79a-02','db9cad39b79a-03','db9cad39b79a-04','db9cad39b79a-05'])
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
# Reuse existing container formatting and source proofs; shaders in Markdown need explicit wrappers.
for name,old in [('mechanical.py','box_code_adoption_batch_17'),('verify.py','box_code_adoption_batch_18')]:
 t=(R/'dev_docs/agents'/old/name).read_text().replace(old,'box_code_adoption_batch_19').replace('adoption-17','adoption-19').replace('adoption-18','adoption-19').replace("'a9d60a2fd'","'242165597'");(H/name).write_text(t)
(H/'revise.py').write_text((R/'dev_docs/agents/box_code_adoption_batch_18/revise.py').read_text())
