from pathlib import Path
import yaml,json
R=Path.cwd();H=R/'dev_docs/agents/box_code_adoption_batch_39';folder=R/'dev_docs/agents/demos/frame_history_reprojection';rows=[]
canonical={name:(folder/(name+'_code_.kt')).read_text() for name in ['rp_renderer','rp_bundle','rp_chain','rp_modes']}
canonical['rp_chain']=(R/'build/box-code-revision/adoption-39/chain-draft.kt').read_text()
canonical['rp_modes']='''// Each mode tests a different part of the same per-pixel correspondence:
// 0 accumulated beauty; 1 backward motion, including each ball; 2 previous UV,
// which breaks at moving silhouettes; 3 green usable history, red newly revealed pixels.
val names = listOf("beauty", "backward motion", "previous UV", "availability")
frames {
    while (true) {
        for (mode in 0..3) {
            chain.setPush("display", "mode", mode)
            println("mode " + mode + " - " + names[mode])
            repeat(150) { frame() }
        }
    }
}
'''
for name,after in canonical.items():
 p=folder/(name+'_code_.kt');before=p.read_text();p.write_text(after);rows.append(dict(path=str(p.relative_to(R)),findings=['c69d11328023-03','c69d11328023-05'] if name=='rp_chain' else [],before=before,after=after))
for path,ids in [('dev_docs/agents/demos/frame_history_reprojection/build.yaml',['c69d11328023-04']),('dev_docs/agents/transcripts/frame_history_reprojection.yaml',['fc9b34aa3014-01'])]:
 p=R/path;before=p.read_text();ed=[]
 def walk(n):
  if isinstance(n,yaml.MappingNode):
   values={k.value:v for k,v in n.value}
   if 'properties' in values and 'box' in values and values['box'].value in canonical:
    for k,v in values['properties'].value:
     if k.value=='code':
      code=canonical[values['box'].value];ind=k.start_mark.column+2;ed.append((v.start_mark.index,v.end_mark.index,'|\n'+''.join(' '*ind+x+'\n' if x else '\n' for x in code.rstrip().splitlines())))
   for _,v in n.value:walk(v)
  elif isinstance(n,yaml.SequenceNode):
   for v in n.value:walk(v)
 walk(yaml.compose(before));assert len(ed)==4,(path,len(ed));after=before
 for a,b,s in sorted(ed,reverse=True):after=after[:a]+s+after[b:]
 p.write_text(after);rows.append(dict(path=path,findings=ids,before=before,after=after))
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(H.parent/'box_code_adoption_batch_32'/name).read_text().replace('adoption-32','adoption-39').replace('ce168ea49','aca07741a');(H/name).write_text(s)
# Batch 32's verification baseline is elsewhere in its script, so pin it explicitly.
p=H/'verify.py';s=p.read_text().replace('baseline\':\'ce168ea49','baseline\':\'aca07741a').replace('"ce168ea49"','"aca07741a"');p.write_text(s)
