import asyncio,importlib.util
from pathlib import Path
R=Path.cwd();p=R/'dev_docs/agents/box_code_adoption_batch_39/baseline.py'
s=importlib.util.spec_from_file_location('base39_finish',p);n=importlib.util.module_from_spec(s)
# Load definitions without re-running the original experiment.
source=p.read_text().replace('asyncio.run(main())','');exec(compile(source,str(p),'exec'),n.__dict__)
async def main():
 code=(R/'dev_docs/agents/demos/frame_history_reprojection/rp_chain_code_.kt').read_text()
 imports='\n'.join(x for x in code.splitlines() if x.startswith('import '));body='\n'.join(x for x in code.splitlines() if not x.startswith('import '))
 await n.fragment('rerun-with-renderer-context','rp_chain',imports+'\nwith(renderer) {\n'+body+'\n}')
 await n.fragment('feedback-reproduced','rp_chain','check(chain.input !== baselineInput);check(chain.input === chain.output);check(chain.pass("taa")!!.target === baselineTaa);println("real feedback reproduced: input is reused display output")')
 await n.m.batch('stop',['stop rp_chain'])
asyncio.run(main())
