import asyncio,importlib.util
from pathlib import Path
R=Path.cwd();p=R/'dev_docs/agents/box_code_adoption_batch_39/baseline.py';spec=importlib.util.spec_from_file_location('base39_select',p);n=importlib.util.module_from_spec(spec);exec(compile(p.read_text().replace('asyncio.run(main())',''),str(p),'exec'),n.__dict__)
async def main():
 await n.fragment('feedback-selection','rp_chain','val nextInput = bundle.postStack.output();check(nextInput !== baselineInput);check(nextInput === chain.output);check(chain.pass("taa")!!.target === baselineTaa);println("old API input selection resolves to the existing display target")')
 await n.m.batch('stop',['stop rp_chain'])
asyncio.run(main())
