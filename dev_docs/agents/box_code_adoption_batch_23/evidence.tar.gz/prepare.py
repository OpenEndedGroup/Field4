from pathlib import Path
import json,re
h=Path('dev_docs/agents/box_code_adoption_batch_23');rows=[]
p=Path('public/docs/fline_examples.md');before=p.read_text();s=before
for old,new in [
 ('if (s == 0) moveTo(p) else lineTo(p)','lineTo(p)'),
 ('if (i == 0) moveTo(x, y - edge, z) else lineTo(x, y - edge, z)','lineTo(x, y - edge, z)'),
 ('if (i == 0) moveTo(p) else lineTo(p)','lineTo(p)'),
 ('if (i == 0) moveTo(cx + r * kotlin.math.cos(a), cy + r * kotlin.math.sin(a))\n        else lineTo(cx + r * kotlin.math.cos(a), cy + r * kotlin.math.sin(a))','lineTo(cx + r * kotlin.math.cos(a), cy + r * kotlin.math.sin(a))'),
 ('helix.sampleByNumber(400).forEachIndexed { i, p -> if (i == 0) moveTo(view(p)) else lineTo(view(p)) }','helix.sampleByNumber(400).forEach { p -> lineTo(view(p)) }'),
 ('moveTo(0, 0); lineTo(100, 0); lineTo(100, 100); lineTo(0, 100); close()','rect(0, 0, 100, 100)')]:
 assert old in s,old;s=s.replace(old,new)
# Every edited sampling path is a fresh FLine; explicitly mark its first point as a new subpath.
for needle in ['for (s in 0..steps) {','for (i in 0..steps) {','for (i in 0..140) {','for (i in 0 until 10) {','helix.sampleByNumber(400).forEach {']:
 s=s.replace(needle,'breakNext()\n'+('        ' if needle.startswith('for (s') else '    ')+needle)
a=s.index('fun circle(cx: Double, cy: Double, r: Double) = fline {');b=s.index('\n\n',a);s=s[:a]+'fun circle(cx: Double, cy: Double, r: Double) = FLine().circle(cx, cy, r)'+s[b:]
# Only the two incidental node markers adjacent to the boolean/offset demonstrations.
a=s.index('fun dot(x: Float, y: Float, c: Vec4) = fline {');b=s.index('    filled = true',a);s=s[:a]+'fun dot(x: Float, y: Float, c: Vec4) = fline {\n    circle(x, y, 2.5)\n'+s[b:]
a=s.index('fun dot(x: Float, y: Float, c: Vec4) = fline {',a+1);b=s.index('    filled = true',a);s=s[:a]+'fun dot(x: Float, y: Float, c: Vec4) = fline {\n    circle(x, y, 2.0)\n'+s[b:]
p.write_text(s);rows.append(dict(path=str(p),before=before,after=s,findingIds=['e775919b0ba4-01','e775919b0ba4-02','e775919b0ba4-03']))
p=Path('public/docs/animation_time_model.md');before=p.read_text();s=before.replace('moveTo(6.0, 6.0); lineTo(W - 6.0, 6.0); lineTo(W - 6.0, H - 6.0); lineTo(6.0, H - 6.0); close()','rect(6.0, 6.0, W - 12.0, H - 12.0)');a=s.index('    (0..28).forEach');b=s.index('    close(); color = rgba',a);s=s[:a]+'    circle(cx, cy, r, segments = 28)\n'+s[b:].replace('    close(); color = rgba','    color = rgba',1);p.write_text(s);rows.append(dict(path=str(p),before=before,after=s,findingIds=['48cc48dbfc2e-01']))
(h/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(h.parent/'box_code_adoption_batch_22'/name).read_text().replace('adoption-22','adoption-23').replace("'5895a5b9e'","'b833dec3b'");(h/name).write_text(s)
