val f = fline {
    moveTo(60, 190)
    cubicTo(120, 20, 260, 280, 360, 120)
    thickness = 4.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

val tangents = f.byCreatingTangentLines(samples = 18, length = 22f).onEach {
    it.thickness = 1.5
    it.color = vec(1.0, 1.0, 1.0, 0.20)
}

val normals = f.byCreatingNormalLines(samples = 18, length = 18f).onEach {
    it.thickness = 1.5
    it.color = vec(0.4, 1.0, 0.6, 0.22)
}

val highCurvature = f.findHighCurvaturePoints(threshold = 0.02f, samples = 120)
val corners =
    if (highCurvature.isEmpty()) emptyList()
    else
        [
            polylineFrom(highCurvature.map { it.v2 }).apply {
                pointed = true
                pointSize = 3.5
                stroked = false
                filled = true
                color = vec(1.0, 0.5, 0.2, 1.0)
            },
        ]

lines([f] + tangents + normals + corners, w = 420.0, h = 260.0, fitToSize = true)
