fun FLine.pieces(): List<FLine>
