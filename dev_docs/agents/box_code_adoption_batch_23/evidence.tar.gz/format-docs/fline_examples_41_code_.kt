val pts2 =
    (0..10).map { i ->
        val x = 40 + i * 34
        val y = 130 + 70 * kotlin.math.sin(i * 0.8)
        vec(x, y)
    }

val poly2 = polylineFrom(pts2, closed = false).apply {
    thickness = 2.0
    color = vec(1.0, 1.0, 1.0, 0.25)
    pointed = true
    pointSize = 3.0
}

val spline = cubicSplineFrom(pts2, closed = false, tension = 1f).apply {
    thickness = 5.0
    color = vec(0.7, 0.9, 1.0, 1.0)
}

lines(poly2, spline, w = 420.0, h = 260.0, fitToSize = true)
