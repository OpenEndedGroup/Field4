fun circle(cx: Double, cy: Double, r: Double) = FLine().circle(cx, cy, r)

fun blob(x: Double, y: Double) = fline {
    moveTo(x, y)
    cubicTo(x + 40, y - 30, x + 90, y + 10, x + 100, y + 50)
    cubicTo(x + 110, y + 90, x + 60, y + 70, x + 50, y + 110)
    cubicTo(x + 40, y + 150, x - 20, y + 120, x - 10, y + 80)
    cubicTo(x, y + 50, x - 30, y + 30, x, y)
    close()
}

fun dot(x: Float, y: Float, c: Vec4) = fline {
    circle(x, y, 2.5)
    filled = true
    stroked = false
    color = c
}

val out = mutableListOf<FLine>()
for ((row, op) in [FLineBooleanOp.Union, FLineBooleanOp.Subtract].withIndex()) {
    for (col in 0..1) {
        val x = 40.0 + col * 260
        val y = 40.0 + row * 190
        val a = blob(x + 20, y)
        val b = circle(x + 90, y + 60, 45.0)
        val r =
            if (col == 1) a.booleanExact(b, op).line
            else if (op == FLineBooleanOp.Union) a.byUnionWith(b) else a.byDifferenceWith(b)
        val c = if (col == 0) vec(1.0, 0.45, 0.25, 1.0) else vec(0.3, 0.8, 1.0, 1.0)
        r.filled = true
        r.stroked = true
        r.thickness = 1.5
        r.color = vec(c.x, c.y, c.z, 0.35)
        out.add(r)
        r.nodes.mapNotNull { it.toOrNull }.forEach { out.add(dot(it.x, it.y, c)) }
    }
}

lines(out, w = 460.0, h = 380.0, fitToSize = true)
