fun animate(block: suspend Frames.() -> Unit): Frames = eachFrame(block)
