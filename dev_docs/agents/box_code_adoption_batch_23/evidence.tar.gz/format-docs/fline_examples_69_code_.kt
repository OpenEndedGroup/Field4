val f = fline {
    moveTo(50, 180)
    cubicTo(120, 20, 300, 280, 350, 120)
    thickness = 1.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

val dashes =
    f.byDashing(dashLength = 18f, gapLength = 10f).mapIndexed { i, seg ->
        seg.apply {
            thickness = 1.0
            color = if (i % 2 == 0) vec(1.0, 0.7, 0.2, 1.0) else vec(0.4, 1.0, 0.6, 1.0)
        }
    }

lines(dashes, w = 420.0, h = 260.0, fitToSize = true)
