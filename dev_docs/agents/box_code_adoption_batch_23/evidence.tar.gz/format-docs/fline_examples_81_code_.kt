// A wave drawn on a slope: two bumps and a little ripple.
val wave = fline {
    moveTo(0, 0)
    for (i in 1..120) {
        val x = i / 120.0
        lineTo(x, 0.6 * x + Math.sin(x * 4 * Math.PI) * 0.25 + Math.sin(x * 14 * Math.PI) * 0.05)
    }
}

val path = fline {
    moveTo(30, 60)
    cubicTo(160, -40, 260, 220, 400, 90)
    color = vec(1.0, 1.0, 1.0, 0.3)
}

val once = path.wiggledBy(wave, amplitude = 60).apply {
    color = vec(0.4, 0.9, 1.0, 0.9)
    thickness = 2.0
}
val eight = (path + vec(0.0, 110.0)).wiggledBy(wave, repeats = 8, amplitude = 25).apply {
    color = vec(0.5, 1.0, 0.6, 0.9)
    thickness = 2.0
}
val kept = (path + vec(0.0, 220.0)).wiggledBy(wave, subtractChord = false, amplitude = 60).apply {
    color = vec(1.0, 0.6, 0.2, 0.9)
    thickness = 2.0
}

lines(
    path,
    path + vec(0.0, 110.0),
    path + vec(0.0, 220.0),
    once,
    eight,
    kept,
    w = 440.0,
    h = 360.0,
    fitToSize = true,
)
