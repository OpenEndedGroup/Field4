// A little "flower" made from repeated cubic petals.
val f = fline {
    val petalPoints: List<Vec3> = [
        vec(200, 130, 0),

        // Each repetition of `c` consumes 3 points: c1, c2, end.
        vec(260, 40, 0),
        vec(340, 80, 0),
        vec(300, 130, 0),
        vec(340, 180, 0),
        vec(260, 220, 0),
        vec(200, 190, 0),
        vec(140, 220, 0),
        vec(60, 180, 0),
        vec(100, 130, 0),
        vec(60, 80, 0),
        vec(140, 40, 0),
        vec(200, 130, 0),
    ]
    data(format = "m c+ z", parameters = petalPoints)

    filled = true
    stroked = true
    thickness = 3.0
    color = vec(1.0, 0.7, 0.2, 0.35)
}

lines(f, w = 420.0, h = 260.0, fitToSize = true)
