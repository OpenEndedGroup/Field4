val base = fline {
    moveTo(60, 60)
    cubicTo(120, 20, 240, 200, 320, 140)
    thickness = 4.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

val wobble =
    base
        .transform { p ->
            val dx = 10f * kotlin.math.sin(p.y * 0.05f)
            vec(p.x + dx, p.y, p.z)
        }
        .apply {
            color = vec(1.0, 0.4, 0.4, 1.0)
        }

lines(base, wobble, w = 420.0, h = 260.0, fitToSize = true)
