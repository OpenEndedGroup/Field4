import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

// One pump == one Runloop tick. Nothing here needs a window, a document or a wall clock.
fun trace(pumps: Int, build: (() -> Unit) -> Frames): Pair<List<Int>, Int> {
    var calls = 0
    val f = build { calls++ }
    val framer = Framer()
    val job = CoroutineScope(framer).launch { runCatching { f.body() } }
    val perPump = mutableListOf<Int>()
    repeat(pumps) {
        framer.frame()
        perPump += calls
    }
    job.cancel()
    return perPump to f.frameNumber
}

val pumps = 8
val builders = [
    "frames { while (frame()) … }" to trace(pumps) { body -> frames { while (frame()) body() } },
    "eachFrame { } — and so animate { }" to trace(pumps) { body -> eachFrame { body() } },
    "loop { }" to trace(pumps) { body -> loop { body() } },
    "forever { … ; true }" to
        trace(pumps) { body ->
            forever {
                body()
                true
            }
        },
]

/*
The claim this figure makes is `expect`, not the footnote: a frameNumber that broke it would
colour itself and the footnote would count it, rather than waiting for a reader to check the
arithmetic by eye.
*/
val figure = showTable(
    Table(
            ["after pump #"] + (1..pumps).map { "$it" } + "frameNumber",
            note = "cells are cumulative body calls",
        )
        .rows(builders.map { (label, r) -> [label] + r.first + r.second })
        .accent("frameNumber")
        .expect("frameNumber", because = "one frame per pump") { it == pumps - 1 },
    channel = "main",
)

// And the same claim as a build failure, so a regression in the builders cannot ship a
// figure that contradicts the paragraph under it.
check(figure.deviations.isEmpty()) { "a builder no longer advances one frame per pump" }
