enum class FLineHitKind {
    POINT,
    EDGE,
    FACE,
    UNKNOWN,
}

data class FLineIntersection(
    val closestVertexIndex: Int,
    val position: Vec3,
    val kind: FLineHitKind = FLineHitKind.UNKNOWN,
    val lineIndex: Int = -1, // which line of the ones you drew
    val label: String? = null, // that line's FLine.label
    val nodeIndex: Int = -1, // the node that IS the element
    val subPathIndex: Int = -1,
    val elementIndex: Int = -1, // edge 0, 1, 2... / face 0, 1...
    val u: Double = Double.NaN, // along the edge, or across the face
    val v: Double = Double.NaN, // up the face
    val onElement: Vec3? = null, // the point on the element, z included
)

enum class FLineFaceCoordinates {
    NONE,
    BILINEAR,
    BOUNDING_BOX,
}

var FLine.onClick: ((FLineIntersection) -> Unit)?
var FLine.hoverColor: Vec4?
var FLine.label: String?
