fun FLine.cubicTo(
    x0: Number,
    y0: Number,
    z0: Number = 0,
    x1: Number,
    y1: Number,
    z1: Number = 0,
    x: Number,
    y: Number,
    z: Number = 0,
): FLine.Node

fun FLine.cubicTo(x0: Number, y0: Number, x1: Number, y1: Number, x: Number, y: Number): FLine.Node
fun FLine.cubicTo(v0: Vec3, v1: Vec3, v: Vec3): FLine.Node
