val pts = [
    vec(40, 70, 0),
    vec(150, 200, 0),
    vec(260, 80, 0),
    vec(370, 210, 0),
    vec(470, 60, 0),
]

val loose = hyperbezierThrough(pts, tension = 1.0).apply {
    thickness = 2.5
    color = vec(0.35, 0.66, 1.0, 1.0)
}
val tight = hyperbezierThrough(pts, tension = 0.45).apply {
    thickness = 2.0
    color = vec(1.0, 0.62, 0.25, 0.9)
}

val dots = pts.map { p ->
    rect(p.x - 3.0, p.y - 3.0, 6.0, 6.0).toFLine(color = vec(1.0, 1.0, 1.0, 0.75), filled = true, stroked = false)
}

val curves: List<FLine> = [loose, tight]
lines(dots + curves, w = 520.0, h = 260.0, fitToSize = true)
