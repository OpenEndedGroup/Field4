val a = fline {
    moveTo(80, 80)
    lineTo(260, 80)
    lineTo(260, 220)
    lineTo(80, 220)
    close()
    filled = true
    stroked = true
    thickness = 2.0
    color = vec(1.0, 1.0, 1.0, 0.20)
}

val b = fline {
    moveTo(170, 40)
    lineTo(340, 140)
    lineTo(170, 240)
    lineTo(40, 140)
    close()
    filled = true
    stroked = true
    thickness = 2.0
    color = vec(1.0, 1.0, 1.0, 0.20)
}

val u = a.byUnionWith(b).apply {
    color = vec(0.4, 1.0, 0.6, 0.40)
    filled = true
    stroked = true
    thickness = 3.0
}
val i = a.byIntersectionWith(b).apply {
    color = vec(1.0, 0.5, 0.2, 0.55)
    filled = true
    stroked = true
    thickness = 3.0
}

lines(a, b, u, i, w = 420.0, h = 260.0, fitToSize = true)
