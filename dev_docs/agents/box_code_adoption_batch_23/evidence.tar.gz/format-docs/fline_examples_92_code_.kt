val fit = fitHyperbezierCubics(p0, c1, c2, p3, tolerance = 1e-4)
fit.segmentCount // how many cubics it took
fit.maxError // worst distance from the true curve, in world units
fit.toleranceMet // false if maxSegments ran out first
fit.solved // false if the solver stalled; cubics is then your input, unchanged
fit.cubics // the (control1, control2, end) triples
