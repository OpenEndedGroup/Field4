val pts =
    (0..80).map { i ->
        val x = 20 + i * 5
        val y = 120 + 60 * kotlin.math.sin(i * 0.2)
        vec(x, y)
    }

val wave = polylineFrom(pts, closed = false).apply {
    thickness = 3.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

lines(wave, w = 420.0, h = 260.0, fitToSize = true)
