fun FLine.crossings2D(other: FLine, tolerance: Float = 0.01f): List<FLineCrossing>
fun FLine.selfCrossings2D(tolerance: Float = 0.01f): List<FLineCrossing>
