val rings =
    (0 until 14).map { i ->
        val radius = 60.0 + i * 11.0
        val z = -90.0 + i * 14.0
        fline {
            val steps = 80
            breakNext()
            for (s in 0..steps) {
                val t = s / steps.toDouble() * Math.PI * 2.0
                val p = vec(Math.cos(t) * radius, Math.sin(t) * radius, z)
                lineTo(p)
            }
            close()
            color = vec(0.35 + i / 20.0, 0.85, 1.0 - i / 18.0, 0.7)
            thickness = 1.8
        }
    }

threeLines(rings, channel = "rings3d", height = 430, editable = false)
