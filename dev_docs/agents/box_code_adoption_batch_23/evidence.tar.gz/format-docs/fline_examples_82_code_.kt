// One turn of a circle around y = z = 0, with x running along: a coil when laid on a path.
val turn = fline {
    moveTo(0, 1, 0)
    for (i in 1..60) {
        val a = i / 60.0 * 2 * Math.PI
        lineTo(i / 60.0, Math.cos(a), Math.sin(a))
    }
}

val path = fline {
    moveTo(-150, 0, -60)
    cubicTo(-60, 160, 120, 60, -160, -120, 150, 40, 80)
    color = vec(1.0, 1.0, 1.0, 0.4)
}

val coil = path.wiggledBy(turn, repeats = 30, subtractChord = false, amplitude = 14, resolution = 60).apply {
    color = vec(0.4, 0.9, 1.0, 0.9)
    thickness = 1.5
}

threeLines(path, coil, channel = "coil3d", height = 430, editable = false)
