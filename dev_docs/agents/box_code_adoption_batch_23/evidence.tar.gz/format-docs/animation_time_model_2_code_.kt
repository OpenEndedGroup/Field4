/* BOX_CODE_FOLD_0 */
val W = 980.0
val H = 300.0
val FRAMES = 160 // frames in the clip: 8 s at 20 fps. The tick row is scaled to fill it.

/*
A border drawn every frame. Without a fixed extent, fitToSize rescales the view to whatever the
dot is doing and the motion cancels itself out — the lesson rasterizeFLinesFramed in
alife_animate.kt records, and it applies to lines() just as much.
*/
fun border(rgba: Vec4) = fline {
    rect(6.0, 6.0, W - 12.0, H - 12.0)
    color = rgba
    thickness = 1.4
    stroked = true
    filled = false
}

fun disc(cx: Double, cy: Double, r: Double, rgba: Vec4) = fline {
    circle(cx, cy, r, segments = 28)
    color = rgba
    filled = true
    stroked = false
}

/* BOX_CODE_FOLD_1 */

val started = AnimationClock.nowSeconds()
val stopAfter = 4.5

// The line worth reading: elapsed seconds in, a position along the track out. Written against the
// clock, not against frameNumber, so it means the same thing live and under capture.
fun dotX(elapsed: Double) = 110.0 + 760.0 * (0.5 - 0.5 * kotlin.math.cos(elapsed * 0.9))

fun draw(elapsed: Double, frames: Int, stopped: Boolean) {
    val accent = if (stopped) vec(1.0, 0.28, 0.30, 1.0) else vec(0.48, 0.85, 1.0, 1.0)
    val quiet = if (stopped) vec(1.0, 0.28, 0.30, 0.55) else vec(0.55, 0.62, 0.72, 0.7)
    val track = fline {
        moveTo(110.0, 105.0)
        lineTo(870.0, 105.0)
        color = quiet
        thickness = 1.4
    }
    // One tick per four frames reached. The row grows with frameNumber; the disc moves with the
    // clock. Every fourth, not every one: at this scale 160 adjacent ticks merge into a solid bar.
    val tickRow = fline {
        for (i in 0 until frames.coerceAtMost(FRAMES) step 4) {
            val x = 110.0 + 760.0 * (i.toDouble() / FRAMES)
            moveTo(x, 190.0)
            lineTo(x, 250.0)
        }
        color = accent
        thickness = 2.4
    }
    lines(
        border(quiet),
        track,
        tickRow,
        disc(dotX(elapsed), 105.0, 15.0, accent),
        channel = "main",
        w = W,
        h = H,
        fitToSize = true,
    )
}

loop {
    val elapsed = AnimationClock.nowSeconds() - started
    draw(elapsed, frameNumber, false)
    if (elapsed >= stopAfter) end()
}
    .end {
        // Runs on cancellation, in a NonCancellable scope that still carries the box context — so it can
        // still draw, and still get frames. Two of them, so the stopped state is definitely painted.
        repeat(2) {
            draw(AnimationClock.nowSeconds() - started, frameNumber, true)
            frame()
        }
    }
