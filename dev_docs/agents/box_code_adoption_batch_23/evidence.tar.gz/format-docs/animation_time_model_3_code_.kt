var x = 0.0
forever {
    x += 0.01
    display("main", "<h2>%.2f</h2>".format(x))
    x < 1.0 // false ends it
}
