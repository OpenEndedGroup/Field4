// A smooth target curve (a circle-ish polyline)
val center = vec(210.0, 130.0)
val radius = 95.0

val circle = fline {
    breakNext()
    for (i in 0..140) {
        val a = (i / 140.0) * kotlin.math.PI * 2.0
        val p = vec(center.x + radius * kotlin.math.cos(a), center.y + radius * kotlin.math.sin(a))
        lineTo(p)
    }
    thickness = 3.0
    color = vec(1.0, 1.0, 1.0, 0.35)
}

// A “messy” version of it
val messy = circle.byPerlinNoising(amplitude = 26f, frequency = 0.03f, octaves = 4, seed = 10L, samples = 180).apply {
    thickness = 2.5
    color = vec(1.0, 0.6, 0.2, 0.65)
}

// Project the messy samples back onto the circle
val projected = messy.byProjectingOnto(circle, samples = 180).apply {
    thickness = 4.0
    color = vec(0.4, 1.0, 0.6, 0.85)
}

lines(circle, messy, projected, w = 420.0, h = 260.0, fitToSize = true)
