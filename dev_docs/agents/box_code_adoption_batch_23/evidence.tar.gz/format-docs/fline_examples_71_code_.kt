val a = fline {
    moveTo(60, 60)
    cubicTo(140, 10, 220, 260, 360, 180)
    thickness = 4.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

val b = fline {
    moveTo(60, 200)
    cubicTo(120, 260, 260, 10, 360, 80)
    thickness = 4.0
    color = vec(0.7, 0.9, 1.0, 0.9)
}

val hits = a.crossings2D(b, tolerance = 1f).map { it.point }
val hitDots = polylineFrom(hits.map { it.v2 }).apply {
    pointed = true
    pointSize = 5.0
    stroked = false
    filled = true
    color = vec(1.0, 0.5, 0.2, 1.0)
}

lines(a, b, hitDots, w = 420.0, h = 260.0, fitToSize = true)
