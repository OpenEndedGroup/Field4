val base = fline {
    moveTo(80, 60)
    lineTo(320, 60)
    lineTo(320, 200)
    lineTo(80, 200)
    close()

    thickness = 3.0
    stroked = true
    filled = true
    color = vec(1.0, 1.0, 1.0, 0.15)
}

val rot = base.byRotating2D(angle = 0.4f, center = vec(200f, 130f)).apply {
    color = vec(1.0, 0.5, 0.2, 0.25)
}

val shear = base.byShearing2D(shearX = 0.35f, shearY = 0.0f).apply {
    color = vec(0.4, 1.0, 0.6, 0.25)
}

lines(base, rot, shear, w = 420.0, h = 260.0, fitToSize = true)
