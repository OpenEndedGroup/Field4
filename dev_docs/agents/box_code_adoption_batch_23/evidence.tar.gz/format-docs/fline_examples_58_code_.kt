val noisy = fline {
    moveTo(20, 130)
    for (i in 0..90) {
        val x = 20 + i * 4
        val y = 130 + 50 * kotlin.math.sin(i * 0.2) + 12 * kotlin.math.sin(i * 1.7)
        lineTo(x, y)
    }
    thickness = 2.0
    color = vec(1.0, 1.0, 1.0, 0.25)
}

val smooth = noisy.byGaussianSmoothing(sigma = 2.0f, samples = 120).apply {
    thickness = 4.0
    color = vec(0.4, 1.0, 0.6, 1.0)
}

val simple = smooth.bySimplifying(epsilon = 2.0f).apply {
    thickness = 1.0
    color = vec(1.0, 0.4, 0.4, 0.75)
}

lines(noisy, smooth, simple, w = 420.0, h = 260.0, fitToSize = true)
