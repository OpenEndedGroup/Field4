val square = fline {
    rect(0, 0, 100, 100)
    thickness = 3.0
    filled = true
    color = vec(0.3, 0.8, 1.0, 0.35)
}

val a = (square * 1.0) + vec(60, 60, 0)
val b = (square * 1.4) + vec(200, 80, 0)
val c = (square * 0.7) + vec(320, 140, 0)

lines(a, b, c, w = 420.0, h = 260.0, fitToSize = true)
