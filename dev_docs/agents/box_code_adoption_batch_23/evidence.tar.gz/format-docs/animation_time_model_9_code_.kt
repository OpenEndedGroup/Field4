frames {
    val out = java.io.File("/tmp/frames.txt").printWriter()
    try {
        while (frame()) out.println(frameNumber)
    } finally {
        out.close()
    }
}
