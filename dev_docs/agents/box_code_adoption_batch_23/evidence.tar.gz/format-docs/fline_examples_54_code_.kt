val f = fline {
    moveTo(50, 180)
    cubicTo(120, 20, 300, 280, 350, 120)
    thickness = 4.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

val c = f.cursor(tol = 0.01f)
val total = c.lengthD()

val dots = mutableListOf<FLine>()
val ticks = mutableListOf<FLine>()

fun dot(p: Vec3, color: Vec4) = fline {
    moveTo(p.x, p.y)
    lineTo(p.x + 0.001, p.y + 0.001)
    pointed = true
    pointSize = 2.75
    stroked = false
    filled = true
    this.color = color
}

val step = 18f
var d = 0f
while (d <= total) {
    c.setD(d)
    val p = c.position()
    dots.add(dot(p, vec(1.0, 0.4, 0.3, 1.0)))

    val t = c.tangent()
    if (t != null && t.lengthSquared() > 1e-9) {
        val dir = Vec3(t).normalize()
        val a = Vec3(p).sub(Vec3(dir).mul(8f))
        val b = Vec3(p).add(Vec3(dir).mul(8f))
        ticks.add(
            fline {
                moveTo(a)
                lineTo(b)
                thickness = 1.5
                color = vec(1.0, 1.0, 1.0, 0.25)
            },
        )
    }

    d += step
}

lines([f] + ticks + dots, w = 420.0, h = 260.0, fitToSize = true)
