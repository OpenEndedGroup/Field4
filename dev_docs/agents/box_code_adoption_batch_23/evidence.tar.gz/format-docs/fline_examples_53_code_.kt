// In afield.geometry.path.java2d.FLinesAndJavaShapes.Cursor
class Cursor {
    fun reset()

    fun hasNext(): Boolean

    // Parameterization
    val t: Float

    fun setT(q: Float): Cursor

    val d: Float

    fun setD(d: Float): Cursor

    fun lengthT(): Int

    fun lengthD(): Float

    // Geometry at current position
    fun position(): Vec3

    fun location(): FLineLocation? // everything below, at once

    fun tangent(): Vec3? // unit length

    fun normal(): Vec3? // principal normal, towards the centre; null on straight runs

    fun binormal(): Vec3? // tangent x normal; null on straight runs

    fun curvature(): Float // unsigned, 3D

    fun normal2D(): Vec2? // unit, (tangent.y, -tangent.x)

    fun signedCurvature2D(): Float // positive bending towards normal2D

    fun radiusOfCurvature(): Vec3? // from here to the centre of the osculating circle

    fun setNearest(point: Vec3): Cursor

    // Analysis helpers (mostly for cubics)
    fun extremalInnerPoints(): List<Float>

    fun tangentBreaks(): List<Float>

    fun inflectionPointsXY(): List<Float>

    // Editing / splitting
    fun split(): Pair<FLine?, FLine?>

    fun splitD(d: List<Float>): List<FLine>

    fun splitT(t: List<Float>): List<FLine>

    fun segment(): FLine.Node?
}
