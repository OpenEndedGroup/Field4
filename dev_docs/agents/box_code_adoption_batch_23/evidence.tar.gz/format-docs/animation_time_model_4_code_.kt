frames {
    display("main", "<h2>ready</h2>")
    delay(1000)
    display("main", "<h2>set</h2>")
    delay(1000)
    display("main", "<h2>go</h2>")
}
