val s1 = fline {
    moveTo(60, 200)
    smoothTo(120, 60)
    smoothTo(220, 240)
    smoothTo(360, 120)
    thickness = 5.0
    color = vec(1.0, 0.7, 0.2, 0.9)
}

val s2 = fline {
    moveTo(60, 200)
    tcbTo(vec(120, 60), tension = 0.2f, continuity = -0.2f, bias = 0.0f)
    tcbTo(vec(220, 240), tension = 0.2f, continuity = -0.2f, bias = 0.0f)
    tcbTo(vec(360, 120), tension = 0.2f, continuity = -0.2f, bias = 0.0f)
    thickness = 5.0
    color = vec(0.4, 1.0, 0.6, 0.9)
}

lines(s1, s2, w = 420.0, h = 260.0, fitToSize = true)
