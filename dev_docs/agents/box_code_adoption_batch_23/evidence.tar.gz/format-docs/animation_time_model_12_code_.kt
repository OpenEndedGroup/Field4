/*
`generator { }` is the output-only shape: the input type is Unit, so `yield(v)` returns Unit.
This one climbs from `from` to `to` over n steps and then simply returns — a generator that
completes rather than running forever.
*/
fun ramp(from: Double, to: Double, n: Int) = generator<Double> {
    for (i in 0 until n) yield(from + (to - from) * i / (n - 1.0))
}

// `+` is sequential: drive the left to completion, then the right. An attack, then a decay.
fun envelope() = ramp(0.0, 1.0, 90) + ramp(1.0, 0.15, 210)

// `map` transforms the output values as they come past.
fun shaped() = envelope().map { it * it }

/*
`pipe` feeds one generator's output in as another's input. A one-pole smoother is the natural
thing to put on the right: it needs the previous output, which is exactly the state a generator
keeps for free.
*/
fun smoother(alpha: Double) = generator2<Double, Double> {
    var y = 0.0
    var x = yield(0.0)
    while (true) {
        y += alpha * (x - y)
        x = yield(y)
    }
}

// Drive any Unit-input generator by hand until it says it is finished by returning null.
fun drive(g: Generator<Unit, Double>, cap: Int): List<Number> {
    val out = mutableListOf<Number>()
    var v = g.start()
    while (v != null && out.size < cap) {
        out += v
        v = g.next(Unit)
    }
    return out
}

val cap = 300
/*
The bare `ramp(0 -> 1, 90)` is deliberately not plotted: it is pixel-identical to the first 90
steps of `a + b`, so drawing it only puts an invisible series in the legend. Its length is the
interesting part, and you can read that off where the orange trace turns.
*/
showSignals(
    "a + b — attack then decay" to drive(envelope(), cap),
    ".map { it * it }" to drive(shaped(), cap),
    "pipe smoother(0.06)" to drive(shaped() pipe smoother(0.06), cap),
    channel = "main",
    title = "one signal in three stages: +, map, pipe",
    xTitle = "step",
)
