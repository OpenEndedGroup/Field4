/*
One wall-clock reading per frame for two seconds, then plot the gaps between them. Nothing here
is frame-indexed: a screenshot capture leaves AnimationClock on monotonic real time, unlike the
frame-synchronous video recorder.
*/
val t0 = AnimationClock.nowSeconds()
val stamps = ArrayList<Double>(400_000)

loop {
    val now = AnimationClock.nowSeconds()
    stamps += now
    if (now - t0 >= 2.0) end()
}
    .end {
        val gapsUs = (1 until stamps.size).map { (stamps[it] - stamps[it - 1]) * 1_000_000.0 }
        val elapsed = stamps.last() - stamps.first()

        // A 100-frame running mean, so the trend is readable under the spikes.
        val window = 100
        val smooth =
            gapsUs.indices.map { i ->
                val lo = maxOf(0, i - window + 1)
                gapsUs.subList(lo, i + 1).average()
            }

        val perSecond = gapsUs.size / elapsed
        val median = gapsUs.sorted()[gapsUs.size / 2]
        showSignals(
            "gap between frames (µs)" to gapsUs,
            "100-frame running mean" to smooth,
            channel = "main",
            title =
                "%,d frames in %.2f s — %,.0f a second, median gap %,.0f µs"
                    .format(
                        gapsUs.size,
                        elapsed,
                        perSecond,
                        median,
                    ),
            xTitle = "frame",
            yTitle = "µs",
        )
    }
