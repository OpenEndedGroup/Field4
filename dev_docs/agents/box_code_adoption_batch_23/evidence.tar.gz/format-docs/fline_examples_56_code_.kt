val f = fline {
    moveTo(60, 150)
    cubicTo(120, 20, 300, 260, 360, 120)
    thickness = 3.0
    color = vec(0.9, 0.9, 1.0, 1.0)
}

val dots = polylineFrom(f.sampleByNumber(40).map { it.v2 }).apply {
    pointed = true
    pointSize = 2.5
    stroked = false
    filled = true
    color = vec(1.0, 0.5, 0.2, 1.0)
}

lines(f, dots, w = 420.0, h = 260.0, fitToSize = true)
