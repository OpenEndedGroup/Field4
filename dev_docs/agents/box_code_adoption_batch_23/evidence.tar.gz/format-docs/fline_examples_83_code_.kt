val a = fline {
    moveTo(60, 190)
    cubicTo(120, 20, 260, 280, 360, 120)
    thickness = 2.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

val b = a.byReversing().apply { color = vec(1.0, 0.4, 0.4, 0.65) }

val mid = a.byBlendingWith(b, t = 0.5f).apply {
    thickness = 1.0
    color = vec(0.4, 1.0, 0.6, 0.7)
}

val snippet = a.byExtracting(tStart = 0.8f, tEnd = 1.9f).apply {
    thickness = 2.0
    color = vec(1.0, 0.7, 0.2, 0.8)
}

lines(a, b, mid, snippet, w = 420.0, h = 260.0, fitToSize = true)
