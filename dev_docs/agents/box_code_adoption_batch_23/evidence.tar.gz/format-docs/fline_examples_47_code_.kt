val rounded = fline {
    moveTo(60, 200)
    lineTo(60, 60)
    arcTo(vec(60, 60), vec(360, 60), radius = 40, segments = 32)
    lineTo(360, 200)

    thickness = 1.0
    color = vec(1.0, 0.9, 0.5, 1.0)
}

lines(rounded, w = 420.0, h = 260.0, fitToSize = true)
