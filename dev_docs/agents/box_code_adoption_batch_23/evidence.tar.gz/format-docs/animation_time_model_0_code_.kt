var n = 0 // runs once

loop { // runs every frame
    n++
    display("main", "<h2>$n</h2>")
    delay(100) // wait 100 ms; this counts as the pass's frame
}
