val f = fline {
    moveTo(0, 0)
    cubicTo(10, 20, 30, 20, 20, 40)
    cubicTo(60, 20, 30, 20, 40, 20)
} * 3

val f2 = fline {
    moveTo(10, 60)
    cubicTo(10, 20, 30, 20, 90, 40)
    cubicTo(60, 20, 30, 20, 20, 20)
    cubicTo(10, 200, 30, 20, 30, 20)
} * 3 + vec(300, 0)

val ii = FLineInterpolator(f, f2)

fun ink(line: FLine, tint: Vec4, thick: Double) = line.apply {
    filled = false
    stroked = true
    thickness = thick
    color = tint
}

val ghosts = [
    ink(f.copy(), vec(0.78, 0.9, 1.0, 0.20), 1.8),
    ink(f2.copy(), vec(1.0, 0.76, 0.52, 0.20), 1.8),
]

val frames =
    (0 until 10).map { i ->
        val t = i / 9f
        ink(
            ii.lineAt(t),
            vec(
                0.28 + i * 0.06,
                0.94 - i * 0.05,
                1.0 - i * 0.08,
                0.88,
            ),
            3.0,
        )
    }

lines(ghosts + frames, w = 560.0, h = 360.0, fitToSize = true)
