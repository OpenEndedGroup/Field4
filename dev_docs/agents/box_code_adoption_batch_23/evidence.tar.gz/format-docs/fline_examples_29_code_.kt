fun FLine.breakNext()
