var x = 0
loop {
    x++
}
    .end {
        x = 20
    }
