val f = fline {
    moveTo(50, 50)
    lineTo(350, 50)

    moveTo(50, 200)
    lineTo(350, 200)

    thickness = 5.0
    color = vec(0.7, 0.9, 1.0, 1.0)
}

val ps = f.pieces()
lines(ps, w = 420.0, h = 260.0, fitToSize = true)
