import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class Result(val how: String, val extraBodyCalls: Int, val endBlockRan: Boolean, val note: String)

/*
Each probe runs a frame body for three pumps, requests a stop, then pumps six more times and
reports what the body did afterwards. These are the stops box code can stage for itself; the
`Box.stop` case needs the box's launch epoch, which is internal to Field — see below.
*/
fun probe(
    how: String,
    note: String,
    build: (counter: () -> Unit) -> Frames,
    request: (Frames, kotlinx.coroutines.Job) -> Unit,
): Result {
    var calls = 0
    var cleaned = false
    val f = build { calls++ }.end { cleaned = true }
    val framer = Framer()
    val job = CoroutineScope(framer).launch { runCatching { f.body() } }
    f.job = job
    repeat(3) { framer.frame() }
    val atRequest = calls
    request(f, job)
    repeat(6) { framer.frame() }
    return Result(how, calls - atRequest, cleaned, note)
}

val results = [
    probe(
        "shouldend flips — what re-running does",
        "the generation fence is read at the top of frame()",
        { c -> eachFrame { c() } },
        { f, _ -> f.shouldend = { true } },
    ),
    probe(
        "the Job is cancelled directly",
        "the pending yield() throws immediately",
        { c -> eachFrame { c() } },
        { _, job -> job.cancel() },
    ),
    probe(
        "end() from inside the body",
        "requested during a body call, so nothing follows it",
        { c ->
            eachFrame {
                c()
                end()
            }
        },
        { _, _ -> },
    ),
    // `throw`, not `error("boom")`: in a box the script's implicit Box receiver is still in scope,
    // so `error(...)` resolves to Box.error and reports a box error instead of throwing.
    probe(
        "the body throws",
        ".end { } is not a finally",
        { c ->
            eachFrame {
                c()
                throw IllegalStateException("boom")
            }
        },
        { _, _ -> },
    ),
    probe(
        "the body returns normally",
        "there is no cancellation to catch",
        { c ->
            frames {
                repeat(2) {
                    c()
                    frame()
                }
            }
        },
        { _, _ -> },
    ),
]

// `roleBy` rather than a hex literal: OK/BAD are the same `--field-*` tokens `markdown()`'s
// `{ok:…}` spans use, so this column agrees with every other "ran / did not run" in the docs.
showTable(
    Table(["how the Frames stopped", "further body calls", ".end { } ran", "why"])
        .rows(results.map { [it.how, it.extraBodyCalls, it.endBlockRan, it.note] })
        .accent("further body calls")
        .color("why", TABLE_MUTED)
        // WARN, not BAD: two of these rows are correct completion behaviour, not errors — the
        // figure wants a reader to notice them, not to read them as a failure.
        .roleBy(".end { } ran") { if (it == true) CellRole.OK else CellRole.WARN }
        .format(".end { } ran") { if (it == true) "yes" else "no" },
    channel = "main",
)

// The two claims the paragraphs below make, as assertions rather than as prose a reader has to
// check against the figure by eye.
check(results.count { it.extraBodyCalls > 0 } == 1) { "only shouldend should cost a further body call" }
check(results.count { it.endBlockRan } == 3) { ".end { } should run for the three cancellation cases" }
