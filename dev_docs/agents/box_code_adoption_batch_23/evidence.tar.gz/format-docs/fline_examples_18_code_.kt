val a = vec(50, 50)
val b = vec(350, 200)

val f = fline {
    moveTo(a) // Vec2
    lineTo(b.x, b.y) // Numbers

    thickness = 1.0
    color = vec(0.9, 0.9, 1.0, 1.0)
}

lines(f, w = 400.0, h = 250.0, fitToSize = true)
