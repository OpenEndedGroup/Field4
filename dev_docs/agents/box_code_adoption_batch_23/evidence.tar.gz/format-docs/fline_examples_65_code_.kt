val f = fline {
    moveTo(0, 0)
    cubicTo(10, 20, 30, 20, 20, 40)
    cubicTo(60, 20, 30, 20, 40, 20)
} * 3

val sweep =
    10.alphas { t ->
        f.byDriverSmoothing(
                config = FLineDriverSmoothingConfig(
                    maxAngularVelocity = 1f / (1f + t.f * 20f),
                    maxAngularAcceleration = 0.10f,
                    targetUpdateMode = FLineDriverTargetUpdateMode.FORWARD_ONLY,
                    forwardSearchSamples = 20,
                ),
                samples = 180,
            )
            .apply {
                filled = false
                stroked = true
                thickness = 3.0
                color = vec(
                    0.28 + t * 0.58,
                    0.94 - t * 0.24,
                    1.0 - t * 0.36,
                    0.90,
                )
            } + vec(t * 300.0, 0.0)
    }

lines(sweep, w = 720.0, h = 220.0, fitToSize = true)
