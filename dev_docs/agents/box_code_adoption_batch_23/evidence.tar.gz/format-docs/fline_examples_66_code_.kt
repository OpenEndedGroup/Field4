val f = fline {
    moveTo(0, 0, 0)
    cubicTo(30, 10, 20, 2, 30, 20, 20, 40)
    cubicTo(20, 60, 20, 2, 30, -50, 40, 20)
} * 3

val sweep3d =
    10.alphas { t ->
        f.byDriverSmoothing(
                config = FLineDriverSmoothingConfig(
                    maxAngularVelocity = 1f / (1f + t.f * 20f),
                    maxAngularAcceleration = 0.10f,
                    targetUpdateMode = FLineDriverTargetUpdateMode.FORWARD_ONLY,
                    forwardSearchSamples = 20,
                ),
                samples = 180,
            )
            .apply {
                filled = false
                stroked = true
                thickness = 3.0
                color = vec(
                    0.32 + t * 0.54,
                    0.86 - t * 0.22,
                    1.0 - t * 0.26,
                    0.88,
                )
            } + vec(t * 300.0, 0.0, 0.0)
    }

threeLines(sweep3d, channel = "driver3d", height = 430, editable = false)
