fline {
    moveTo(vec(0, 0, 0))
    lineTo(vec(100, 0, 0)) {
        color = vec(1, 0.5, 0.2, 1)
        pointSize = 6.0
    }
    pointed = true
}
