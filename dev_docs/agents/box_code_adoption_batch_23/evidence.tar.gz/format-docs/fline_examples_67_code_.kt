val base = fline {
    moveTo(60, 180)
    cubicTo(120, 20, 260, 280, 360, 120)
    thickness = 3.0
    color = vec(1.0, 1.0, 1.0, 1.0)
}

val (l, r) = base.byCreatingParallelCurves(distance = 12f, samples = 80)

val left = l.apply {
    color = vec(0.4, 1.0, 0.6, 1.0)
    thickness = 3.0
}
val right = r.apply {
    color = vec(1.0, 0.4, 0.4, 1.0)
    thickness = 3.0
}

lines(base, left, right, w = 420.0, h = 260.0, fitToSize = true)
