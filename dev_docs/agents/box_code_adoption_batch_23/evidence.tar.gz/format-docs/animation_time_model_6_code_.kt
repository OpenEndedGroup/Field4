val started = AnimationClock.nowSeconds()

loop {
    val t = AnimationClock.nowSeconds() - started
    display("main", "<h2>%.1f s</h2>".format(t))
    if (t > 5.0) end() // stop after five seconds
}
