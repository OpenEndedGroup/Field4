val f = fline {
    moveTo(0, 0)
    cubicTo(10, 20, 30, 20, 20, 40)
    cubicTo(60, 20, 30, 20, 40, 20)
} * 3

val f2 = fline {
    moveTo(10, 60)
    cubicTo(10, 20, 30, 20, 90, 40)
    cubicTo(60, 20, 30, 20, 20, 20)
    cubicTo(10, 200, 30, 20, 30, 20)
} * 3 + vec(300, 0)

val ii = FLineInterpolator(
    f,
    f2,
    FLineInterpolationConfig(
        motion = FLineInterpolationMotion(
            spatialSpinAngle = 1f,
            spatialSpinAxis = vec(0f, 1f, 0.25f),
            spatialSpinMode = FLineInterpolationSpinMode.MIDPOINT_RETURN,
        ),
    ),
)

val shift = vec(28, 8, 0)

fun ink(line: FLine, tint: Vec4, thick: Double) = line.apply {
    filled = false
    stroked = true
    thickness = thick
    color = tint
}

val frames =
    (0 until 10).map { i ->
        val t = i / 9f
        ink(
            ii.lineAt(t).byPerspectiveProjecting(cameraPos = vec(180f, 90f, -620f)) + shift,
            vec(
                0.24 + i * 0.07,
                0.92 - i * 0.05,
                1.0 - i * 0.08,
                0.9,
            ),
            3.0,
        )
    }

val ghosts = [
    ink(
        f.copy().byPerspectiveProjecting(cameraPos = vec(180f, 90f, -620f)) + shift,
        vec(0.78, 0.9, 1.0, 0.18),
        1.8,
    ),
    ink(
        f2.copy().byPerspectiveProjecting(cameraPos = vec(180f, 90f, -620f)) + shift,
        vec(1.0, 0.76, 0.52, 0.18),
        1.8,
    ),
]

lines(ghosts + frames, w = 460.0, h = 240.0, fitToSize = true)
