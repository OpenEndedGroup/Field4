var x = 0
loop {
    x++
}
    .end {
        x = 20
        10 {
            frame()
            x = 30 + it
        }
    }
