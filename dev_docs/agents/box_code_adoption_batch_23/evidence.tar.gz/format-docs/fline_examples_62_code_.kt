val base = fline {
    moveTo(60, 180)
    cubicTo(120, 20, 260, 280, 360, 120)
}

val clean = base.copy().apply {
    thickness = 4.0
    color = vec(1.0, 1.0, 1.0, 0.30)
}

val gauss = base.byGaussianNoising(amplitude = 6f, seed = 1L, samples = 140).apply {
    thickness = 3.0
    color = vec(1.0, 0.6, 0.2, 0.85)
}

val oriented = base.byOrientedGaussianNoising(normalAmplitude = 10f, tangentAmplitude = 1.5f, seed = 2L, samples = 140).apply {
    thickness = 4.5
    color = vec(0.4, 1.0, 0.6, 0.85)
}

val perlin = base.byPerlinNoising(amplitude = 12f, frequency = 0.02f, octaves = 4, seed = 3L, samples = 140).apply {
    thickness = 3.5
    color = vec(0.7, 0.9, 1.0, 0.85)
}

lines(clean, gauss, oriented, perlin, w = 420.0, h = 260.0, fitToSize = true)
