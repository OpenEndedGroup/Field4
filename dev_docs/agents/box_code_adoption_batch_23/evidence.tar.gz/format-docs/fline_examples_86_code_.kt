fun asymmetricStroke() =
    polylineFrom(
            [
                vec(-150, 20),
                vec(-80, -110),
                vec(-10, -30),
                vec(35, 120),
                vec(90, 40),
                vec(150, -60),
            ],
        )
        .apply {
            filled = false
            stroked = true
            thickness = 2.0
        }

val start = asymmetricStroke()
val end =
    asymmetricStroke()
        .byRotating2D(1.7f, center = vec(0f, 0f))
        .byScaling2D(0.78f, 1.24f, center = vec(0f, 0f))
        .byShearing2D(0.18f, -0.08f)

val vanillaMid = start.interpolatorTo(end).lineAt(0.5f).apply {
    filled = false
    stroked = true
    thickness = 3.0
    color = vec(1.0, 0.58, 0.22, 0.8)
}

val alignedMid =
    start
        .interpolatorTo(
            end,
            config = FLineInterpolationConfig(
                alignment = FLineInterpolationAlignment(
                    rotationMode = FLineInterpolationRotationMode.FIT_LINE_2D,
                    scaleMode = FLineInterpolationScaleMode.BOUNDS_DIAGONAL,
                ),
            ),
        )
        .lineAt(0.5f)
        .apply {
            filled = false
            stroked = true
            thickness = 3.0
            color = vec(0.42, 1.0, 0.68, 0.8)
        }

fun ghost(line: FLine, tint: Vec4) = line.copy().apply {
    filled = false
    stroked = true
    thickness = 1.8
    color = tint
}

val leftShift = vec(-190, 0, 0)
val rightShift = vec(190, 0, 0)

val panels = [
    fline {
        rect(-330, -160, 300, 320)
        filled = true
        stroked = false
        color = vec(0.12, 0.15, 0.19, 0.28)
    },
    fline {
        rect(30, -160, 300, 320)
        filled = true
        stroked = false
        color = vec(0.15, 0.12, 0.09, 0.28)
    },
]

val alignedLines: List<FLine> = [
    ghost(start, vec(0.76, 0.9, 1.0, 0.20)) + leftShift,
    ghost(end, vec(1.0, 0.8, 0.5, 0.20)) + leftShift,
    vanillaMid + leftShift,
    ghost(start, vec(0.76, 0.9, 1.0, 0.20)) + rightShift,
    ghost(end, vec(1.0, 0.8, 0.5, 0.20)) + rightShift,
    alignedMid + rightShift,
]
val comparison = panels + alignedLines

lines(comparison, w = 720.0, h = 360.0, fitToSize = true)
