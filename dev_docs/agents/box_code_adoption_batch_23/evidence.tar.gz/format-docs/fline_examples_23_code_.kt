fun FLine.close(): FLine.Node
