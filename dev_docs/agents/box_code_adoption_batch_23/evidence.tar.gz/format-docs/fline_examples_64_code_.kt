val raw = fline {
    moveTo(40, 140)
    for (i in 1..240) {
        val t = i / 240.0
        val x = 40 + t * 340
        val y = 140 + 55 * kotlin.math.sin(t * 7.0 * kotlin.math.PI) + 11 * kotlin.math.sin(t * 70.0)
        lineTo(x, y)
    }
}

val showRaw = raw.copy().apply {
    thickness = 2.0
    color = vec(1.0, 1.0, 1.0, 0.20)
}

val ema = raw.byEmaFiltering(alpha = 0.10f, samples = 220).apply {
    thickness = 3.0
    color = vec(0.7, 0.9, 1.0, 0.85)
}

val oneEuro = raw.byOneEuroFiltering(minCutoffHz = 1.0f, beta = 0.05f, dCutoffHz = 1.0f, fpsHint = 60f, samples = 220).apply {
    thickness = 4.0
    color = vec(0.4, 1.0, 0.6, 0.85)
}

val ab = raw.byAlphaBetaFiltering(alpha = 0.25f, beta = 0.08f, fpsHint = 60f, samples = 220).apply {
    thickness = 3.5
    color = vec(1.0, 0.6, 0.2, 0.85)
}

val gpMean =
    raw.byGaussianProcessInterpolating(
            trainingSamples = 44,
            samples = 220,
            lengthScale = 0.11f,
            variance = 1f,
            noise = 0.02f,
            drawSamples = false,
        )
        .apply {
            thickness = 5.0
            color = vec(1.0, 0.4, 0.4, 0.70)
        }

// One-Dollar outputs a normalized gesture around the origin; shift it back into view.
val oneDollar = (raw.byOneDollarFiltering(targetSamples = 64, targetSize = 220f, rotateToZero = true)).apply {
    thickness = 4.0
    color = vec(0.8, 0.6, 1.0, 0.85)
}
val oneDollarPlaced = oneDollar + vec(210, 140, 0)

lines(showRaw, ema, oneEuro, ab, gpMean, oneDollarPlaced, w = 420.0, h = 260.0, fitToSize = true)
