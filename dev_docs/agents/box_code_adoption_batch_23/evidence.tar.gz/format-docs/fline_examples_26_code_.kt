// Pen operators inside fline { }: `-` draws, `+` lifts the pen to a new subpath.
val zig = fline {
    -vec(40, 40) // first point -> promoted to moveTo
    -vec(140, 40) // lineTo
    -vec(140, 140)
    +vec(200, 40) // pen up: a second subpath starts here
    -vec(300, 140)
    thickness = 3.0
    color = vec(0.98, 0.88, 0.28, 1.0)
}

// Collection literal: first point is a moveTo, the rest lineTo.
val tri: FLine = [vec(60, 220), vec(180, 300), vec(300, 220)]
tri.apply {
    close()
    thickness = 2.0
    color = vec(0.4, 1.0, 0.6, 1.0)
}

// `..` makes a segment; `+=` extends it with another point.
val seg = (vec(340, 40)..vec(460, 40)).apply {
    thickness = 2.0
    color = vec(1.0, 0.5, 0.25, 1.0)
}
seg += vec(460, 160)

// The `data` mini-language, driven variadically, with per-node styling on the box.
val box = FLine().data("m l l l z", 340, 200, 460, 200, 460, 300, 340, 300).apply {
    stroked = true
    color = vec(0.34, 0.82, 1.0, 1.0)
}

lines(zig, tri, seg, box, w = 520.0, h = 340.0, fitToSize = true)
