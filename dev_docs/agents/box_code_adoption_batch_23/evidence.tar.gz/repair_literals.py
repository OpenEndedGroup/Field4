from pathlib import Path
import json,re
h=Path('dev_docs/agents/box_code_adoption_batch_23');rows=json.loads((h/'changes.json').read_text());p=Path('public/docs/fline_examples.md')
def fix(s):
 for old,new in [
 ('lines(handles + [curve] + pts,','val curveLines: List<FLine> = [curve]\nlines(handles + curveLines + pts,'),
 ('lines(endDirs + [f],','val baseLine: List<FLine> = [f]\nlines(endDirs + baseLine,'),
 ('lines(dots + [loose, tight],','val curves: List<FLine> = [loose, tight]\nlines(dots + curves,'),
 ('threeLines([path, coil],','threeLines(path, coil,')]:
  assert old in s;s=s.replace(old,new)
 pattern=r'val comparison =\s*panels \+\s*(\[[\s\S]*?\])\s*\n\s*lines\(comparison,'
 s,n=re.subn(pattern,lambda m:'val alignedLines: List<FLine> = '+m[1]+'\nval comparison = panels + alignedLines\n\nlines(comparison,',s);assert n==1
 pattern=r'data\(\s*format = "m c\+ z",\s*parameters = (\[[\s\S]*?\]),?\s*\)'
 s,n=re.subn(pattern,lambda m:'val petalPoints: List<Vec3> = '+m[1]+'\n    data(format = "m c+ z", parameters = petalPoints)',s);assert n==1
 return s
p.write_text(fix(p.read_text()));rows[0]['after']=fix(rows[0]['after']);(h/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
