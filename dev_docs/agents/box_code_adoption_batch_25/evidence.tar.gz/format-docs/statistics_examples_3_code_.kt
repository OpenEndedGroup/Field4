val n = 400
val x = DoubleArray(n) { it / (n - 1.0) * 2.0 - 1.0 }
val rng = java.util.Random(7)
val noise = DoubleArray(n) { rng.nextGaussian() }
val y = DoubleArray(n) { (0.05 + abs(x[it])) * noise[it] } // the growing-spread panel again

val observedDcor = StatsDependence.distanceCorrelation(x, y)
val observedXi = StatsDependence.xi(x, y)

// The null: break the pairing, keep both marginals. Anything left is chance.
val prng = java.util.Random(31)
val reps = 400
val order = (0 until n).toMutableList()
val nullDcor = DoubleArray(reps)
val nullXi = DoubleArray(reps)
for (r in 0 until reps) {
    order.shuffle(prng)
    val shuffled = DoubleArray(n) { y[order[it]] }
    nullDcor[r] = StatsDependence.distanceCorrelation(x, shuffled)
    nullXi[r] = StatsDependence.xi(x, shuffled)
}
val sortedD = nullDcor.sortedArray()
val p95 = sortedD[(reps * 0.95).toInt()]
val exceed = sortedD.count { it >= observedDcor }
val xiExceed = nullXi.count { it >= observedXi }

// How large does dCor have to be before it means anything? Measure the null's 95th percentile
// against n, and against a fitted 2.5/sqrt(n).
val sizes = [25, 50, 100, 150, 200, 300, 400]
val thresholds = sizes.map { m ->
    val r2 = java.util.Random(1234)
    val k = 150
    val v =
        DoubleArray(k) {
                StatsDependence.distanceCorrelation(
                    DoubleArray(m) { r2.nextGaussian() },
                    DoubleArray(m) { r2.nextGaussian() },
                )
            }
            .sortedArray()
    v[(k * 0.95).toInt()]
}
val fitted = sizes.map { 2.5 / sqrt(it.toDouble()) }
// Plotted against 1/sqrt(n) rather than n: it turns the claim into a straight line through the
// origin, which is a much stronger thing to see than a hyperbola.
val inverseRootN = sizes.map { 1.0 / sqrt(it.toDouble()) }
/* BOX_CODE_FOLD_0 */
val hist = buildHistogram(nullDcor.toList())
showSignals(
    "dCor over $reps random re-pairings" to hist.bins.map { it.count },
    x = hist.bins.map { (it.start + it.end) / 2.0 },
    channel = "null at n=400",
    title = "The null distribution of dCor, and where the observed value sits",
    xTitle = "distance correlation",
    yTitle = "count",
    marks = [
        "null 95th pct = ${"%.3f".format(p95)}" to p95,
        "observed = ${"%.3f".format(observedDcor)}" to observedDcor,
    ],
)
showSignals(
    "measured 95th pct of the dCor null" to thresholds,
    "2.5 / sqrt(n)" to fitted,
    x = inverseRootN,
    channel = "threshold vs n",
    title = "How big dCor has to be to mean anything: proportional to 1/sqrt(n)",
    xTitle = "1 / sqrt(n)   (n=400 left, n=25 right)",
    yTitle = "dCor",
)
markdown(
    "verdict",
    """
    {muted:observed dCor = ${"%.4f".format(observedDcor)}; null mean ${"%.4f".format(nullDcor.average())},
    95th pct ${"%.4f".format(p95)}, max ${"%.4f".format(sortedD.last())};
    re-pairings reaching the observed value: $exceed / $reps}

    {muted:observed xi = ${"%.4f".format(observedXi)}; xi null 95th pct
    ${"%.4f".format(nullXi.sortedArray()[(reps * 0.95).toInt()])};
    re-pairings reaching it: $xiExceed / $reps}

    {muted:null 95th pct vs n (measured / 2.5-over-root-n):
    ${sizes.indices.joinToString(" · ") { "n=${sizes[it]} ${"%.3f".format(thresholds[it])}/${"%.3f".format(fitted[it])}" }}}
""",
    width = 900,
)/* BOX_CODE_FOLD_1 */
