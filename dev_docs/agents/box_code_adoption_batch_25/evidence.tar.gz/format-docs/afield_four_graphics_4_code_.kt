var module = moduleHere()
var m = Mesh()

module += m named "mainMesh"
renderer += module

val camera = Camera()
m.p = camera.p
m.m = camera.m

m.set(3, 1) {
    val z = 0.0
    pos.add(0, 0, 0 + z, 1.0, 0.1, z, 1, 1, z)
    tri.add(0, 1, 2)
}

var kc by keyCamera(camera = camera)
