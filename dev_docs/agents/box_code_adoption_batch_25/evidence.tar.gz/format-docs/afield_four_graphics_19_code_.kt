var module = moduleHere { primitiveType = triangles }

var m = Mesh()
module += m named "someMesh"
renderer += module

var vertexData = defaultBuffer {
    perFrame = true
    size = 3.vec4s
}
    .buffer

m.vertexData = { vertexData }

vertexData.write {
    put(vec(0, 0, 0))
    put(vec(1, 0, 0))
    put(vec(0, 1, 0))
}

m.resize(3)
