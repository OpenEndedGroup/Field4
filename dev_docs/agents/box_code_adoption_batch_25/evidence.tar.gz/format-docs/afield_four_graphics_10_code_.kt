var (module, meshes) = gltfModelHere("glTF-Sample-Models/2.0/Box/glTF/Box.gltf")

var m = Mesh()

module += "let's go" to m
renderer += "boo" to module

val camera = Camera()
camera.p.orthoness = 0.3
camera.p.matchDepth = 2.0

KeyCamera(camera = camera)
meshes[0].meshes[0].applyToMesh(m, camera)

camera.at = vec(0, 0, -10)
camera.p()

loop {
    module.VertexData.modelView = meshes[0].meshes[0].modelView(camera)
    module.VertexData.proj = camera.p()
    frame()
}
