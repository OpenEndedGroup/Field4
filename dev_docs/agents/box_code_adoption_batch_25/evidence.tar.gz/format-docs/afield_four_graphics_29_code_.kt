// The transcript built the renderer, the fluid and the cylinder and launched them;
// this waits for the wake to start shedding and captures the window.
