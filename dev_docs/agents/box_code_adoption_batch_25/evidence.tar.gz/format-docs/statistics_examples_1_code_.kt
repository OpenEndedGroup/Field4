val rng = java.util.Random(11)
val skewed = (0 until 500).map { exp(0.6 * rng.nextGaussian()) }

// Two clean modes, 4 apart, each with sd 0.4 — the case the rule handles worst.
val rng2 = java.util.Random(23)
val bimodal =
    (0 until 500).map { if (it % 2 == 0) -2.0 + 0.4 * rng2.nextGaussian() else 2.0 + 0.4 * rng2.nextGaussian() }

/*
Re-derive the three candidate widths from the public stats and predict the bin count.
This shares `quantileSorted` with the implementation, so it checks the *rule selection and the
rounding* — not the quantiles themselves. Those are checked against SciPy in jvmTest instead.
*/
fun explain(name: String, values: List<Double>): String {
    val s = buildSummaryStats(values)
    val n = s.count
    val range = s.max - s.min
    val cubeRootN = n.toDouble().pow(-1.0 / 3.0)
    val hFd = 2.0 * s.iqr * cubeRootN // Freedman-Diaconis
    val hScott = 3.5 * s.sampleStdDev * cubeRootN // Scott
    val kSturges = ceil(ln(n.toDouble()) / ln(2.0) + 1.0).toInt() // Sturges
    val hSturges = range / kSturges
    val winner = minOf(hFd, hScott, hSturges)
    val which = when (winner) {
        hFd -> "Freedman-Diaconis"
        hScott -> "Scott"
        else -> "Sturges"
    }
    val predicted = Math.round(range / winner).toInt().coerceIn(1, 2000)
    val actual = buildHistogram(values)
    return "$name: FD=${"%.4f".format(hFd)}  Scott=${"%.4f".format(hScott)}  " +
        "Sturges=${"%.4f".format(hSturges)} (k=$kSturges) -> $which wins; " +
        "predicted ${predicted} bins of ${"%.5f".format(range / predicted)}, " +
        "got ${actual.bins.size} of ${"%.5f".format(actual.binWidth)}; counts sum to ${actual.count}"
}

val skewedNote = explain("skewed", skewed)
val bimodalNote = explain("bimodal", bimodal)
/* BOX_CODE_FOLD_0 */
val svgs = [
    histogramToSvg(
        buildHistogram(skewed),
        widthPx = 470,
        heightPx = 270,
        padTop = 26,
        title = "exp(0.6 g), n=500",
        decimals = 3,
    ),
    histogramToSvg(
        buildHistogram(bimodal),
        widthPx = 470,
        heightPx = 270,
        padTop = 26,
        title = "two modes at -2 and +2, n=500",
        decimals = 3,
    ),
]
showRow("histograms", svgs)
markdown(
    "the rule, re-derived",
    """
    {muted:$skewedNote}

    {muted:$bimodalNote}
""",
    width = 960,
)/* BOX_CODE_FOLD_1 */
