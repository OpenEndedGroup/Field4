// A right-skewed signal by construction: exp of a Gaussian, so we know the shape we are asking about.
val rng = java.util.Random(11)
val signal = (0 until 500).map { exp(0.6 * rng.nextGaussian()) }

val buf = SummaryStatsBuffer(maxSize = 500)
buf.addAll(signal)
buf.add(Double.NaN) // dropped, and counted, at `add` time
buf.add(Double.POSITIVE_INFINITY) // likewise: `values` never holds a non-finite number

val s = buf.snapshot()

/*
Three things the card reports that are easy to misread, pinned here as arithmetic:
 - MAD is the *median absolute deviation from the median*, unscaled. For a normal sample it is
   about 0.6745 sigma, not sigma; here the signal is skewed, so it is smaller than the IQR/2.
 - `range` is max - min, which for a skewed signal is dominated by the single largest sample.
 - `cv` is sampleStdDev / mean, so it is meaningless the moment the mean crosses zero.
*/
val madOverIqr = s.mad / s.iqr
val note =
    "n=${s.count}, dropped=${s.droppedCount}; " +
        "median=${"%.3f".format(s.median)}  mean=${"%.3f".format(s.mean)} (mean > median: right-skewed); " +
        "MAD=${"%.3f".format(s.mad)} = ${"%.3f".format(madOverIqr)} x IQR; " +
        "skew=${"%.3f".format(s.skewness)}  excess kurtosis=${"%.3f".format(s.kurtosisExcess)}"
/* BOX_CODE_FOLD_0 */
display("card", buf.summaryHtml(widthPx = 620, chartHeightPx = 150, decimals = 3))
markdown("read this off the card", "{muted:$note}", width = 620)/* BOX_CODE_FOLD_1 */
