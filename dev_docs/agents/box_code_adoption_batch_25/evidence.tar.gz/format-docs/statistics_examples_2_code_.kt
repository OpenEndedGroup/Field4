val n = 400
val rng = java.util.Random(7)
val x = DoubleArray(n) { it / (n - 1.0) * 2.0 - 1.0 } // an even sweep of -1..1
val noise = DoubleArray(n) { rng.nextGaussian() } // ONE noise draw, reused, so the
// "independent" panel is literally
// the noise the others are built on
val cases = [
    "linear" to DoubleArray(n) { 0.8 * x[it] + 0.25 * noise[it] },
    "monotone, curved" to DoubleArray(n) { exp(3.0 * x[it]) },
    "parabola" to DoubleArray(n) { x[it] * x[it] },
    "sine, 3 cycles" to DoubleArray(n) { sin(3.0 * PI * x[it]) },
    "same mean, growing spread" to DoubleArray(n) { (0.05 + abs(x[it])) * noise[it] },
    "independent" to DoubleArray(n) { noise[it] },
]

fun coefficients(y: DoubleArray): String {
    val d = "%.3f"
    return "r=${d.format(StatsDependence.pearson(x, y))}   " +
        "rho=${d.format(StatsDependence.spearman(x, y))}   " +
        "tau=${d.format(StatsDependence.kendallTauB(x, y))}   " +
        "xi=${d.format(StatsDependence.xi(x, y))}   " +
        "dCor=${d.format(StatsDependence.distanceCorrelation(x, y))}   " +
        "MIC~=${d.format(StatsDependence.micTicNaive(x, y).mic)}"
}

/* BOX_CODE_FOLD_0 */
/*
Each panel is min-max rescaled into the unit square so the six share one window; SVG y grows
downward, so flip it to read the shapes the way the formulas are written.

Two columns because three panels this wide do not fit the capture, and the panels are worth
more here than a third column would be. A caption longer than `cellWidth` now wraps inside the
card instead of widening it out of frame — that used to cost you a whole column.
*/
val window = Rect(0.0, 0.0, 1.0, 1.0)
val frame = window.toFLine(color = vec(0.35, 0.44, 0.56, 0.5), thickness = 1.0)

val panels = cases.map { (name, y) ->
    val lo = y.min()
    val hi = y.max()
    val span = (hi - lo).takeIf { it > 1e-12 } ?: 1.0
    val cloud = pointCloudFLine(
        (0 until n).map { i -> vec((x[i] + 1.0) / 2.0, 1.0 - (y[i] - lo) / span) },
        color = vec(0.48, 0.85, 1.0, 0.8),
        pointSize = 1.1,
    )
    "$name\n${coefficients(y)}" to [frame, cloud]
}

showPlaneGrid(
    *panels.toTypedArray(),
    columns = 2,
    cellWidth = 430,
    cellHeight = 262,
    window = window,
)/* BOX_CODE_FOLD_1 */
