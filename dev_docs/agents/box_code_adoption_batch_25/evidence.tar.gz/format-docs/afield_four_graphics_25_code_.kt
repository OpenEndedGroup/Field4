var bml = ShaderBmlSystem() {
    width = 512
    height = 512
    density = 0.32f
}
bml.installInto()
