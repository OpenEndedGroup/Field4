var bml = ShaderBmlSystem() {
    width = 512
    height = 512
    density = 0.32f
    probe = "float(p.x + p.y)"
}
bml.installInto()

fieldProbeHere(samples = 4096).display("probe")
displayOpen("probe")
