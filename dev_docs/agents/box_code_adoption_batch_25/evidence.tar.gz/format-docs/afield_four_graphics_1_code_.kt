var module = moduleHere { primitiveType = triangles }
var m = Mesh()
module += m named "someMesh"
renderer += module

var vertexData = defaultBuffer {
    perFrame = true
    size = 9.vec4s
}
    .buffer

m.vertexData = { vertexData }

vertexData.write {
    put(vec(-0.8, -0.6, 0.0, 1.0))
    put(vec(-0.2, -0.6, 0.0, 1.0))
    put(vec(-0.5, 0.2, 0.0, 1.0))

    put(vec(-0.1, -0.4, 0.0, 1.0))
    put(vec(0.5, -0.4, 0.0, 1.0))
    put(vec(0.2, 0.5, 0.0, 1.0))

    put(vec(0.2, -0.8, 0.0, 1.0))
    put(vec(0.8, -0.8, 0.0, 1.0))
    put(vec(0.5, 0.0, 0.0, 1.0))
}

m.resize(9)
