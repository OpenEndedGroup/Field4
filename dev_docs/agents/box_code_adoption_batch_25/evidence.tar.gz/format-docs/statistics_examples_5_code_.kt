val rng = java.util.Random(5)
val fit = DoubleArray(4000) { exp(rng.nextGaussian()) } // log-normal: violently right-skewed
val held = DoubleArray(4000) { exp(rng.nextGaussian()) } // a second, disjoint draw

val warp = AdaptiveQuantileWarp() // target: UnitNormal, 8 knots
val state = warp.update(fit)

val warped = held.map { state.evaluate(it) }
val before = buildSummaryStats(held.toList())
val after = buildSummaryStats(warped)

/*
An independent oracle for the 8-knot fit: the *exact* warp onto a unit normal is
Phi^-1(Fhat(v)), the inverse normal CDF of the empirical CDF of the fitting sample. Nothing in
`quantilewarp.kt` computes that, so comparing against it tests the PCHIP interpolation itself.
*/
val sortedFit = fit.sortedArray()
fun empiricalCdf(v: Double): Double {
    var lo = 0
    var hi = sortedFit.size
    while (lo < hi) {
        val mid = (lo + hi) / 2
        if (sortedFit[mid] <= v) lo = mid + 1 else hi = mid
    }
    return lo / sortedFit.size.toDouble()
}

val probes = (2..98).map { it / 100.0 }
val inputs = probes.map { sortedFit[(it * (sortedFit.size - 1)).toInt()] }
val pchip = inputs.map { state.evaluate(it) }
val exact = inputs.map { inverseStandardNormalCdf(empiricalCdf(it).coerceIn(1e-4, 1.0 - 1e-4)) }
val worst = pchip.indices.maxOf { abs(pchip[it] - exact[it]) }
/* BOX_CODE_FOLD_0 */
showSignals(
    "8-knot PCHIP warp" to pchip,
    "exact inverse-normal of the empirical CDF" to exact,
    x = probes,
    channel = "the fitted curve",
    title = "The warp, against the exact answer it is approximating",
    xTitle = "quantile of the fitting sample",
    yTitle = "warped value",
)
val svgs = [
    histogramToSvg(
        buildHistogram(held.toList()),
        widthPx = 460,
        heightPx = 250,
        padTop = 26,
        decimals = 2,
        title = "held-out input: skew ${"%.1f".format(before.skewness)}",
    ),
    histogramToSvg(
        buildHistogram(warped),
        widthPx = 460,
        heightPx = 250,
        padTop = 26,
        decimals = 2,
        title = "after the warp: skew ${"%.3f".format(after.skewness)}",
    ),
]
showRow("distributions", svgs)
// before/after over the same four moments: a table says it in a quarter of the characters.
markdown(
    "numbers",
    """
    | held-out | mean | sd | skew | excess kurtosis |
    |----------|------|----|------|-----------------|
    | before | ${"%.3f".format(before.mean)} | ${"%.3f".format(before.sampleStdDev)} | ${"%.3f".format(before.skewness)} | ${"%.1f".format(before.kurtosisExcess)} |
    | after | ${"%.4f".format(after.mean)} | ${"%.4f".format(after.sampleStdDev)} | ${"%.4f".format(after.skewness)} | ${"%.4f".format(after.kurtosisExcess)} |

    {muted:input knots: ${state.inputKnots.joinToString { "%.3f".format(it) }}}

    {muted:target knots: ${state.targetKnots.joinToString { "%.3f".format(it) }}}

    {muted:worst |PCHIP - exact| over the 2nd..98th percentile: ${"%.4f".format(worst)}}
""",
    width = 900,
)/* BOX_CODE_FOLD_1 */
