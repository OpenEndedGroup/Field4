var m = Mesh()
var module = moduleHere()

module += "mainMesh" to m
renderer += module

val camera = Camera()
camera.at = vec(-8, 2, 7)

module.view.m = camera.m()
module.view.p = camera.p()

for (n in 1..80) {
    m.set(3 * n, 1 * n) {
        n {
            val z = 0.0 + it
            pos.add(0, 0, -1 + z, 1.0, 0.1, z, 1, 1, z)
            3 {
                col.add(10 - it * 0, it / 3.0, 1 - it / 3.0, 1)
            }
            tri.add(0 + 3 * it, 1 + 3 * it, 2 + 3 * it)
        }
    }
}
