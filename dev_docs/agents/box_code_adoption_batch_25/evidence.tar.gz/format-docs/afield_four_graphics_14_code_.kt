prop<HasImageView>(bbc) = target.thisImageView
