// The transcript built the renderer, the forest and the fire starter and launched them;
// this waits for the two trains of rings to fill the forest and captures the window.
