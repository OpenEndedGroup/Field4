import afield.media.stream.FieldRTTStreamer
import org.lwjgl.vulkan.VK10.*

// Streamer allocates + imports the surface and hands back the RTT to render into.

prop<FieldRTTStreamer>(streamer)
once.streamer {
    FieldRTTStreamer(renderer, dest = "127.0.0.1:9001", width = 1280, height = 720, fps = 15)
}

prop<RenderToTexture>(target) = streamer.start().first()

renderer.renderList += "target" to target

var module = moduleHere { target.apply() }
var m = Mesh()
module += "mainMesh" to m
target += "boo" to module
