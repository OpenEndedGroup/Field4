from pathlib import Path
import json,re
H=Path('dev_docs/agents/box_code_adoption_batch_25');rows=[]
def edit(path,ids,fn):
 p=Path(path);before=p.read_text();after=fn(before);assert after!=before;rows.append(dict(path=path,before=before,after=after,findingIds=ids));p.write_text(after)
def ramp(s):return re.sub(r'return\s*\(a\s*%\s*b\)\s*/\s*\(b\s*-\s*1\);','// Divide as floats so the ramp includes intermediate channel values.\n    return float(a % b) / float(b - 1);',s)
edit('public/docs/afield_four_graphics.md',['02b566216ca7-04'],ramp)
for i,name in enumerate(['65bd0587-dbfa-451a-8f6a-e003ff3d1abf','af0946dd-f25d-4355-984d-f0d24a43ee12','81f27655-7d32-4a4d-b73d-1b5d368efaa7']):edit('public/docs/assets/canonical_graphics/'+name+'_vertex_.glsl',['25f85b04108e-04'] if i==0 else [],ramp)
def chirp(s):
 s=s.replace('val n = 8000                     // 1 s','''val n = 8000                     // 1 s
val duration = n / sampleRate.toDouble()
val startHz = 200.0
val endHz = 2000.0
val chirpRate = (endHz - startHz) / duration''')
 s=s.replace('''    val t = i / sampleRate
    val f = 200f + 1800f * (i.toFloat() / n)     // sweep 200 -> 2000 Hz
    var s = 0.6f * sin(2.0 * PI * f * t).toFloat() + 0.25f * sin(2.0 * PI * 900.0 * t).toFloat()''','''    val t = i / sampleRate.toDouble()
    // Integrate frequency: the phase derivative is startHz + chirpRate * t.
    val phase = 2.0 * PI * (startHz * t + 0.5 * chirpRate * t * t)
    var s = 0.6f * sin(phase).toFloat() + 0.25f * sin(2.0 * PI * 900.0 * t).toFloat()''')
 return s
edit('public/docs/spectral_examples.md',['559c80d8da0a-01'],chirp)
def stats(s):
 a=s.index('// The threshold that makes the traces readable:');b=s.index('// The incremental sums',a)
 s=s[:a]+'''// Calibrate each statistic against its own null distribution at this window size.
// These are pointwise reference levels, not a multiple-testing-adjusted change detector.
val r2 = java.util.Random(1234)
val k = 300
val dNull = DoubleArray(k)
val xiNull = DoubleArray(k)
repeat(k) { i ->
    val nx = DoubleArray(w) { r2.nextGaussian() }
    val ny = DoubleArray(w) { r2.nextGaussian() }
    dNull[i] = StatsDependence.distanceCorrelation(nx, ny)
    xiNull[i] = StatsDependence.chatterjeeXi(nx, ny)
}
val threshold = dNull.sortedArray()[(k * 0.95).toInt()]
val xiThreshold = xiNull.sortedArray()[(k * 0.95).toInt()]

'''+s[b:]
 s=s.replace('xiSeries[it] > threshold','xiSeries[it] > xiThreshold')
 s=s.replace('val firstXi = (change until total).firstOrNull { xiSeries[it] > xiThreshold }','''val firstXi = (change until total).firstOrNull { xiSeries[it] > xiThreshold }
val dCrossing = firstD?.let { "+${it - change} samples" } ?: "not crossed"
val xiCrossing = firstXi?.let { "+${it - change} samples" } ?: "not crossed"''')
 s=s.replace('"dCor null 95th pct at w=$w" to List(total) { threshold },','"dCor null 95th pct at w=$w" to List(total) { threshold },\n    "xi null 95th pct at w=$w" to List(total) { xiThreshold },')
 s=s.replace('''    {muted:threshold ${"%.3f".format(threshold)} first crossed by dCor at +${firstD!! - change} samples,
    by xi at +${firstXi!! - change}}''','''    {muted:dCor null 95th pct ${"%.3f".format(threshold)}: $dCrossing.
    xi null 95th pct ${"%.3f".format(xiThreshold)}: $xiCrossing.}''')
 a=s.index('Both dependence measures cross the w=80 null threshold');b=s.index('The last line of that figure',a)
 s=s[:a]+'''Each dependence measure is compared with its **own** null distribution at w=80. The
pointwise 95th-percentile levels describe independent Gaussian windows, and the figure reports
the first crossings for this seeded recording. Overlapping windows are correlated; these are
not multiple-testing-adjusted change alarms, and their first crossings do not establish a
general latency winner. Both settled dependence averages rise clearly after the change.
Rolling `|pearson|` still swings across much the same range before and after it: a small-window
absolute correlation has a positive noise floor, so reading it against zero would mislead.

'''+s[b:]
 s=s.replace('dCor and xi both climb clear of the null threshold and stay there','dCor and xi rise against their separately calibrated pointwise null reference levels')
 return s
edit('public/docs/statistics_examples.md',['e70830985ea4-01'],stats)
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(H.parent/'box_code_adoption_batch_23'/name).read_text().replace('adoption-23','adoption-25').replace("'b833dec3b'","'6ef67f560'")
 if name=='verify.py':s=s.replace("elif p.suffix=='.yaml':", "elif p.suffix=='.glsl':compare(expected,actual,'fragment')\n elif p.suffix=='.yaml':")
 (H/name).write_text(s)
