val notes = mutableListOf<TimedNote>()
val spread0 = spreadOf(from)
for (k in 0 until 32) {
    val t = if (k < 16) k / 15.0 else (31 - k) / 15.0 // out to the heart, then back
    val midi = 72 + 12 * log2(spreadOf(morphBetween(from, partner, t)) / spread0)
    notes += TimedNote(k * 0.25, k * 0.25 + 0.25, midi)
}
val audio = patRenderStereo(
    patTimed(notes, beats = 8.0),
    cycles = 2,
    cps = 0.25,
    voice = patVoice(wave = PatWave.TRIANGLE, decay = 0.004, sustain = 0.6),
)
