syncToProperty("gain", 0.5, min = 0.0, max = 2.0)

val gain = getPropertyRaw("gain") as Double
