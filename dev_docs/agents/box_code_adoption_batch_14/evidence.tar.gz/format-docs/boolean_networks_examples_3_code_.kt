data class RhythmCandidate(val seed: Int, val net: BooleanNetwork, val attr: Attractor, val score: Double)

fun activity(attr: Attractor, net: BooleanNetwork): Double =
    attr.cycle.sumOf { state -> state.count { it } }.toDouble() / (attr.period * net.size).toDouble()

val candidate =
    (0..240)
        .mapNotNull { seed ->
            val net = kauffmanNetwork(n = 5, k = 2, seed = seed.toLong())
            net.findAttractors()
                .filter { it.period in 5..10 }
                .map { attr ->
                    val density = activity(attr, net)
                    val periodScore = 1.0 - kotlin.math.abs(attr.period - 8) / 8.0
                    val densityScore = 1.0 - kotlin.math.abs(density - 0.42)
                    val basinScore = attr.basin.size.toDouble() / (1 shl net.size).toDouble()
                    RhythmCandidate(seed, net, attr, periodScore * 1.6 + densityScore * 1.2 + basinScore)
                }
                .maxByOrNull { it.score }
        }
        .maxByOrNull { it.score }!!

val natural = candidate.attr.repeatedCycle(16)
val gated = natural.mapIndexed { step, state ->
    booleanArrayOf(
        state[0] && step % 4 == 0,
        state[1] && step % 4 == 2,
        state[2] && step % 2 == 0,
        state[3] && (step % 8 == 4 || step % 8 == 12),
        state[4] && (step % 4 == 1 || step % 4 == 3),
    )
}

/* BOX_CODE_FOLD_0 */
fun shift(lines: List<FLine>, dx: Double, dy: Double) = lines.map { it + vec(dx, dy, 0) }

fun panel(x: Double, y: Double, w: Double, h: Double, color: Vec4) = fline {
    rect(x, y, w, h)
    filled = true
    stroked = true
    thickness = 1.0
    this.color = color
}

/* BOX_CODE_FOLD_1 */

lines(
    [
        panel(30.0, 40.0, 280.0, 420.0, vec(0.08, 0.13, 0.18, 0.56)),
        panel(350.0, 40.0, 470.0, 420.0, vec(0.10, 0.10, 0.14, 0.56)),
        panel(860.0, 40.0, 470.0, 420.0, vec(0.16, 0.11, 0.08, 0.54)),
    ] +
        shift(candidate.net.drawNetworkGraph(radius = 96.0, nodeR = 17.0), 76.0, 118.0) +
        shift(
            drawRhythmGrid(natural, cellW = 21.0, cellH = 22.0, stepGap = 5.0, laneGap = 9.0, accentEvery = 4),
            390.0,
            150.0,
        ) +
        shift(
            drawRhythmGrid(gated, cellW = 21.0, cellH = 22.0, stepGap = 5.0, laneGap = 9.0, accentEvery = 4),
            900.0,
            150.0,
        ),
    channel = "boolean-rhythm",
    w = 1380.0,
    h = 520.0,
    fitToSize = true,
)
