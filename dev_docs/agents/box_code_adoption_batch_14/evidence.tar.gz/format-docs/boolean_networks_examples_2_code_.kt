data class SweepRow(val k: Int, val attractors: Double, val period: Double, val fixed: Double)

val rows =
    (1..5).map { k ->
        val runs =
            (0 until 18).map { seed ->
                val attrs = kauffmanNetwork(n = 8, k = k, seed = seed.toLong()).findAttractors()
                Triple(
                    attrs.size.toDouble(),
                    if (attrs.isEmpty()) 0.0 else attrs.map { it.period.toDouble() }.average(),
                    attrs.count { it.period == 1 }.toDouble(),
                )
            }
        SweepRow(
            k = k,
            attractors = runs.map { it.first }.average(),
            period = runs.map { it.second }.average(),
            fixed = runs.map { it.third }.average(),
        )
    }

/* BOX_CODE_FOLD_0 */
val maxY =
    [
            rows.maxOf { it.attractors },
            rows.maxOf { it.period },
            rows.maxOf { it.fixed },
        ]
        .max() + 0.5

fun guides() = [
    fline {
        moveTo(80, 580)
        lineTo(1100, 580)
        moveTo(80, 120)
        lineTo(80, 580)
        color = vec(1, 1, 1, 0.22)
        thickness = 1.1
    },
    fline {
        for (i in 0..8) {
            val y = 580.0 - i / 8.0 * 430.0
            moveTo(80, y)
            lineTo(1100, y)
        }
        for (i in rows.indices) {
            val x = 80.0 + i.toDouble() / (rows.size - 1).coerceAtLeast(1).toDouble() * 1020.0
            moveTo(x, 120.0)
            lineTo(x, 580.0)
        }
        color = vec(1, 1, 1, 0.08)
        thickness = 1.0
    },
]

fun curve(values: List<Double>, color: Vec4, thickness: Double): FLine = fline {
    breakNext()
    values.forEachIndexed { i, value ->
        val x = 80.0 + i.toDouble() / (values.size - 1).coerceAtLeast(1).toDouble() * 1020.0
        val y = 580.0 - value / maxY * 430.0
        lineTo(x, y)
    }
    this.color = color
    this.thickness = thickness
}

fun markers(values: List<Double>, color: Vec4, size: Double): FLine = fline {
    filled = true
    stroked = false
    values.forEachIndexed { i, value ->
        val x = 80.0 + i.toDouble() / (values.size - 1).coerceAtLeast(1).toDouble() * 1020.0
        val y = 580.0 - value / maxY * 430.0
        rect(x - size, y - size, 2 * size, 2 * size)
    }
    this.color = color
}

/* BOX_CODE_FOLD_1 */

lines(
    guides() +
        [
            curve(rows.map { it.attractors }, vec(0.56, 0.92, 1.0, 0.95), 3.0),
            curve(rows.map { it.period }, vec(1.0, 0.74, 0.38, 0.92), 3.0),
            curve(rows.map { it.fixed }, vec(0.58, 1.0, 0.68, 0.92), 3.0),
            markers(rows.map { it.attractors }, vec(0.56, 0.92, 1.0, 0.95), 5.0),
            markers(rows.map { it.period }, vec(1.0, 0.74, 0.38, 0.92), 5.0),
            markers(rows.map { it.fixed }, vec(0.58, 1.0, 0.68, 0.92), 5.0),
        ],
    channel = "boolean-kauffman",
    w = 1180.0,
    h = 660.0,
    fitToSize = true,
)
