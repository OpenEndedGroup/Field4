val mine = notation.strokes.filter { it.handDrawn }.takeLast(2)
notation.edit(mine[0]) { name = "from" }
notation.edit(mine[1]) { name = "to" }
