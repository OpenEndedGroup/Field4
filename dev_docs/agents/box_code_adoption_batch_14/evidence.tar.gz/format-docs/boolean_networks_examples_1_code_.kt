val net = segmentPolarityNetwork()
val attrs = net.findAttractors().sortedByDescending { it.basin.size }
val largest = attrs.first()
val cycleStates = largest.cycle.map { net.stateToInt(it) }.toSet()
val start = largest.basin.firstOrNull { it !in cycleStates } ?: largest.basin.first()
val trajectory = net.trajectoryUntilCycle(net.intToState(start))
val shown = attrs.take(2)

/* BOX_CODE_FOLD_0 */
fun shift(lines: List<FLine>, dx: Double, dy: Double) = lines.map { it + vec(dx, dy, 0) }

fun panel(x: Double, y: Double, w: Double, h: Double, color: Vec4) = fline {
    rect(x, y, w, h)
    filled = true
    stroked = true
    thickness = 1.0
    this.color = color
}

/* BOX_CODE_FOLD_1 */

lines(
    [
        panel(30.0, 40.0, 220.0, 420.0, vec(0.08, 0.13, 0.18, 0.56)),
        panel(290.0, 40.0, 380.0, 420.0, vec(0.10, 0.10, 0.14, 0.56)),
        panel(710.0, 40.0, 620.0, 420.0, vec(0.16, 0.11, 0.08, 0.54)),
    ] +
        shift(net.drawUnrolled(trajectory, cellSize = 34.0), 72.0, 128.0) +
        shift(net.drawStateTransitionGraph(radius = 125.0), 347.0, 83.0) +
        shift(net.drawAttractorBasins(shown, samplesPerAttractor = 3, cellSize = 18.0), 724.0, 154.0),
    channel = "boolean-segment",
    w = 1360.0,
    h = 520.0,
    fitToSize = true,
)
