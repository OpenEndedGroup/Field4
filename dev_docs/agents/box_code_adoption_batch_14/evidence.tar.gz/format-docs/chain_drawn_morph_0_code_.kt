notation { morphShapes() }
val drawnFrom = notation.named("from")!!.points
val drawnTo = notation.named("to")!!.points
val from = drawnFrom.resampleByLength(240, closed = true)
val to = drawnTo.resampleByLength(240, closed = true)
val match = matchPoints(from, to)
val partner = match.reorder(to)

/* BOX_CODE_FOLD_0 */
fun chord(a: Vec2, b: Vec2, dx: Double) = FLine().moveTo(a.x + dx, a.y).lineTo(b.x + dx, b.y).also {
    it.thickness = 0.8
    it.color = okhsl(atan2(a.y - 260.0, a.x - 520.0) * 180 / PI + 360, 0.85, 0.6, 0.9)
}
lines(
    from.indices.map { chord(from[it], partner[it], -220.0) } + from.indices.map { chord(from[it], to[it], 220.0) },
    w = 760.0,
    h = 380.0,
    fitToSize = true,
)
val byIndex =
    from.indices.sumOf { (from[it].x - to[it].x).toDouble().pow(2) + (from[it].y - to[it].y).toDouble().pow(2) }
markdown(
    "travel",
    """
| | |
|---|---|
| points drawn, circle and heart | ${drawnFrom.size} and ${drawnTo.size} |
| points after resampling | ${from.size} and ${to.size} |
| squared travel, matched (left) | ${"%.0f".format(match.squaredCost)} |
| squared travel, by list index (right) | ${"%.0f".format(byIndex)} |
""",
    width = 420,
)/* BOX_CODE_FOLD_1 */
