notation { morphShapes() }
val from = notation.named("from")!!.points.resampleByLength(240, closed = true)
val to = notation.named("to")!!.points.resampleByLength(240, closed = true)
val matched = DrawnMorphDocs.morphNotes(from, matchPoints(from, to).reorder(to)) // the loop above
val byIndex = DrawnMorphDocs.morphNotes(from, to)
notation.clear()

showSignals(
    "matched" to matched.map { it.note },
    "by list index" to byIndex.map { it.note },
    title = "pitch per step",
    xTitle = "step",
    yTitle = "MIDI",
    channel = "pitch",
)
markdown(
    "dips",
    "lowest note, matched: %.2f  \nlowest note, by list index: %.2f"
        .format(matched.minOf { it.note }, byIndex.minOf { it.note }),
    width = 400,
)
