val net = toggleNetwork()
val attrs = net.findAttractors()

/* BOX_CODE_FOLD_0 */
fun shift(lines: List<FLine>, dx: Double, dy: Double) = lines.map { it + vec(dx, dy, 0) }

fun panel(x: Double, y: Double, w: Double, h: Double, color: Vec4) = fline {
    rect(x, y, w, h)
    filled = true
    stroked = true
    thickness = 1.0
    this.color = color
}

/* BOX_CODE_FOLD_1 */

lines(
    [
        panel(30.0, 40.0, 430.0, 430.0, vec(0.08, 0.13, 0.18, 0.56)),
        panel(500.0, 40.0, 500.0, 430.0, vec(0.16, 0.11, 0.08, 0.54)),
    ] +
        shift(net.drawNetworkGraph(radius = 120.0, nodeR = 18.0), 80.0, 80.0) +
        shift(net.drawStateTransitionGraph(radius = 150.0), 560.0, 55.0),
    channel = "boolean-toggle",
    w = 1060.0,
    h = 520.0,
    fitToSize = true,
)
