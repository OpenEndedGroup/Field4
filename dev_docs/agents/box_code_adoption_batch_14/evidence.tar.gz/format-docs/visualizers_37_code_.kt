// One viewer, three sources, one timeline: a decaying 220 Hz ping.
val sync = "one-viewer"
val rate = 8_000
val ping = { t: Double -> sin(2 * PI * 220 * t) * exp(-2.5 * t) }

// 1. Fn.plot: the envelope, samples embedded in the page (resampled live when you zoom in).
with(Functions) {
    fn(0.0..2.0, "envelope  exp(-2.5 t)") { t -> exp(-2.5 * t) }.plot("envelope", syncGroup = sync, xLabel = "seconds")
}

// 2. displayAudioSamples: the ping itself, playable; click to seek.
displayAudioSamples(
    FloatArray(2 * rate) { ping(it / rate.toDouble()).toFloat() },
    rate,
    channel = "audio",
    label = "the ping, as audio",
    options = AudioVisualizerOptions(width = 760, syncGroup = sync),
)

// 3. displaySignal: the same ping evaluated per visible window on the server.
displaySignal(
    SignalViewer([SignalChannel("ping", ping, -1.0, 1.0)], 0.0, 2.0, sampleStep = 1.0 / rate),
    "signal",
    SignalViewerOptions(
        width = 760,
        label = "the ping, evaluated per window",
        syncGroup = sync,
        viewKey = "one-viewer:signal",
    ),
)
