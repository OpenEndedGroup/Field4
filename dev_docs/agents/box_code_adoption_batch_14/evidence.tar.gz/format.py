from pathlib import Path
import json,importlib.util,subprocess,sys
ROOT=Path.cwd();HERE=ROOT/'dev_docs/agents/box_code_adoption_batch_14';OUT=ROOT/'build/box-code-revision/adoption-14'
rows=json.loads((HERE/'changes.json').read_text());paths=[r['path'] for r in rows]
subprocess.run([sys.executable,str(HERE.parent/'box_code_adoption_batch_6/literals.py'),*paths],check=True)
subprocess.run([str(ROOT/'gradlew'),'formatBoxCode','--args=--imports '+' '.join(p for p in paths if p.endswith('.yaml'))],check=True)
spec=importlib.util.spec_from_file_location('complete_docs14',HERE.parent/'box_code_adoption_batch_7/format_docs.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.OUT=OUT/'format-docs';m.HERE=m.OUT/'input';m.HERE.mkdir(parents=True,exist_ok=True)
(m.HERE/'comment_changes.json').write_text(json.dumps([{'path':p} for p in paths if p.endswith('.md')]))
m.main()
