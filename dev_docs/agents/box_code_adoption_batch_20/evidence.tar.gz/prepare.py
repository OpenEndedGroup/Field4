from pathlib import Path
import json
h=Path('dev_docs/agents/box_code_adoption_batch_20');rows=[]
def edit(path,ids,fn):
 p=Path(path);before=p.read_text();after=fn(before);assert after!=before;rows.append(dict(path=path,before=before,after=after,findingIds=ids));p.write_text(after)
base='dev_docs/agents/demos/'
edit(base+'optical_flow/example.kt',['df987c0112a5-01'],lambda s:s.replace('lab.dx=if(deform)0f else 12f;lab.dy=if(deform)0f else -8f;lab.displayRange=if(deform)3f else 20f;lab.gain=gain;lab.damping=damping;lab.costThreshold=cost;lab.deformation=deform','''// Pixel displacement for the translation check; wiggle supplies its own motion.
        lab.dx = if (deform) 0f else 12f
        lab.dy = if (deform) 0f else -8f
        lab.displayRange = if (deform) 3f else 20f
        lab.gain = gain
        lab.damping = damping
        lab.costThreshold = cost
        lab.deformation = deform''').replace('lab.update(time,reset);reset=false;time+=lab.pairStep','lab.update(time, reset)\n        reset = false\n        time += lab.pairStep'))
edit(base+'ray_reconstruction/example.kt',['d55fb0a37340-01'],lambda s:s.replace('lab.animate=animate;lab.cameraMotion=camera','lab.animate = animate\n        lab.cameraMotion = camera').replace('if(cut){lab.time+=4;lab.reset("live cut");cut=false}','''if (cut) {
            lab.time += 4
            lab.reset("live cut")
            cut = false
        }'''))
edit(base+'gpu_shader_learning/example.kt',['d9dc73469897-01'],lambda s:s.replace('var iterations=8','''var iterations=8
val trainingSampleCount = 13
val previewAngularStep = 0.018f''').replace('lab.learning=learn;lab.iterationsPerFrame=iterations;lab.view=view','''lab.learning = learn
        lab.iterationsPerFrame = iterations
        lab.view = view''').replace('lab.parameter=if(learn)(phase%13)/6f-1 else kotlin.math.sin(phase*.018f)','''// Train across both endpoints of [-1, 1]; preview moves smoothly through that range.
        lab.parameter = if (learn) {
            (phase % trainingSampleCount) / ((trainingSampleCount - 1) / 2f) - 1
        } else {
            kotlin.math.sin(phase * previewAngularStep)
        }'''))
edit('dev_docs/agents/tool-pool/tools.kt',['12be272acb49-01','12be272acb49-02'],lambda s:s.replace('val poolOwner=Box.context.get()!!','// Tool actions run later; retain the provider box for ownership checks.\nval poolOwner = thisBox'))
edit(base+'optical_flow_pingpong/example.kt',['3d9b91c39265-01'],lambda s:s.replace('// Fully qualified: prop<T> finds T\'s import in a classpath index that lists classes, not interfaces.\n','').replace('prop<afield.media.vision.OpticalFlowOperation>(flow)','prop<OpticalFlowOperation>(flow)'))
edit(base+'frame_history_reprojection/rp_bundle_code_.kt',['c69d11328023-01'],lambda s:s[s.index('import afield.graphics.scene.fabricated.StandardRenderer'):].replace('prop<afield.graphics.scene.fabricated.StandardRenderer.Bundle>(bundle)','prop<StandardRenderer.Bundle>(bundle)').replace('prop<MutableList<afield.graphics.scene.fabricated.StandardRenderer.Bundle.PullingMeshPair>>(balls)','prop<MutableList<StandardRenderer.Bundle.PullingMeshPair>>(balls)'))
(h/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(h.parent/'box_code_adoption_batch_18'/name).read_text().replace('adoption-18','adoption-20').replace("'a9d60a2fd'","'68c5d6fa3'");(h/name).write_text(s)
print(len(rows),'sources',sum(len(r['findingIds']) for r in rows),'findings')
