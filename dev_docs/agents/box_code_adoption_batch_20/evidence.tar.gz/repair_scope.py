from pathlib import Path
import json,yaml
H=Path('dev_docs/agents/box_code_adoption_batch_20');row=next(r for r in json.loads((H/'changes.json').read_text()) if r['path'].endswith('build.yaml'));p=Path(row['path']);before=row['before'];actual=p.read_text()
def codes(text):
 result=[]
 def visit(n):
  if isinstance(n,yaml.MappingNode):
   for k,v in n.value:
    if k.value=='code' and isinstance(v,yaml.ScalarNode):result.append(v)
    else:visit(v)
  elif isinstance(n,yaml.SequenceNode):
   for v in n.value:visit(v)
 visit(yaml.compose(text));return result
old=codes(before);new=codes(actual);assert len(old)==len(new)==4
for a,b in reversed(list(zip(old,new))):
 if 'prop<afield.graphics.scene.fabricated.StandardRenderer.Bundle>(bundle)' not in a.value:
  actual=actual[:b.start_mark.index]+before[a.start_mark.index:a.end_mark.index]+actual[b.end_mark.index:]
p.write_text(actual)
assert [x.value for x in codes(actual)][::2]==[x.value for x in old][::2]
print('restored three neighboring builder bodies to their baseline')
