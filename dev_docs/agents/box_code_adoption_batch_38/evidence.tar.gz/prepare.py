from pathlib import Path
import json,re,sys
H=Path('dev_docs/agents/box_code_adoption_batch_38');p=Path('public/docs/functions_examples.md');before=p.read_text();after=before
# Rectangles keep the authored coordinates/styles while using the existing closed-path helper.
a=r'moveTo\(x0, y0\)\s*lineTo\(x1, y0\)\s*lineTo\(x1, y1\)\s*lineTo\(x0, y1\)\s*lineTo\(x0, y0\)'
after,n=re.subn(a,'rect(x0, y0, x1 - x0, y1 - y0)',after);assert n==9,n
for a,b,expected in [(r'moveTo\(120.0, 60.0\)\s*lineTo\(880.0, 60.0\)\s*lineTo\(880.0, 440.0\)\s*lineTo\(120.0, 440.0\)\s*lineTo\(120.0, 60.0\)','rect(120.0, 60.0, 760.0, 380.0)',2),(r'moveTo\(40.0, 50.0\)\s*lineTo\(940.0, 50.0\)\s*lineTo\(940.0, 390.0\)\s*lineTo\(40.0, 390.0\)\s*lineTo\(40.0, 50.0\)','rect(40.0, 50.0, 900.0, 340.0)',2)]:
 after,n=re.subn(a,b,after);assert n==expected,n
pattern=r'    val xFn =\s*\(radial \* cos\(frequency = 0.0, phase = 0.0, amplitude = 1.0, offset = 0.0, domain = tDomain\)\).mapY \{ _ -> 0.0 \}\n\n'
after,n=re.subn(pattern,'',after);assert n==1,n
# breakNext makes the first sample a move, keeping sample order and every coordinate unchanged.
after=after.replace('val f = FLine()\n        for (i in 0 until samples)', 'val f = FLine()\n        f.breakNext()\n        for (i in 0 until samples)').replace('if (i == 0) f.moveTo(x, y) else f.lineTo(x, y)','f.lineTo(x, y)')
after=after.replace('val line = FLine()\n    val samples = 1800','val line = FLine()\n    line.breakNext()\n    val samples = 1800').replace('if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)','line.lineTo(x, y)')
a=r'        val n = 220\n        for \(i in 0..n\) \{\n            val a = i.toDouble\(\) / n.toDouble\(\) \* Math.PI \* 2.0\n            val x = cx \+ kotlin.math.cos\(a\) \* 210.0\n            val y = cy \+ kotlin.math.sin\(a\) \* 210.0\n            if \(i == 0\) moveTo\(x, y\) else lineTo\(x, y\)\n        \}'
after,n=re.subn(a,'        circle(cx, cy, 210.0, segments = 220)',after);assert n==1,n
old='    f.withName("toFLine source").plot()';new='''    line.color = vec(0.62, 0.95, 1.0, 1.0)
    line.thickness = 2.0
    lines(line, channel = "converted", w = 1040.0, h = 440.0, fitToSize = false)''';assert after.count(old)==1;after=after.replace(old,new)
for source,points,label,old in [('f','pts','samples','    f.withName("samplesAt source").plot()'),('source','peaks','peaks','    source.withName("samplePeaks source").plot()')]:
 new=f'''    val curve = {source}.toFLine(samples = 600, xScale = 980.0, yScale = 170.0, xOffset = 30.0, yOffset = 220.0)
    curve.color = vec(0.62, 0.95, 1.0, 0.7)
    val markers = {points}.map {{ sample ->
        fline {{
            circle(30.0 + sample.x * 980.0, 220.0 + sample.y * 170.0, 4.0)
            color = vec(1.0, 0.75, 0.4, 1.0)
            filled = true
            stroked = false
        }}
    }}
    lines(curve, *markers.toTypedArray(), channel = "{label}", w = 1040.0, h = 440.0, fitToSize = false)
    markdown("notes", "${{{points}.size}} {'local maxima, ranked by absolute value' if points=='peaks' else 'samples at the requested coordinates'} are marked on the source curve.")'''
 assert after.count(old)==1;after=after.replace(old,new)
p.write_text(after);(H/'changes.json').write_text(json.dumps([dict(path=str(p),findings=['17291ebbeb49-01','17291ebbeb49-02','17291ebbeb49-04'],before=before,after=after)],indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(H.parent/'box_code_adoption_batch_33'/name).read_text().replace('adoption-33','adoption-38').replace('ac1bd079c','ae3d87d5b');(H/name).write_text(s)
