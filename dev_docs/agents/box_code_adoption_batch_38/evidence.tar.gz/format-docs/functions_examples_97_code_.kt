val f = sin(2.0).sampleHold(0.05)
