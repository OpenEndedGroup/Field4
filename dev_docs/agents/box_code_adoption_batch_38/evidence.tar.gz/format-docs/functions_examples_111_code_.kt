val f = sin(3.0) / gain(0.5)
