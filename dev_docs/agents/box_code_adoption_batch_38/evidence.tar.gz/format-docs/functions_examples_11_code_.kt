val shaped = hannWindow(0.0..0.8)
val relabeled = hannWindow() over (0.0..0.8)
