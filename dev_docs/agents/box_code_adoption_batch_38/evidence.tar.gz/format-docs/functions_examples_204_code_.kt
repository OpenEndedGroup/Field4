val ys = sin(2.0).cursor().next(16)
