val x = d.lerp(0.25) // → 0.25 (a quarter across 0..1)
