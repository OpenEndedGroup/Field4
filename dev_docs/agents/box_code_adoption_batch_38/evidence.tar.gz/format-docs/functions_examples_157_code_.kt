val phrase = [sin(2.0), saw(0.12), square(0.18)].sequence(overlap = 0.05)
