val f = sin(2.0).scaleY(0.5).offsetY(0.2)
