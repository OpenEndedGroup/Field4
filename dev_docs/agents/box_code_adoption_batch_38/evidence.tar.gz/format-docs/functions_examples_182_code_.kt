val a = 0.0..1.0
val b = sin(5, domain = 0..1)
