val f = ramp(0.0, 1.0).reverse()
