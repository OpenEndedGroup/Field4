val phrase = (sin(2.0) over (0.0..1.0)) then (saw(0.15) over (0.0..1.0))
