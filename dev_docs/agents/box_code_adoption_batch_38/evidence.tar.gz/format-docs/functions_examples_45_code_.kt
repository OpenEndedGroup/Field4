val f = cos(frequency = 2.0, amplitude = 1.0)
