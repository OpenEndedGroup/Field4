with(Functions) {
    val delayed = timelineGraph {
        saw(0.2).place()
    }
        .tap(offset = 0.12, name = "echoTap")
    delayed.plot()
}
