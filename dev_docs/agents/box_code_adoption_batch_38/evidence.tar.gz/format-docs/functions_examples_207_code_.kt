with(Functions) {
    val ch = Functions.TimelineChunk(
        fbm(2, 2.0, 0.5),
        sourceDomain = 0.0..1.0,
        domain = 1.0..2.0,
        mapMode = Functions.ChunkMapMode.WRAP,
        window = hannWindow(0.0..1.0),
    )
    val on = ch.contains(1.35)
    val f = fn(1.0..2.0, "chunk sample") { x -> ch.sampleAt(x) ?: 0.0 }
    f.plot()
}
