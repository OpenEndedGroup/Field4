with(Functions) {
    val f =
        fbm(9, 2.0, 1.0)
            .convolve(
                gaussianWindow(-0.06..0.06, sigma = 0.3),
                samples = 41,
                kernelDomain = -0.06..0.06,
                normalize = true,
            )
            .blur(0.01, samples = 31)
    f.plot()
}
