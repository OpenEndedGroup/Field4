val sm = valueNoise(3, 14.0, 1.0).movingAverage(0.08, samples = 64)
