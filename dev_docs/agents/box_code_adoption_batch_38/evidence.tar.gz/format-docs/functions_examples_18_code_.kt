with(Functions) {
    // Push a rising ramp through each shaper: what comes out is the shape it imposes.
    val sweep = ramp(-1.5, 1.5) over Functions.Domain.of(0.0, 1.0)

    /* BOX_CODE_FOLD_0 */
    val x0 = 40.0
    val x1 = 940.0
    val y0 = 30.0
    val y1 = 410.0
    val lo = -1.7
    val hi = 1.7
    val yScale = -(y1 - y0) / (hi - lo)
    val zeroY = y1 + lo * (y1 - y0) / (hi - lo)
    fun curve(fn: Functions.Fn, color: Vec4, thickness: Double, dashed: Boolean = false): List<FLine> {
        val line = fn.toFLine(0.0..1.0, samples = 600, xScale = x1 - x0, yScale = yScale, xOffset = x0, yOffset = zeroY)
        val parts = if (dashed) line.byDashing(10f, 7f) else [line]
        return parts.onEach {
            it.color = color
            it.thickness = thickness
        }
    }
    val guides = [
        fline {
            rect(x0, y0, x1 - x0, y1 - y0)
            color = vec(1.0, 1.0, 1.0, 0.28)
            thickness = 1.6
        },
        fline {
            moveTo(x0, zeroY)
            lineTo(x1, zeroY)
            color = vec(1.0, 1.0, 1.0, 0.30)
            thickness = 1.2
        },
    ]
    val orange = vec(0.97, 0.45, 0.18, 1.0)
    val cyan = vec(0.30, 0.79, 0.94, 1.0)
    val grey = vec(0.6, 0.6, 0.6, 1.0)
    val violet = vec(0.66, 0.50, 0.98, 1.0)
    val green = vec(0.45, 0.85, 0.45, 1.0)
    val pink = vec(0.96, 0.45, 0.72, 1.0)
    /* BOX_CODE_FOLD_1 */

    lines(
        guides +
            curve(sweep, grey, 2.0, dashed = true) +
            curve(sweep.fold(0.7), cyan, 2.4) +
            curve(sweep.softClip(2.5), orange, 2.4) +
            curve(sweep.chebyshev(3), violet, 2.4) +
            curve(sweep.rectify(Functions.RectifyMode.FULL), green, 2.4),
        channel = "transfer",
        w = 980.0,
        h = 440.0,
        fitToSize = false,
    )
    markdown(
        "notes",
        "**transfer curves over a -1.5..1.5 sweep**: input ramp (grey, dashed), fold(0.7) (cyan), " +
            "softClip(2.5) (orange), chebyshev(3) (violet), rectify(FULL) (green)",
    )
}
