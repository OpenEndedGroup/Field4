val r = ramp(0.0, 1.0)
