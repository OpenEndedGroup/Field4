with(Functions) {
    val f = piecewise(
        default = valueNoise(3, 8.0, 0.1),
        0.0..0.33 to sin(3.0),
        0.33..0.66 to saw(0.2),
        0.66..1.0 to pulseTrain(0.1),
    )
    f.plot()
}
