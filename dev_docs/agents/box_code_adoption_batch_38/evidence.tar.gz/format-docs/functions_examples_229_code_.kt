with(Functions) {
    val i = RbfInterpolator(
        points(0.0 to 0.0, 0.2 to 0.9, 0.9 to -0.2),
        RbfKernels.gaussian(3.0),
        smoothing = 1e-4,
        base = sin(1.0),
    )
    val y = i.eval(0.63)
    val f = fn(name = "rbf interpolator") { x -> i.eval(x) }
    f.plot()
}
