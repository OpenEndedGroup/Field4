val f = pulseTrain(period = 0.2, duty = 0.35)
