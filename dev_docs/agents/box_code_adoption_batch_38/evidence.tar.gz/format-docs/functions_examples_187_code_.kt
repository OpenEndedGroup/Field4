val band = d.expand(0.2).shrink(0.05) // → Domain(-0.15..1.15)
