val f = sin(2.0).saturate(1.0)
