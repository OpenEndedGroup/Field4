with(Functions) {
    val f = [sin(2.0), saw(0.12), pulseTrain(0.08)].weightedSequence(
        [0.6, ramp(0.1, 0.35), 0.15],
        seed = 7,
        overlap = ramp(0.02, 0.08),
    ) over (0.0..10.0)
    f.plot()
}
