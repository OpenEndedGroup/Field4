val f = [sin(2.0), saw(0.2)].sequenceLoop() over (0.0..8.0)
