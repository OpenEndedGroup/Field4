with(Functions) {
    val x0 = 40.0
    val x1 = 940.0
    val y0 = 40.0
    val y1 = 400.0
    val midY = 220.0
    val amp = 150.0

    /*
    Adversarial setup: the target is a half-amplitude sine; the seed is a
    full-amplitude COSINE — the wrong op AND the wrong amplitude. A good run must
    both substitute the op and dial in the numeric leaves. Fixed rngSeed = 3L, so
    the run — and this figure — reproduces exactly.
    */
    val target = sin(frequency = 1.0, amplitude = 0.5)
    val seed = cos(frequency = 1.0, amplitude = 1.0)
    val run = evolve(
        seed = seed,
        iterations = 120,
        lambda = 8,
        rngSeed = 3L,
        fitness = matchFitness(target, samples = 160, complexityWeight = 0.01),
    )

    fun asLine(fn: Functions.Fn, color: Vec4, thickness: Double): FLine = fn.toFLine(0.0..1.0, samples = 160, xScale = x1 - x0, yScale = -amp, xOffset = x0, yOffset = midY).apply {
        this.color = color
        this.thickness = thickness
    }
    fun hLine(y: Double, color: Vec4, thickness: Double): FLine = fline {
        moveTo(x0, y)
        lineTo(x1, y)
        this.color = color
        this.thickness = thickness
    }
    val frame = fline {
        rect(x0, y0, x1 - x0, y1 - y0)
        color = vec(1.0, 1.0, 1.0, 0.28)
        thickness = 1.6
    }

    val guides = [frame, hLine(midY, vec(1.0, 1.0, 1.0, 0.30), 1.2)]
    val seedLine = asLine(seed, vec(0.55, 0.55, 0.55, 0.9), 2.0) // grey: where it started
    val targetLine = asLine(target, vec(0.84, 0.15, 0.16, 1.0), 4.5) // red: the target
    val bestLine = asLine(run.best, vec(0.12, 0.47, 0.71, 1.0), 2.4) // blue: evolved best, on top

    lines(
        guides + seedLine + targetLine + bestLine,
        channel = "evolve-overlay",
        w = 980.0,
        h = 440.0,
        fitToSize = false,
    )
    markdown(
        "notes",
        "**evolve** — seed cosine (grey) → target sine (red); the evolved best (blue) tracks the target. score ${"%.4f".format(run.initialScore)} → ${"%.4f".format(run.bestScore)}",
    )
    run
}
