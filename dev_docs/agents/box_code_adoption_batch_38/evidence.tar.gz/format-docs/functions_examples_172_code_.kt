val f = sin(3.0) / copyPaste(0.1..0.3, 0.7..0.9)
