val pts = points(0.0 to 0.0, 0.4 to 1.0, 1.0 to 0.2)
