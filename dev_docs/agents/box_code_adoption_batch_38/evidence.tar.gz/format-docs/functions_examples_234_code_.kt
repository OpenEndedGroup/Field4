with(Functions) {
    val base = sin(sin(saw(0.25))).withName("nested carrier")
    val changed =
        base.rewriteKotlin(
            """
#fnrewrite
sin/*/saw => op=triangle
sin/**/[tag=number][value>0.2] => = 0.5
""",
        )

    /* BOX_CODE_FOLD_0 */
    // The two graphs are stacked, not side by side — the original grid was a single column.
    markdown(
        "graph",
        """
        #### before
        ${base.graphSvg(width = 1060, nodeWidth = 186.0, nodeHeight = 52.0, xGap = 200.0, yGap = 70.0, maxDepth = 5)}

        #### after
        ${changed.graphSvg(width = 1060, nodeWidth = 186.0, nodeHeight = 52.0, xGap = 200.0, yGap = 70.0, maxDepth = 5)}
    """,
        width = 1120,
    )
    /* BOX_CODE_FOLD_1 */
}
