val merged = d.union(domain(-0.3..0.3)).intersect(domain(-0.1..0.9)) // → Domain(-0.1..0.9)
