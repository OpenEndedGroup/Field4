val y = sin(2.0).eval(0.5)
