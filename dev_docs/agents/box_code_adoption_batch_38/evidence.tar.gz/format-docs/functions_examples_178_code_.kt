val s = sin(2.0).lowpassStream(alpha = 0.2).take(64).toList()
