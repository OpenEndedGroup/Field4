val first = sin(2.0).stream(start = 0.0, step = 0.01).take(8).toList()
