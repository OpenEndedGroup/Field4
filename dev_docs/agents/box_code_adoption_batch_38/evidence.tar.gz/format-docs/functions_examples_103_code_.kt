val f = sin(2.0).repeat(0.25, 0.0)
