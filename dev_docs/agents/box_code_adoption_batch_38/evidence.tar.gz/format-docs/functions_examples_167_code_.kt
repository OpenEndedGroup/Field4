val f = (ramp(-2.0, 2.0) over (0.0..1.0)) / fold(0.7)
