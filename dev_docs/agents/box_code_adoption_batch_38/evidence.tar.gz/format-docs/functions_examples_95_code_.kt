val f = sin(2.0).window(hannWindow())
