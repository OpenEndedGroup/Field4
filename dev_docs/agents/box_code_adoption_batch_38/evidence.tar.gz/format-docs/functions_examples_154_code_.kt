with(Functions) {
    val t = timeline(name = "scene") {
        mark("start")
        pulseTrain(0.12).place(duration = 0.7, mapMode = Functions.ChunkMapMode.WRAP)
        fbm(4, 3.0, 0.35).overlap(amount = 0.15, duration = 0.8, blend = ADD)
        moveToMark("start", 0.35)
        saw(0.2).splice(lookBack = 0.2, duration = 0.5)
    }
    t.plot()
}
