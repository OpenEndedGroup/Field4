val f = gaussian(mean = 0.5, sigma = 0.1, amplitude = 1.0)
