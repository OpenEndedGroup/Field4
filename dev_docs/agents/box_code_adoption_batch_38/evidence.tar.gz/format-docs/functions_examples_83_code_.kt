val f = ramp(0.0, 1.0).pow(2.0)
