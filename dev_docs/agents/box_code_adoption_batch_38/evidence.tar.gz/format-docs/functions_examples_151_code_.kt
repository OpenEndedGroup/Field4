val w = spliceWindow(fadeIn = 0.1, fadeOut = 0.1)
