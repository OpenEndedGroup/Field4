val f = timelineGraph {
    sin(2.0).place()
}
    .asFn("main")
