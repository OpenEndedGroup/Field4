val f = sin(3.0).granular(grainSize = 0.05, spacing = 0.04)
