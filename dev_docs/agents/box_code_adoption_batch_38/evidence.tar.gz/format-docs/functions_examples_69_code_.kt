val f = sin(2.0).mapY { it * 0.5 }
