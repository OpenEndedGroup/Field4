val base = sin(sin(saw(0.25)))
val changed =
    base.rewriteKotlin(
        """
#fnrewrite
sin/*/saw => op=triangle
""",
    )
