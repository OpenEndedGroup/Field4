val f = pulseTrainWidth(period = 0.2, width = 0.08)
