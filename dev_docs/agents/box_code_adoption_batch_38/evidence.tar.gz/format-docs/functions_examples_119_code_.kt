val c0 = sin(2.0).cursor(start = 0.0, step = 0.01)
