val simplified = ((sin(2.0) + 0.0) + 0.0).rewritePatterns(
    "add(?x, 0) => ?x", // additive identity, applied to a fixed point
    "multiply(?x, 1) => ?x", // multiplicative identity
)
println(simplified.function.graphNode().op) // sin
