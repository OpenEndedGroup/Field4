val n = fbm(seed = 2, frequency = 2.0, amplitude = 1.0, octaves = 5)
