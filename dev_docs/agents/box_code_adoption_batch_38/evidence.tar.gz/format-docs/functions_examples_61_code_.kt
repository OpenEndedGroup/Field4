val f = impulseTrain(period = 0.1, width = 0.01)
