val g = timelineGraph {
    one().place()
}
val cs = timeline(start = 0.0) {}.withName("empty")
