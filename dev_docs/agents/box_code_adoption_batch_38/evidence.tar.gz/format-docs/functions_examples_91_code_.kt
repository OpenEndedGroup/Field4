val f = sin(2.0).mix(saw(0.2), 0.5)
