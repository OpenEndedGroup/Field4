val f = pulseTrainHz(frequency = 8.0, duty = 0.3)
