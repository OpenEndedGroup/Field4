with(Functions) {
    val f = sin(2.0) + fbm(5, 6.0, 0.2)
    // Screen y grows downward; negate the scale so larger values appear higher.
    val line = f.toFLine(samples = 1400, xScale = 980.0, yScale = -170.0, xOffset = 30.0, yOffset = 220.0)
    line.color = vec(0.62, 0.95, 1.0, 1.0)
    line.thickness = 2.0
    lines(line, channel = "converted", w = 1040.0, h = 440.0, fitToSize = false)
}
