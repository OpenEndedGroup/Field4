with(Functions) {
    val f =
        catmullRomSpline(
                [
                    Keyframe(0.0, 0.0, "linear"),
                    Keyframe(0.2, 0.9, "linear"),
                    Keyframe(0.6, -0.4, "linear"),
                    Keyframe(1.0, 0.2, "linear"),
                ],
                alpha = 0.5,
            )
            .mix(
                monotoneCubic(
                    [Keyframe(0.0, 0.1, "linear"), Keyframe(0.4, 0.8, "linear"), Keyframe(1.0, 0.0, "linear")],
                ),
                constant(0.35),
            )
    f.plot()
}
