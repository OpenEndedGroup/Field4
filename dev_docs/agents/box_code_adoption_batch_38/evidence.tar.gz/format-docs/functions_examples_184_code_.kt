val inside = d.containsInclusive(0.2) // → true
