with(Functions) {
    val source = sin(3.0) + fbm(1, 7.0, 0.25)
    val peaks = source.samplePeaks(20)
    // Screen y grows downward; negate the scale so larger values appear higher.
    val curve = source.toFLine(samples = 600, xScale = 980.0, yScale = -170.0, xOffset = 30.0, yOffset = 220.0)
    curve.color = vec(0.62, 0.95, 1.0, 0.7)
    val markers = peaks.map { sample ->
        fline {
            circle(30.0 + sample.x * 980.0, 220.0 - sample.y * 170.0, 4.0)
            color = vec(1.0, 0.75, 0.4, 1.0)
            filled = true
            stroked = false
        }
    }
    lines(curve, *markers.toTypedArray(), channel = "peaks", w = 1040.0, h = 440.0, fitToSize = false)
    markdown("notes", "${peaks.size} local maxima, ranked by absolute value are marked on the source curve.")
}
