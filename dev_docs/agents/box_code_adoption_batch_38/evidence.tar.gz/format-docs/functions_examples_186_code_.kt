val wide = d.expand(0.1) // → Domain(-0.1..1.1)
