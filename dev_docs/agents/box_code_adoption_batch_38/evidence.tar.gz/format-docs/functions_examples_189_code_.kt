val zoom = d.scale(0.5, about = d.center).shift(0.1) // → Domain(0.35..0.85)
