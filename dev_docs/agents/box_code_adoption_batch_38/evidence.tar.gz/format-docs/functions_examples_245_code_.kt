with(Functions) {
    /*
    Same run as the harness: grow 6 behaviourally distinct gestures from one seed by
    novelty search. normalize = true measures distance in *shape*, not amplitude, so
    the set spreads across genuinely different waveforms. Fixed rngSeed = 7L.
    */
    val variety = evolveVariety(
        seed = sin(2.0) * 0.5,
        count = 6,
        iterations = 48,
        rngSeed = 7L,
        samples = 120,
        neighbours = 3,
        normalize = true,
    )

    val cols = 3
    val cellW = 300.0
    val cellH = 180.0
    val gap = 20.0
    val topPad = 44.0
    val out = mutableListOf<FLine>()

    /*
    One mini-plot per result, laid out in a grid. Plot the stored *normalized*
    behaviour (variety.behaviours[i].samples) so every cell shares one z-scored
    scale and the montage reads as pure shape variety, not "the same wave rescaled".
    */
    variety.behaviours.forEachIndexed { i, b ->
        val col = i % cols
        val row = i / cols
        val cx0 = gap + col * (cellW + gap)
        val cy0 = topPad + row * (cellH + gap)
        val cyc = cy0 + cellH / 2
        val amp = (cellH / 2 - 12) / 2.6 // z-scored signal spans roughly +/-2.6

        out += fline {
            moveTo(cx0, cy0)
            lineTo(cx0 + cellW, cy0)
            lineTo(cx0 + cellW, cy0 + cellH)
            lineTo(cx0, cy0 + cellH)
            lineTo(cx0, cy0)
            color = vec(1.0, 1.0, 1.0, 0.22)
            thickness = 1.2
        }
        out += fline {
            moveTo(cx0, cyc)
            lineTo(cx0 + cellW, cyc)
            color = vec(1.0, 1.0, 1.0, 0.18)
            thickness = 1.0
        }
        val s = b.samples
        val curve = FLine()
        for (k in s.indices) {
            val px = cx0 + 8 + (cellW - 16) * k / (s.size - 1).toDouble()
            val py = cyc - amp * s[k]
            if (k == 0) curve.moveTo(px, py) else curve.lineTo(px, py)
        }
        curve.color = vec(0.12, 0.47, 0.71, 1.0)
        curve.thickness = 2.2
        out += curve
    }

    lines(out, channel = "evolve-variety", w = 980.0, h = 440.0, fitToSize = false)
    markdown(
        "notes",
        "**evolveVariety** — ${variety.results.size} behaviourally distinct gestures from one seed, meanPairwiseDistance ${"%.3f".format(variety.meanPairwiseDistance)} (normalized shape)",
    )
    variety
}
