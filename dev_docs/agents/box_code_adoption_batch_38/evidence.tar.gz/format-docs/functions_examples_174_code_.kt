val g = timelineGraph {
    repeatToFit(sin(2.0), duration = 2.0)
}
