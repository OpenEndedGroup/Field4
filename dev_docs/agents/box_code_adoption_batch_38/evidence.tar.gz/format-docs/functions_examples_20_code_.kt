val burst = pulseBurst(10) through gain(0.6)
burst.plot("source")
