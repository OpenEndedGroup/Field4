val variety = evolveVariety(
    seed = sin(2.0) * 0.5,
    count = 6, // how many mutually-distant gestures to return
    iterations = 48,
    rngSeed = 7L, // same seed + inputs -> identical set
    neighbours = 3, // k-nearest novelty
    normalize = true, // measure distance in *shape*, not amplitude (see below)
)
println("spread = ${variety.meanPairwiseDistance}")
variety.results.forEachIndexed { i, fn -> fn.browseGraph(channel = "variety-$i") }
