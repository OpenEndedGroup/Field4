val s = step(0.5)
