val f = triangle(period = 0.2, amplitude = 0.9)
