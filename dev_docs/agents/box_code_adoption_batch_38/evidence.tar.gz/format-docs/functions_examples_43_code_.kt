val f = sin(frequency = 3.0, amplitude = 0.8)
