val s = smoothStep(0.2, 0.8)
