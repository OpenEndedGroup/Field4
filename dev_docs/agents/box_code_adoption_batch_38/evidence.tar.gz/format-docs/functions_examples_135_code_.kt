val zc = sin(6.0).sampleZeroCrossings()
