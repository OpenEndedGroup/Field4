val f = sin(2.0).quantize(8)
