val x = d.clamp(1.2) // → 1.0 (pulled back to the upper edge)
