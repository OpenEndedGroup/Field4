with(Functions) {
    val f =
        hermiteFromHandles(
                [
                    Keyframe(0.0, 0.0, "linear"),
                    Keyframe(0.3, 0.8, "linear"),
                    Keyframe(0.75, -0.2, "linear"),
                    Keyframe(1.0, 0.1, "linear"),
                ],
            )
            .softClip(constant(1.2))
    f.plot()
}
