val f = sin(2.0).shift(0.1)
