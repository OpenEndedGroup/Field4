gesture.browseRewrite(
    """
#fnrewrite
saw => op=triangle
**/[role=amplitude] => *= 0.5
""",
    channel = "rewrite",
)
