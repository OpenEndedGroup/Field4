val y = saw(0.1).evalSafe(-0.3, edge = Functions.EdgeMode.MIRROR)
