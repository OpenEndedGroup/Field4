val ys = sin(2.0).sampleAt(doubleArrayOf(0.0, 0.25, 0.5))
