val g =
    f.rewriteKotlin(
        """
#fnrewrite
sin/**/[tag=number] => *= @{1.1}
""",
    )
