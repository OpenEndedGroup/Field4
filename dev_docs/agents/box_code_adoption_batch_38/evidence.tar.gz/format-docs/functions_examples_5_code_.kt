with(Functions) {
    val tDomain = 0.0..1.0
    val cx = 500.0
    val cy = 250.0

    val xFn =
        (sin(frequency = 3.0, phase = 0.2, amplitude = 1.0, domain = tDomain) +
                sin(frequency = 9.0, phase = 1.1, amplitude = 0.18, domain = tDomain))
            .softClip(1.15)

    val yFn =
        (sin(frequency = 4.0, phase = 1.2, amplitude = 1.0, domain = tDomain) +
                valueNoise(seed = 88L, frequency = 16.0, amplitude = 0.1, domain = tDomain))
            .softClip(1.2)

    fun parametric(xf: Functions.Fn, yf: Functions.Fn, samples: Int = 1400): FLine {
        val f = FLine()
        f.breakNext()
        for (i in 0 until samples) {
            val t = tDomain.lerp(i.toDouble() / (samples - 1).coerceAtLeast(1).toDouble())
            val x = cx + xf.eval(t) * 290.0
            val y = cy + yf.eval(t) * 190.0
            f.lineTo(x, y)
        }
        return f
    }

    val frame = fline {
        rect(120.0, 60.0, 760.0, 380.0)
        color = vec(1.0, 1.0, 1.0, 0.24)
        thickness = 1.4
    }

    val cross = [
        fline {
            moveTo(120.0, cy)
            lineTo(880.0, cy)
            color = vec(1.0, 1.0, 1.0, 0.12)
            thickness = 1.0
        },
        fline {
            moveTo(cx, 60.0)
            lineTo(cx, 440.0)
            color = vec(1.0, 1.0, 1.0, 0.12)
            thickness = 1.0
        },
    ]

    val curve = parametric(xFn, yFn).apply {
        color = vec(0.98, 0.9, 0.32, 0.95)
        thickness = 2.3
    }

    lines([frame] + cross + curve, channel = "xy-parametric", w = 1000.0, h = 500.0, fitToSize = false)
    markdown("notes", "**2D parametric**\n\nx(t) and y(t) are independent Functions stacks.")
}
