val a = Functions.Domain.centered(0.5, 0.42).intersect(domain(0.0..1.0))

// → Domain(0.08..0.92)
