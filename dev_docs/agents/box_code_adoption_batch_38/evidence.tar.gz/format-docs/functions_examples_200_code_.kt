val f = sin(2.0).withName("lead")
