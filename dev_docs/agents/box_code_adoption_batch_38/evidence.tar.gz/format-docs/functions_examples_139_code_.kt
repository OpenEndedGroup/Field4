val f = piecewise(zero(), 0.0..0.5 to one(), 0.5..1.0 to zero())
