with(Functions) {
    val ch = Functions.TimelineChunk(
        saw(0.2),
        domain = 0.0..1.0,
        window = spliceWindow(0.2, 0.2, 0.0..1.0),
        gain = valueNoise(1, 4.0, 0.2),
    )
    val w = ch.weightAt(0.6)
    val f = fn(name = "chunk weight") { x -> ch.weightAt(x) }
    f.plot()
}
