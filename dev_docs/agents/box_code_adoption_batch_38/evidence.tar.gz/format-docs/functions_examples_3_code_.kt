with(Functions) {
    // The same graph structure as the target, with the wrong numbers in it: a fifth of the
    // amplitude and the offset the wrong way. One fitGradient, no restarts.
    val target = sin(frequency = 2.0, amplitude = 0.8, offset = 0.12)
    val seed = sin(frequency = 2.0, amplitude = 0.30, offset = -0.15)
    val run = fitGradient(target = target, seed = seed, iterations = 400, lr = 0.05, samples = 160, rngSeed = 0L)

    /* BOX_CODE_FOLD_0 */
    val x0 = 40.0
    val x1 = 940.0
    val y0 = 30.0
    val y1 = 410.0
    val lo = -1.1
    val hi = 1.1
    val yScale = -(y1 - y0) / (hi - lo)
    val zeroY = y1 + lo * (y1 - y0) / (hi - lo)
    fun curve(fn: Functions.Fn, color: Vec4, thickness: Double, dashed: Boolean = false): List<FLine> {
        val line = fn.toFLine(0.0..1.0, samples = 600, xScale = x1 - x0, yScale = yScale, xOffset = x0, yOffset = zeroY)
        val parts = if (dashed) line.byDashing(10f, 7f) else [line]
        return parts.onEach {
            it.color = color
            it.thickness = thickness
        }
    }
    val guides = [
        fline {
            rect(x0, y0, x1 - x0, y1 - y0)
            color = vec(1.0, 1.0, 1.0, 0.28)
            thickness = 1.6
        },
        fline {
            moveTo(x0, zeroY)
            lineTo(x1, zeroY)
            color = vec(1.0, 1.0, 1.0, 0.30)
            thickness = 1.2
        },
    ]
    val orange = vec(0.97, 0.45, 0.18, 1.0)
    val cyan = vec(0.30, 0.79, 0.94, 1.0)
    val grey = vec(0.6, 0.6, 0.6, 1.0)
    val violet = vec(0.66, 0.50, 0.98, 1.0)
    val green = vec(0.45, 0.85, 0.45, 1.0)
    val pink = vec(0.96, 0.45, 0.72, 1.0)
    /* BOX_CODE_FOLD_1 */

    lines(
        guides + curve(target, orange, 5.0) + curve(seed, grey, 2.0, dashed = true) + curve(run.fitted, cyan, 2.0),
        channel = "fit",
        w = 980.0,
        h = 440.0,
        fitToSize = false,
    )
    markdown(
        "notes",
        "**fitGradient, before and after**: target (orange), seed (grey, dashed), fitted (cyan); " +
            "error ${"%.4f".format(run.initialError)} -> ${"%.4f".format(run.finalError)}",
    )
}
