with(Functions) {
    // A ramp sweeping -2..2 across the window: plotting a shaper of it against x draws
    // that shaper's transfer curve directly — the shape it imposes on its input.
    val sweep = ramp(-2.0, 2.0) over (0.0..1.0)
    sweep.withName("input sweep -2..2").plot(channel = "sweep", title = "input: ramp -2..2", heightPx = 150)
    (sweep / fold(0.7)).plot(channel = "fold", title = "fold(0.7) — wavefolder triangle", heightPx = 150)
    (sweep / rectify(Functions.RectifyMode.FULL)).plot(
        channel = "rectFull",
        title = "rectify(FULL) — |x|",
        heightPx = 150,
    )
    (sweep / rectify(Functions.RectifyMode.HALF)).plot(
        channel = "rectHalf",
        title = "rectify(HALF) — max(0, x)",
        heightPx = 150,
    )
    (sweep / quantize(6)).plot(channel = "quant", title = "quantize(6) — staircase", heightPx = 150)
    (sweep / crush(3)).plot(channel = "crush", title = "crush(3) — bit-depth steps", heightPx = 150)
    (sweep / chebyshev(3)).plot(channel = "cheb", title = "chebyshev(3) — T₃ (clamps to [-1, 1])", heightPx = 150)
    sweep.clip(0.8).plot(channel = "clip", title = "clip(0.8) — hard rails", heightPx = 150)
    sweep.softClip(3.0).plot(channel = "soft", title = "softClip(3.0) — tanh knee", heightPx = 150)
    sweep.clamp(-0.8, 0.8).plot(channel = "clamp", title = "clamp(-0.8, 0.8)", heightPx = 150)
    sweep.wrapY(-0.8, 0.8).plot(channel = "wrap", title = "wrapY(-0.8, 0.8) — sawtooth wrap", heightPx = 150)
}
