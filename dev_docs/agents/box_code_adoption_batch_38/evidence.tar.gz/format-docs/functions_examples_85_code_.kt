val f = sin(2.0).clip(0.7)
