val sweep = ramp(-1.5, 1.5) over Functions.Domain.of(0.0, 1.0)

sweep.fold(0.7) // reflects back at the threshold
sweep.softClip(2.5) // a bounded S, smooth everywhere
sweep.chebyshev(3) // the 3rd Chebyshev polynomial
sweep.rectify(Functions.RectifyMode.FULL) // absolute value, folded about zero
