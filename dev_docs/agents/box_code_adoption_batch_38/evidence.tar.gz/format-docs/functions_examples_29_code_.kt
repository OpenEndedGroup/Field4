val f = constant(0.5)
