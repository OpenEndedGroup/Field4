val g = timelineGraph {
    sin(2.0).place()
}
val y = g.eval(0.4)
