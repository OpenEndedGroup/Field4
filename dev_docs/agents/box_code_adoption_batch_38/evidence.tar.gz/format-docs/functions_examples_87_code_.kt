val f = sin(3.0).withEdge(Functions.EdgeMode.CLAMP)
