val y = sin(2.0).evalSafe(2.0, outside = 0.0)
