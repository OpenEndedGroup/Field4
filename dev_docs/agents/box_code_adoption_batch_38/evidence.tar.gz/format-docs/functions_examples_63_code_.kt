val f = pulseBurst(count = 5, period = 0.1, start = 0.2)
