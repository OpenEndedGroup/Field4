with(Functions) {
    val f =
        Functions.TimelineBuilder(start = 0.0)
            .apply {
                sin(2.0).place()
                fbm(3, 4.0, 0.3).overlap(0.1, blend = ADD)
            }
            .build(name = "stacked")
    f.plot()
}
