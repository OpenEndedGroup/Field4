with(Functions) {
    val f =
        fbmPerlin(1, 3.0, 0.8)
            .granular(
                grainSize = 0.04,
                spacing = 0.027,
                jitter = 0.35,
                overlap = 2,
                seed = 3,
                window = gaussianWindow(0.0..1.0, 0.3),
            )
    f.plot()
}
