val slope = sin(2.0).derivative()
