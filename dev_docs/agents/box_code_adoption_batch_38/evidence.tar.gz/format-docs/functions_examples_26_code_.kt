with(Functions) {
    // examples here
}
