val i = d.intersect(domain(0.2..0.7)) // → Domain(0.2..0.7)
