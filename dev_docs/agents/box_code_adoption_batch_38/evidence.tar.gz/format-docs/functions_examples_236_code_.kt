val spec =
    """
#fnrewrite
sin/**/[tag=number] => *= @{1.0 + depth * 0.1}
"""
