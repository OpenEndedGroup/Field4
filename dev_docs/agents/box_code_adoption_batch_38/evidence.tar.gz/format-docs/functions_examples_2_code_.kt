with(Functions) {
    val x0 = 40.0
    val x1 = 940.0
    val y0 = 40.0
    val y1 = 400.0
    val midY = 220.0
    val amp = 150.0

    // A target that is awkward to hand-tune: two oscillators multiplied together.
    val target = cos(2) * sin(1.5, amplitude = 0.8, offset = 0.2)
    // Same *shape*, wrong *numbers* — both frequencies far off, which is the point.
    val seed = cos(3.4) * sin(1.0, amplitude = 2.0)

    /*
    Gradient descent with jittered restarts. A single fitGradient would stall in a
    frequency local-minimum (~0.19); fitBest escapes it. This target is unbounded,
    so fitBest falls back to the finite 0..1 sampling domain.
    */
    val run = fitBest(target, seed, restarts = 16) // RMSE ~0.72 -> ~0.006

    fun asLine(fn: Functions.Fn, color: Vec4, thickness: Double): FLine = fn.toFLine(0.0..1.0, samples = 900, xScale = x1 - x0, yScale = amp, xOffset = x0, yOffset = midY).apply {
        this.color = color
        this.thickness = thickness
    }
    fun hLine(y: Double, color: Vec4, thickness: Double): FLine = fline {
        moveTo(x0, y)
        lineTo(x1, y)
        this.color = color
        this.thickness = thickness
    }
    val frame = fline {
        rect(x0, y0, x1 - x0, y1 - y0)
        color = vec(1.0, 1.0, 1.0, 0.28)
        thickness = 1.6
    }

    val guides = [frame, hLine(midY, vec(1.0, 1.0, 1.0, 0.30), 1.2)]
    val targetLine = asLine(target, vec(0.30, 0.79, 0.94, 1.0), 4.5) // cyan, thick
    val fittedLine = asLine(run.fitted, vec(0.97, 0.45, 0.18, 1.0), 2.2) // orange, thin, on top

    lines(guides + targetLine + fittedLine, channel = "fit-graph", w = 980.0, h = 440.0, fitToSize = false)
    markdown(
        "notes",
        "**fit to target** — target (cyan) vs gradient-fitted (orange), RMSE ${"%.4f".format(run.finalError)}",
    )
    run
}
