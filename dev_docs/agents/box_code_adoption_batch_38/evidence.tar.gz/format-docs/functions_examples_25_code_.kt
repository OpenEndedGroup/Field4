with(Functions) {
    // One signal, plotted at each stage of its pipeline.
    val carrier = sin(frequency = 3.0, amplitude = 1.0)
    val envelope = ramp(0.2, 1.0) over Functions.Domain.of(0.0, 1.0)
    val stage0 = carrier * envelope
    val stage1 = stage0.fold(0.75)
    val stage2 = stage1.softClip(2.0)

    /* BOX_CODE_FOLD_0 */
    val x0 = 40.0
    val x1 = 940.0
    val y0 = 30.0
    val y1 = 410.0
    val lo = -1.3
    val hi = 1.3
    val yScale = -(y1 - y0) / (hi - lo)
    val zeroY = y1 + lo * (y1 - y0) / (hi - lo)
    fun curve(fn: Functions.Fn, color: Vec4, thickness: Double, dashed: Boolean = false): List<FLine> {
        val line = fn.toFLine(0.0..1.0, samples = 600, xScale = x1 - x0, yScale = yScale, xOffset = x0, yOffset = zeroY)
        val parts = if (dashed) line.byDashing(10f, 7f) else [line]
        return parts.onEach {
            it.color = color
            it.thickness = thickness
        }
    }
    val guides = [
        fline {
            rect(x0, y0, x1 - x0, y1 - y0)
            color = vec(1.0, 1.0, 1.0, 0.28)
            thickness = 1.6
        },
        fline {
            moveTo(x0, zeroY)
            lineTo(x1, zeroY)
            color = vec(1.0, 1.0, 1.0, 0.30)
            thickness = 1.2
        },
    ]
    val orange = vec(0.97, 0.45, 0.18, 1.0)
    val cyan = vec(0.30, 0.79, 0.94, 1.0)
    val grey = vec(0.6, 0.6, 0.6, 1.0)
    val violet = vec(0.66, 0.50, 0.98, 1.0)
    val green = vec(0.45, 0.85, 0.45, 1.0)
    val pink = vec(0.96, 0.45, 0.72, 1.0)
    /* BOX_CODE_FOLD_1 */

    lines(
        guides + curve(stage0, grey, 2.0, dashed = true) + curve(stage1, orange, 2.4) + curve(stage2, cyan, 2.4),
        channel = "stages",
        w = 980.0,
        h = 440.0,
        fitToSize = false,
    )
    markdown(
        "notes",
        "**carrier x envelope, stage by stage**: the product (grey, dashed), after fold(0.75) (orange), " +
            "after softClip(2.0) (cyan)",
    )
}
