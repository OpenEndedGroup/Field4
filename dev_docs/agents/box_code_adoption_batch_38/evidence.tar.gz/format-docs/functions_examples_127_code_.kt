val n = valueNoise(seed = 1, frequency = 12.0, amplitude = 0.5)
