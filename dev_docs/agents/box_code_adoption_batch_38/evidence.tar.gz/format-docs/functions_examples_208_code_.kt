val w = Functions.TimelineChunk(sin(2.0), domain = 0.0..1.0).weightAt(0.5)
