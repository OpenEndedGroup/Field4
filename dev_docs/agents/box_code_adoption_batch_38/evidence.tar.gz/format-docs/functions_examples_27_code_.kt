val f = fn { x -> x * x }
