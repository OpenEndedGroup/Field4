val pingPong = d.reflect(2.7) // → 0.7 (folded back into 0..1)
