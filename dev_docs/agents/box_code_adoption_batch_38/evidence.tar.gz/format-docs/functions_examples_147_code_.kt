val f = differentiate(sin(2.0))
