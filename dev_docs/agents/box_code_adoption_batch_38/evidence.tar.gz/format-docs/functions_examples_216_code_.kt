val t = timeline {
    moveTo(0.3)
    advance(0.2)
    rewind(0.1)
}
