val line = sin(2.0).toFLine(samples = 600)
