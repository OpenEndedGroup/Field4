with(Functions) {
    val f =
        gaussianSmooth(
                fromKeyframeEditor(
                    [Keyframe(0.0, 0.0, "linear"), Keyframe(0.4, 1.0, "bezier"), Keyframe(1.0, 0.1, "linear")],
                ),
                sigma = 0.03,
                taps = 41,
            )
            .let { resample(it, sampleCount = 512, interpolation = CUBIC) }
    f.plot()
}
