val f = square(period = 0.25, duty = 0.5, amplitude = 1.0)
