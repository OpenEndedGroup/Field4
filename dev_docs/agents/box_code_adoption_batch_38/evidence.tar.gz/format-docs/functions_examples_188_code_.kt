val moved = d.shift(0.15) // → Domain(0.15..1.15)
