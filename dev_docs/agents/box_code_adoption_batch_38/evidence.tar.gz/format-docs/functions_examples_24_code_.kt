val tornTape = (cos(5.0) / slower(2.0) / turbulence(amount = 0.04, frequency = 11.0) / mirror()) over (0.0..4.0)
tornTape.plot("tornTape")
