val f = sin(2.0).mapX { x -> x * 0.5 }
