val f = [sin(2.0), saw(0.2) * 0.3].stack()
