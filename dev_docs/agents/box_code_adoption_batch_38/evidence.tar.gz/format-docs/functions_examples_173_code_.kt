with(Functions) {
    val f =
        (pulseTrain(0.08) /
            randomRepeat(period = ramp(0.12, 0.28), seed = 4) /
            randomCopyPaste(grain = ramp(0.04, 0.12), seed = 8, density = ramp(0.35, 0.85))) over (0.0..6.0)
    f.plot()
}
