with(Functions) {
    val tDomain = 0.0..1.0
    val cx = 500.0
    val cy = 250.0

    val radial =
        (one(tDomain) * 0.62 +
                pulseTrain(period = 0.25, duty = 0.5, profile = TRIANGLE, amplitude = 0.22, domain = tDomain) +
                valueNoise(seed = 5L, frequency = 14.0, amplitude = 0.05, domain = tDomain))
            .clamp(0.12, 1.0)

    val theta = ramp(start = 0.0, end = 1.0, domain = tDomain) * Math.PI * 2.0 * 6.0

    // Explicit x/y from radial + theta, sampled directly for clarity.
    val line = FLine()
    line.breakNext()
    val samples = 1800
    for (i in 0 until samples) {
        val t = tDomain.lerp(i.toDouble() / (samples - 1).coerceAtLeast(1).toDouble())
        val r = radial.eval(t)
        val ang = theta.eval(t)
        val x = cx + kotlin.math.cos(ang) * r * 280.0
        val y = cy + kotlin.math.sin(ang) * r * 210.0
        line.lineTo(x, y)
    }

    line.color = vec(0.62, 0.95, 1.0, 0.95)
    line.thickness = 2.0

    val frame = fline {
        rect(120.0, 60.0, 760.0, 380.0)
        color = vec(1.0, 1.0, 1.0, 0.22)
        thickness = 1.4
    }

    val ringGuide = fline {
        circle(cx, cy, 210.0, segments = 220)
        color = vec(1.0, 1.0, 1.0, 0.1)
        thickness = 1.0
    }

    lines(frame, ringGuide, line, channel = "xy-rosette", w = 1000.0, h = 500.0, fitToSize = false)
    markdown("notes", "**2D rosette**\n\nradial(t) + angle(t) stack mapped into x/y.")
}
