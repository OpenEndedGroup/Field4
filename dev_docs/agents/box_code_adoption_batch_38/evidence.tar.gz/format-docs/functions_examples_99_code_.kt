val f = sin(2.0).phaseMod(sin(8.0), 0.02)
