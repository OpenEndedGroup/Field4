val ys = sin(3.0).toDoubleArray(128)
