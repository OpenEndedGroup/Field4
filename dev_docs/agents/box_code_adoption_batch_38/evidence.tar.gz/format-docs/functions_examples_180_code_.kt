val result = demo(sampleCount = 256)
