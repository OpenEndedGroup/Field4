with(Functions) {
    val f = fbmPerlin(8, 2.0, 1.0)
    val pts = f.samplesAt(DoubleArray(32) { it / 31.0 })
    // Screen y grows downward; negate the scale so larger values appear higher.
    val curve = f.toFLine(samples = 600, xScale = 980.0, yScale = -170.0, xOffset = 30.0, yOffset = 220.0)
    curve.color = vec(0.62, 0.95, 1.0, 0.7)
    val markers = pts.map { sample ->
        fline {
            circle(30.0 + sample.x * 980.0, 220.0 - sample.y * 170.0, 4.0)
            color = vec(1.0, 0.75, 0.4, 1.0)
            filled = true
            stroked = false
        }
    }
    lines(curve, *markers.toTypedArray(), channel = "samples", w = 1040.0, h = 440.0, fitToSize = false)
    markdown("notes", "${pts.size} samples at the requested coordinates are marked on the source curve.")
}
