with(Functions) {
    val a = pulseTrain(period = 0.08, duty = 0.35, domain = 0.0..0.8)
    val b = pulseTrain(period = 0.08, duty = 0.35) over (0.0..0.8)

    a.plot(
        "a",
        domain(0.0..0.8),
        heightPx = 200,
        title = "a: pulseTrain(..., domain = 0.0..0.8)",
        yDomain = domain((-0.1)..1.1),
    )
    b.plot(
        "b",
        domain(0.0..0.8),
        heightPx = 200,
        title = "b: pulseTrain(...) over (0.0..0.8)",
        yDomain = domain((-0.1)..1.1),
    )

    (a - b).plot(
        "difference",
        domain(0.0..0.8),
        title = "a - b: construction domain - over domain",
        yDomain = domain((-0.1)..0.1),
    )
}
