val f = sin(2.0).cut(0.2..0.8)
