val s = sin(2.0).sampleUniform(32)
