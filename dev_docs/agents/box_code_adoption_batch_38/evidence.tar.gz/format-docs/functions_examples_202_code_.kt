val cur = sin(2.0).cursor(0.0, 0.01)
val y = cur.next()
