with(Functions) {
    val f =
        cosineInterp(
                [
                    Keyframe(0.0, 0.2, "linear"),
                    Keyframe(0.3, 0.9, "linear"),
                    Keyframe(0.8, -0.4, "linear"),
                    Keyframe(1.0, 0.1, "linear"),
                ],
            )
            .mix(
                smootherStepInterp(
                    [
                        Keyframe(0.0, 0.2, "linear"),
                        Keyframe(0.3, 0.9, "linear"),
                        Keyframe(0.8, -0.4, "linear"),
                        Keyframe(1.0, 0.1, "linear"),
                    ],
                ),
                constant(0.5),
            )
    f.plot()
}
