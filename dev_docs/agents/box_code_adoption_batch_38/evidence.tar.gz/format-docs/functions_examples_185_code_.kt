val mask = if (d.contains(0.77)) one() else zero() // 0.77 is inside → one()
