val sheets =
    [Paper.Rough, Paper.HotPress].map { paper ->
        val sheet = PaintCanvas.paper(420, aspect = 1.3, paper = paper, sizeMm = 120.0, seed = 5)
        for ((i, fill) in [1.0, 0.3, 0.1].withIndex()) {
            val brush =
                sheet
                    .waterBrush(90.0)
                    .load(Watercolors.burntSienna * 40.0 + Watercolors.ultramarine * 20.0, fill = fill)
            sheet.wash(
                FLine().moveTo(60, 130.0 + i * 230).lineTo(940, 130.0 + i * 230),
                brush,
                pressure = [0.3],
                speed = 200.0,
            )
        }
        sheet.dry()
    }
display("main", pngRow(sheets))
