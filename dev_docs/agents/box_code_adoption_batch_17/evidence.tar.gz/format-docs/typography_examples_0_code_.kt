val face = typeface("SansSerif", 140.0)
val word = layoutText("Handgloves", face)

// rasterizeText is a scanline fill over the contours this family extracted. Not drawString.
showImgGrid(
    "Handgloves — %d contours, %d of them counters, %.0f units wide"
        .format(word.contourCount, word.holeCount, word.advanceWidth) to rasterizeText(word, 1600, 380),
    columns = 1,
    cellSide = 900,
)
