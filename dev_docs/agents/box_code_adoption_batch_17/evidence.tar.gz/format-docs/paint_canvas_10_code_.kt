val tools = PaintToolbox()
tools["sky"] = canvas.brush(BrushKind.HogFlat, 45.0)
tools.brush("sky").load(rgb(0.45, 0.55, 0.75))
canvas.stroke(sky, tools.brush("sky"))
// later, dirty with the earth it was dragged through
canvas.stroke(horizon, tools.brush("sky"))
tools.save(file) // every bristle's paint, the knife's bead, the rag's faces
val again = PaintToolbox.load(file) // carries on exactly as the tools would have
