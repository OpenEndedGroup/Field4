with(Functions) {
    val target = cos(2) * sin(1.5, amplitude = 0.8, offset = 0.2)

    // The seed from the figure above, and the same seed rectified. Until abs became a real op the
    // second of these was refused outright, with `mapY` named as the culprit.
    val kinked = cos(1.9).abs() * sin(1.3, amplitude = 1.0)

    val fd = fitGradient(target, kinked, iterations = 400, lr = 0.05)
    val exact = fitGradient(target, kinked, iterations = 400, lr = 0.05, gradient = FnGradientMode.EXACT)
    /* BOX_CODE_FOLD_0 */
    plot(kinked, channel = "1 seed", title = "the rectified seed   cos(1.9).abs() * sin(1.3)")
    plot(exact.fitted, channel = "2 fitted", title = "fitted with exact reverse-mode gradients")
    showSignals(
        "finite differences" to fd.losses,
        "exact reverse mode" to exact.losses,
        channel = "3 loss",
        title = "RMSE per Adam step - the rectified seed",
        xTitle = "step",
        yTitle = "RMSE",
    )
    /* BOX_CODE_FOLD_1 */
    "refused now? " +
        (exactFitRefusal(target, kinked, Functions.Domain.DEFAULT) ?: "no - accepted") +
        "\n" +
        "finite differences: RMSE " +
        fd.finalError +
        " in " +
        fd.evaluations +
        " loss evaluations\n" +
        "exact reverse mode:  RMSE " +
        exact.finalError +
        " in " +
        exact.evaluations +
        " loss evaluations\n" +
        "sign is still refused: " +
        (exactFitRefusal(target, cos(1.9).sign() * sin(1.3), Functions.Domain.DEFAULT) ?: "no")
}
