fun rectBetween(x0: Double, y0: Double, x1: Double, y1: Double) = FLine().rect(x0, y0, x1 - x0, y1 - y0)

val sheet = PaintCanvas.paper(600, aspect = 1.5, paper = Paper.ColdPress, sizeMm = 150.0, seed = 6)
sheet.wet(rectBetween(100.0, 100.0, 460.0, 560.0), microns = 120.0, paint = Watercolors.ultramarine * 3.0)
sheet.wet(rectBetween(540.0, 100.0, 900.0, 560.0), microns = 120.0, paint = Watercolors.phthaloBlue * 1.0)
sheet.dry()

// scrub a band across both: wet the brush, scrub, squeeze it out, scrub again, six times
val brush = sheet.waterBrush(50.0)
val band = FLine().moveTo(150, 330).lineTo(850, 330)
repeat(6) {
    brush.load(WaterPaint.Clear, fill = 0.6)
    sheet.wash(band, brush, pressure = [0.9], speed = 120.0)
    brush.load(WaterPaint.Clear, fill = 0.05)
    sheet.wash(band, brush, pressure = [0.9], speed = 120.0)
}
sheet.dry()
display("main", sheet.png())
