val canvas = PaintCanvas(900, aspect = 1.5, sizeMm = 250.0, seed = 3)

// the underdrawing: a horizon, two hills and a tree, in pencil
val hills = FLine().moveTo(40, 380).cubicTo(250, 250, 420, 300, 560, 360).cubicTo(700, 300, 850, 280, 960, 340)
val trunk = FLine().moveTo(700, 560).lineTo(705, 380)
val crown = FLine().moveTo(705, 300).cubicTo(640, 300, 630, 400, 705, 400).cubicTo(780, 400, 770, 300, 705, 300)
val pencil = canvas.pencil("3B")
for (line in [hills, trunk, crown]) canvas.sketch(line, pencil, pressure = 0.7, passes = 2)

// thin paint over it: the pencil shows through a glaze, and is sealed in where paint covers it
val sky =
    FLine()
        .moveTo(0, 0)
        .lineTo(1000, 0)
        .lineTo(1000, 380)
        .cubicTo(850, 280, 700, 300, 560, 360)
        .cubicTo(420, 300, 250, 250, 0, 380)
        .lineTo(0, 0)
val land =
    FLine()
        .moveTo(0, 380)
        .cubicTo(250, 250, 420, 300, 560, 360)
        .cubicTo(700, 300, 850, 280, 1000, 340)
        .lineTo(1000, 667)
        .lineTo(0, 667)
        .lineTo(0, 380)
canvas.work(sky, rgb(0.55, 0.7, 0.85), Handling.Glaze, hiding = 0.25, angle = 0.0)
canvas.work(land, rgb(0.45, 0.6, 0.3), Handling.Broad, hiding = 0.35, angle = -0.2)
canvas.work(crown, rgb(0.2, 0.35, 0.15), Handling.Body, hiding = 0.6, width = 14.0)

display("main", canvas.png())
