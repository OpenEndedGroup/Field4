val chain = IkChain(vec(120.0, 300.0), doubleArrayOf(90.0, 80.0, 70.0, 55.0))
val target = vec(330.0, 150.0)
val solved = solveIk(chain, target)
val smoothed = solveIk(chain, target, options = IkOptions(smoothness = 2.0))
/* BOX_CODE_FOLD_0 */
fun marker(p: Vec2, r: Double) = fline {
    moveTo(p.x - r * 1.7, p.y)
    lineTo(p.x - r * 0.5, p.y)
    moveTo(p.x + r * 0.5, p.y)
    lineTo(p.x + r * 1.7, p.y)
    moveTo(p.x, p.y - r * 1.7)
    lineTo(p.x, p.y - r * 0.5)
    moveTo(p.x, p.y + r * 0.5)
    lineTo(p.x, p.y + r * 1.7)
    circle(p.x, p.y, r, segments = 40)
    color = vec(1.0, 0.42, 0.3, 1.0)
    thickness = 2.0
}
fun pose(line: FLine, r: Double, g: Double, b: Double) = line.apply {
    color = vec(r, g, b, 1.0)
    thickness = 3.5
    pointed = true
    pointSize = 3.0
}
val cross = marker(target, 26.0)
showPlaneGrid(
    "start pose\nall four joint angles zero" to
        [pose(chain.toFLine(DoubleArray(chain.linkCount)), 0.45, 0.55, 0.72), cross],
    "solved\nreach error " + solved.reachError + " units, " + solved.run.iterations + " L-BFGS iterations" to
        [pose(chain.toFLine(solved.angles), 0.42, 0.86, 0.58), cross],
    "smoothness = 2.0\nstraighter, and it costs " + smoothed.reachError + " units of reach" to
        [pose(chain.toFLine(smoothed.angles), 0.98, 0.86, 0.32), cross],
    columns = 3,
    cellWidth = 280,
    window = Rect(40.0, 60.0, 400.0, 320.0),
)/* BOX_CODE_FOLD_1 */
