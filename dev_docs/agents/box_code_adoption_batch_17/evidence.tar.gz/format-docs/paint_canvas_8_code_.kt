val canvas = PaintCanvas(900, aspect = 1.5, ground = PaintGround.Oil, sizeMm = 300.0, seed = 4)
val passage = FLine().rect(60, 60, 880, 540)
canvas.work(passage, rgb(0.22, 0.16, 0.12), handling = Handling.Broad, hiding = 0.7, stiff = 0.3)

val rag = canvas.rag(70.0)
canvas.wipe(FLine().moveTo(120, 170).cubicTo(350, 120, 600, 220, 880, 150), rag, [0.8])
canvas.refold(rag).dampen(rag, 0.8)
canvas.wipe(FLine().moveTo(160, 260).lineTo(840, 250), rag, [0.6])

val knife = canvas.knife(90.0).load(rgb(0.92, 0.85, 0.66), amount = 1.0)
canvas.knife(FLine().moveTo(100, 420).lineTo(900, 400), knife, pressure = 0.4..0.6)
canvas.scrape(FLine().moveTo(240, 330).lineTo(250, 520), knife.wipe())

val flick = canvas.brush(BrushKind.Round, 40.0)
flick.load(rgb(0.8, 0.2, 0.1), stiff = 0.3, turps = 0.5, part = LoadPart(side = -1.0, share = 0.5))
flick.load(rgb(0.2, 0.45, 0.8), stiff = 0.3, turps = 0.5, wipe = 0.0, part = LoadPart(side = 1.0, share = 0.5))
canvas.spatter(flick, 150.0, 540.0, toward = 600.0 to -60.0, spread = 0.3, force = 0.6)

display("main", canvas.png(wet = true, light = PaintLight.Raking))
