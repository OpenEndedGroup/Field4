val wash = FLine().rect(200, 150, 600, 450)
val sheet = PaintCanvas.paper(400, aspect = 0.75, paper = Paper.HotPress, sizeMm = 120.0, seed = 4)
sheet.tilt(15.0, 90.0)
sheet.wet(wash, microns = 60.0, paint = Watercolors.ultramarine * 2.0 + Watercolors.quinacridoneRose * 1.2)
sheet.dry()

val w = sheet.water!!
fun f(x: Double) = "%.2f".format(x)
markdown(
    """
| water, mm³ | added | evaporated | run off | on the sheet | imbalance |
| --- | --- | --- | --- | --- | --- |
| | ${f(w.addedMm3)} | ${f(w.evaporatedMm3)} | ${f(w.runoffMm3)} | ${f(w.surfaceMm3 + w.absorbedMm3)} | ${"%.1e".format(w.imbalanceMm3)} |

| pigment, µg | added | run off | glued | bound | deposited | imbalance |
| --- | --- | --- | --- | --- | --- | --- |
"""
        .trimIndent() +
        "\n" +
        w.pigments.joinToString("\n") { p ->
            "| ${p.name} | ${f(p.added)} | ${f(p.runoff)} | ${f(p.glued)} | ${f(p.bound)} | ${f(p.deposited)} | ${"%.1e".format(p.imbalance)} |"
        },
)
