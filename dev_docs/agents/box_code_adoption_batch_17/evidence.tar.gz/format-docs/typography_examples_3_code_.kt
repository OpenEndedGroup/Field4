/* BOX_CODE_FOLD_0 */
val face = typeface("SansSerif", 120.0)
val prose = wrapText(
    "Type is geometry that happens to be legible, and legibility is the one test " +
        "a plausible looking picture cannot pass.",
    face.atSize(44.0),
    maxWidth = 620.0,
)
/* BOX_CODE_FOLD_1 */

// Identity one: kerning off, no tracking — the line is the sum of its advances. Two different
// AWT paths (accumulated pen positions vs per-glyph metrics) that have to agree.
val plain = layoutText("minimum", face.withKerning(false))
val drift = plain.advanceWidth - plain.glyphs.sumOf { it.glyph.advance }

// Identity two: tracking adds one gap per INTER-GLYPH space, not one per glyph. The trailing gap
// nobody asked for is the classic off-by-one, and the advance boxes below show where it went.
val t = 0.16 * face.size
val tight = layoutText("TYPE", face)
val loose = layoutText("TYPE", face, tracking = t)

/* BOX_CODE_FOLD_2 */
// Two figures, so two CHANNELS: a second display on the same channel replaces the first.
showPlaneGrid(
    "tracking 0 — %.0f units; advanceWidth − Σadvances = %.1e".format(tight.advanceWidth, drift) to
        (tight.metricsFLines() + tight.advanceBoxFLines() + tight.toFLines(thickness = 1.0)),
    "tracking 0.16em — %.0f units, i.e. exactly %d gaps × %.1f wider"
        .format(loose.advanceWidth, tight.glyphs.size - 1, t) to
        (loose.metricsFLines() + loose.advanceBoxFLines() + loose.toFLines(thickness = 1.0)),
    channel = "metrics",
    columns = 1,
    cellWidth = 880,
    cellHeight = 240,
    window = afield.app.protocol.Rect(-20.0, -face.ascent - 20, loose.advanceWidth + 40, face.lineHeight + 40),
)
showImgGrid(
    *TextAlign.entries
        .map { a ->
            a.name.lowercase() to
                rasterizeText(layoutText(prose, face.atSize(44.0), align = a, lineSpacing = 1.12), 700, 380)
        }
        .toTypedArray(),
    channel = "alignment",
    columns = 3,
    cellSide = 290,
)/* BOX_CODE_FOLD_3 */
