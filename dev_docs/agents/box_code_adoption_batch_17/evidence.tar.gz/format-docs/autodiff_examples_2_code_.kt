with(Functions) {
    val target = cos(2) * sin(1.5, amplitude = 0.8, offset = 0.2)
    val seed = cos(1.9) * sin(1.3, amplitude = 1.0)

    val fd = fitGradient(target, seed, iterations = 400, lr = 0.05)
    val exact = fitGradient(target, seed, iterations = 400, lr = 0.05, gradient = FnGradientMode.EXACT)

    // The exact path never trusts itself: it re-checks its own interpretation against Fn.eval on the
    // loss grid before switching over. Ask it why a piecewise oscillator is refused.
    val refusal = exactFitRefusal(target, valueNoise(3L, 2.0, 0.8), Functions.Domain.DEFAULT)
    /* BOX_CODE_FOLD_0 */
    plot(target, channel = "1 target", title = "target   cos(2) * sin(1.5)")
    plot(exact.fitted, channel = "2 fitted", title = "fitted, exact reverse-mode gradients")
    showSignals(
        "finite differences" to fd.losses,
        "exact reverse mode" to exact.losses,
        channel = "3 loss",
        title = "RMSE per Adam step - same optimiser, different gradient",
        xTitle = "step",
        yTitle = "RMSE",
    )
    /*
    The refusal names every differentiable op, which is one ~700-character line. Left unwrapped it
    sets the width of the whole capture — the plots above end up small inside a very wide, mostly
    empty frame. Wrap it on comma boundaries so the figure is sized by its plots, not by its prose.
    */
    fun wrap(text: String, at: Int = 96): String {
        val out = StringBuilder()
        var column = 0
        for ((i, piece) in text.split(", ").withIndex()) {
            val token = if (i == 0) piece else ", $piece"
            if (column + token.length > at) {
                out.append(",\n     ").append(piece)
                column = 5 + piece.length
            } else {
                out.append(token)
                column += token.length
            }
        }
        return out.toString()
    }
    val numbers =
        "finite differences: RMSE " +
            fd.initialError +
            " -> " +
            fd.finalError +
            " in " +
            fd.evaluations +
            " loss evaluations\n" +
            "exact reverse mode: RMSE " +
            exact.initialError +
            " -> " +
            exact.finalError +
            " in " +
            exact.evaluations +
            " loss evaluations\n" +
            "a valueNoise seed is refused, with a reason:\n  " +
            wrap(refusal ?: "(none)")
    markdown(
        "4 numbers",
        """
        ~~~
$numbers
        ~~~
    """,
    )
    /* BOX_CODE_FOLD_1 */
}
