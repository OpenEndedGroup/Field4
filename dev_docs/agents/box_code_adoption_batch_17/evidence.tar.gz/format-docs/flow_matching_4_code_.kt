val n = 1200
val draws: List<Pair<Double, Double>> = (0 until n).map { Pair(random(), randomGaussian()) }

fun width(s: Double): Double = 3.0 + 26.0 * sin(PI * s) * sin(PI * s)
fun centre(s: Double): Vec3 = vec(240 * (s - 0.5), 70 * sin(3 * PI * s), 0.0)

// Unit normal of the centreline: the direction the width is measured along.
fun normal(s: Double): Vec3 {
    val dy = 70.0 * 3 * PI * cos(3 * PI * s)
    val len = hypot(240.0, dy)
    return vec(-dy / len, 240.0 / len, 0.0)
}

val source = draws.map { vec(240 * (it.first - 0.5), 150 + 9 * it.second, 0.0) }
val target = draws.map { (s, r) -> centre(s) + normal(s) * (width(s) * r) }

val field = flowMatch(
    target,
    source,
    options = FlowMatchOptions(steps = 8000, seed = 11, coupling = FlowCoupling.PAIRED),
)

val drift =
    [0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0].map { t ->
        val flowed = field.transport(source, to = t, steps = 64)
        val away = (0 until n).sumOf {
            val exact = source[it] * (1 - t) + target[it] * t
            hypot((flowed[it].x - exact.x).toDouble(), (flowed[it].y - exact.y).toDouble())
        } / n
        "  %.2f   %14.2f   %10.2f%%".format(t, away, 100 * away / 240.0)
    }
/* BOX_CODE_FOLD_0 */
val every = source.indices.filter { it % 16 == 0 }
val exact = every.map { i ->
    fline {
        moveTo(source[i])
        lineTo(target[i])
        color = vec(0.88, 0.64, 0.33, 0.7)
        thickness = 1.0
    }
}
val flown = field.pathsFrom(every.map { source[it] }, steps = 48).map {
    it.color = vec(0.44, 0.83, 0.78, 0.8)
    it.thickness = 0.9
    it
}

lines(exact + flown, w = 1000.0, h = 400.0, fitToSize = true)
markdown(
    "drift",
    """
    ~~~
how far the integrated path is from the exact straight line

     t   mean deviation   of a 240-unit extent
${drift.joinToString("\n")}
    ~~~
""",
)/* BOX_CODE_FOLD_1 */
