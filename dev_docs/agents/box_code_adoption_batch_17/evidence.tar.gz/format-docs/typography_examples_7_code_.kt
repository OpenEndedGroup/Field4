val layout = layoutText("SDF", typeface("SansSerif", 170.0))
val sdf = layout.toSdf(depth = 0.24, gridResolution = 340)

// Once the letters are a field, the whole SDF family applies to them unchanged — which is the
// entire reason for this bridge existing.
val marched = sdf.march(resolution = 130)
val melted = marchingCubes(sdfSmoothUnion(sdf.field, sdfSphere(0.6, vec(0.0, 0.0, 0.0)), 0.18), sdf.bounds, 130)
val hollow = marchingCubes(sdf.field.shell(0.02), sdf.bounds, 150)
val wrung = marchingCubes(sdf.field.twisted(0.5), sdf.bounds, 130)

/* BOX_CODE_FOLD_0 */
val grid = sdf.distanceField
/*
showImgGrid rather than showImg: showImg sends its caption as a separate output message,
which the image then replaces, so the caption never survives to the page. montage only ever
scales a tile DOWN, so upscale the grid first or it lands as a 340px thumbnail.
*/
showImgGrid(
    "signed distance field, %dx%d grid, deepest %.0f".format(grid.nx, grid.ny, grid.deepestInside()) to
        grid.toImg().upscaleNearest(2),
    channel = "grid",
    columns = 1,
    cellSide = 880,
)
showMeshGrid(
    "marchingCubes on the letters — ${marched.triangleCount} triangles, genus ${marched.genus()}" to marched,
    "sdfSmoothUnion with a sphere — ${melted.triangleCount}" to melted,
    "field.shell(0.02) — ${hollow.triangleCount}" to hollow,
    "field.twisted(0.5) — ${wrung.triangleCount}" to wrung,
    channel = "surfaces",
    columns = 2,
    cellWidth = 420,
    view = MeshView(yawDegrees = 18.0, pitchDegrees = 12.0, distance = 2.6),
)/* BOX_CODE_FOLD_1 */
