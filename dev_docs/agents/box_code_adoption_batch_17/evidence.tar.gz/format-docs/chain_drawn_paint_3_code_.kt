/* BOX_CODE_FOLD_0 */
notation {
    stroke(
        FLine().moveTo(80, 300).cubicTo(200, 60, 330, 420, 420, 140),
        name = "S",
        pressure = { 0.15 + 0.85 * sin(PI * it) },
    )
    stroke(
        FLine().moveTo(470, 110).cubicTo(560, 300, 700, 330, 820, 180),
        name = "sweep",
        pressure = { 1.0 - 0.85 * it },
    )
    stroke(
        FLine().moveTo(880, 330).cubicTo(1060, 300, 1020, 60, 900, 120).cubicTo(820, 160, 880, 260, 960, 250),
        name = "loop",
        pressure = { 0.15 + 0.85 * it * it },
    )
}
/* BOX_CODE_FOLD_1 */
// Every stroke in that region, painted three times, one row each: the brush
// pressing as the pen did; the pen's pressure squared, so light strokes go lighter; one even pressure.
val region = Rect(40.0, 40.0, 1040.0, 400.0)
val strokes = notation.strokes.filter { it.bounds.intersects(region) }
val colours = [
    mapOf("ultramarine blue" to 2.0, "bone black" to 0.3),
    mapOf("vermilion" to 1.0),
    mapOf("viridian" to 1.0, "chrome yellow" to 0.6),
]
val canvas = PaintCanvas(900, aspect = 0.9, view = Rect(40.0, 40.0, 1000.0, 1110.0))
val brush = canvas.brush(BrushKind.Round, width = 70.0)
fun lower(s: Mark, dy: Double) = s.toFLine() + vec(0.0, dy)
strokes.forEachIndexed { i, s ->
    val pen = s.pressuresAlong(64)
    brush.load(colours[i % 3], wipe = 1.0)
    canvas.stroke(s.toFLine(), brush, pressure = 1.0..1.0, swell = pen)
    brush.load(colours[i % 3], wipe = 1.0)
    canvas.stroke(lower(s, 360.0), brush, pressure = 1.0..1.0, swell = pen.map { it * it })
    brush.load(colours[i % 3], wipe = 1.0)
    canvas.stroke(lower(s, 720.0), brush, pressure = 0.6..0.6)
}
display("main", canvas.png())
notation.clear() // take the strokes down so they do not lie over the picture
