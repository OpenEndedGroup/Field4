val n = 400

val knot = (0 until n).map {
    val u = 2 * PI * (it / (n - 1.0))
    vec(26 * (sin(u) + 2 * sin(2 * u)), 26 * (cos(u) - 2 * cos(2 * u)), -26 * sin(3 * u))
}
// A closed source for a closed target, and flat: z is entirely the field's work.
val circle = (0 until n).map {
    val u = 2 * PI * (it / (n - 1.0))
    vec(45 * cos(u), 45 * sin(u), 0.0)
}

val field = flowMatch(
    knot,
    circle,
    options = FlowMatchOptions(steps = 12000, seed = 11, coupling = FlowCoupling.PAIRED),
)
val landed = field.transport(circle, steps = 96)
val miss = circle.indices.sumOf { (landed[it] - knot[it]).length().toDouble() } / n
/* BOX_CODE_FOLD_0 */
fun asLine(points: List<Vec3>, c: Vec4, t: Double): FLine = fline {
    data("m l+", points)
    close()
    color = c
    thickness = t
}

/*
Three curves only. Intermediate stages of a self-intersecting knot, overlaid in one static
projection, cannot be told apart; they are worth orbiting through live but not worth printing.
Grey target, purple source, cyan where the flow landed.
*/
threeLines(
    [
        asLine(knot, vec(0.42, 0.42, 0.5, 0.9), 4.0),
        asLine(circle, vec(0.6, 0.42, 0.85, 1.0), 2.0),
        asLine(landed, vec(0.44, 0.83, 0.78, 1.0), 1.6),
    ],
    channel = "trefoil3d",
    height = 460,
    editable = false,
)
markdown(
    "knot",
    """
    ~~~
mean landing error ${"%.2f".format(miss)} on a knot about 150 units across
    ~~~
""",
)/* BOX_CODE_FOLD_1 */
