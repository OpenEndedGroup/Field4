val drawn = notation.strokes.filter { it.handDrawn }
val view =
    drawn.map { it.bounds }.reduce { a, b -> a.union(b) }.let { Rect(it.x - 40, it.y - 40, it.w + 80, it.h + 80) }
val canvas = PaintCanvas(900, aspect = view.w / view.h, view = view)
