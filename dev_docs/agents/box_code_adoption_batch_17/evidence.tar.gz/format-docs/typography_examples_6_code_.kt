/* BOX_CODE_FOLD_0 */
val face = typeface("SansSerif", 170.0)
val o = layoutText("o", face).toMesh(depth = 46.0, centre = true)
val l = layoutText("l", face).toMesh(depth = 46.0, centre = true)
val word = layoutText("mesh", typeface("SansSerif", 130.0)).toMesh(depth = 36.0, centre = true)
/* BOX_CODE_FOLD_1 */

/*
A 2D count against a 3D one. The hole count comes from ring nesting in the plane; the genus comes
from counting the mesh's vertices, edges and faces. They have no reason to agree unless the
extruder is right.
*/
val holesIn2D = layoutText("o", face).holeCount

// A 2D area against a 3D volume: a shoelace sum times the depth, against the divergence theorem
// over the triangles. A dropped cap triangle or a wall wound the wrong way breaks it.
val expected = layoutText("o", face).glyphs.sumOf { it.glyph.inkArea } * 46.0
val measured = layoutText("o", face).toMesh(depth = 46.0, yUp = false).volume()

/* BOX_CODE_FOLD_2 */
/*
flatShaded() un-welds every triangle, and the genus in these labels is topology() over whatever
you hand it — so a flat-shaded copy would label itself "genus null, watertight false" while
looking identical. The `word` panel below goes further: single-mesh showMesh writes its own fact
line, and that line would read "open (N boundary loop(s))". Unnecessary as well: both renderers
apply shadedNormals to a mesh that arrives without normals for you.
*/
showMeshGrid(
    "o — genus ${o.genus()}, 2D hole count $holesIn2D, watertight ${o.isWatertight()}" to o,
    "l — genus ${l.genus()}, watertight ${l.isWatertight()}" to l,
    channel = "letters",
    columns = 2,
    cellWidth = 420,
    view = MeshView(yawDegrees = 26.0, pitchDegrees = 16.0, distance = 3.2),
)
showMesh(
    word,
    channel = "word",
    view = MeshView(yawDegrees = 22.0, pitchDegrees = 14.0, distance = 2.6, width = 820, height = 340),
    title = "extruded from the same contours the raster filled",
    caption =
        "'o': ink area × depth = %.0f, mesh volume %.0f, relative difference %.2e"
            .format(expected, measured, kotlin.math.abs(expected - measured) / expected),
)/* BOX_CODE_FOLD_3 */
