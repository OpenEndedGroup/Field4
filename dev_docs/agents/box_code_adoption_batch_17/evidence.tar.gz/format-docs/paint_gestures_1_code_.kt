fun line(x0: Double, y0: Double, x1: Double, y1: Double) = FLine().moveTo(x0, y0).lineTo(x1, y1)
val canvas = PaintCanvas(900, aspect = 1.5, groundColor = rgb(0.97, 0.96, 0.92), sizeMm = 200.0, seed = 3)
val umber = rgb(0.25, 0.15, 0.1)
fun round() = canvas.dynamicBrush(BrushKind.Round, 50.0).load(umber, stiff = 0.4)

// a flick, then a slow lift over the same distance
canvas.stroke(
    canvas.gesture(line(80.0, 100.0, 420.0, 70.0), speed = 400.0, pressure = [0.9, -0.6], tilt = 30.0),
    round(),
)
canvas.stroke(
    canvas.gesture(line(500.0, 100.0, 900.0, 70.0), speed = 30.0, pressure = [0.9, -0.6], tilt = 30.0),
    round(),
)

// a pause halfway
val first = canvas.gesture(line(80.0, 250.0, 450.0, 250.0), speed = 80.0, pressure = [0.6], tilt = 30.0)
val second = canvas.gesture(line(450.0, 250.0, 900.0, 250.0), speed = 80.0, pressure = [0.6], tilt = 30.0)
canvas.stroke(first.pause(0.6).then(second), round())

// a flat rolled through half a turn
val straight = canvas.gesture(line(80.0, 400.0, 900.0, 400.0), speed = 60.0, pressure = [0.6], tilt = 20.0)
val n = straight.samples.size - 1
val rolled = TimedGesture(straight.samples.mapIndexed { i, s -> s.copy(roll = 90.0 + 180.0 * i / n) })
canvas.stroke(rolled, canvas.dynamicBrush(BrushKind.HogFlat, 60.0).load(umber, stiff = 0.7))

// upright, then laid well over
canvas.stroke(
    canvas.gesture(line(80.0, 540.0, 450.0, 540.0), speed = 80.0, tilt = 0.0),
    canvas.dynamicBrush(BrushKind.Filbert, 50.0).load(umber),
)
canvas.stroke(
    canvas.gesture(line(500.0, 540.0, 900.0, 540.0), speed = 80.0, tilt = 65.0),
    canvas.dynamicBrush(BrushKind.Filbert, 50.0).load(umber),
)

display("main", canvas.png(relief = 0.6))
