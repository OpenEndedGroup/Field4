val layout = layoutText("field", typeface("SansSerif", 200.0))

// Even by ARC LENGTH, so halving the spacing twice roughly quadruples the count. That ratio is the
// a real check that the resampler walks the curve rather than emitting one point per stored vertex.
val coarse = layout.samplePoints(spacing = 18.0)
val fine = layout.samplePoints(spacing = 4.5)

// And now every point-consuming family in the stdlib eats a word.
val graph = vec2DelaunayGraph(coarse)
val km = vec2KMedoids(coarse, k = 6, options = KMedoidsOptions(randomSeed = 11L))

/* BOX_CODE_FOLD_0 */
val layer = ClusterLayer("outline strokes", km.labels)
showPlaneGrid(
    "outline samples — ${coarse.size} at spacing 18, ${fine.size} at 4.5 (%.2fx for 4x finer)"
        .format(fine.size.toDouble() / coarse.size) to [layout.toPointFLine(spacing = 18.0, pointSize = 1.1)],
    "vec2DelaunayGraph over those samples — ${graph.edges.size} edges" to
        [graph.toFLine(coarse, thickness = 0.8), layout.toPointFLine(spacing = 18.0, pointSize = 0.9)],
    "vec2KMedoids, k = 6 — distortion %.1f, converged ${km.converged}".format(km.distortion) to
        layer.toFLines(coarse, centers = km.medoids, drawSpokes = false),
    "the outlines the samples came from" to layout.toFLines(thickness = 1.2),
    columns = 2,
    cellWidth = 420,
    cellHeight = 250,
    window = layout.bounds,
)/* BOX_CODE_FOLD_1 */
