val n = 1400
val picks: List<Triple<Double, Double, Double>> =
    (0 until n).map { Triple(random(), randomGaussian(), randomGaussian()) }

val source = picks.map { (s, a, b) -> vec(200 * (s - 0.5), -90 + 7 * a, 7 * b) }
val target = picks.map { (s, a, b) ->
    val u = 3 * PI * s
    val swell = 2.0 + 18.0 * sin(PI * s) * sin(PI * s)
    vec(200 * (s - 0.5) + swell * a * 0.45, 55 * sin(u) + swell * a, 55 * cos(u) + swell * 0.35 * b)
}

val field = flowMatch(
    target,
    source,
    options = FlowMatchOptions(steps = 12000, seed = 11, coupling = FlowCoupling.PAIRED),
)
val landed = field.transport(source, steps = 96)
/* BOX_CODE_FOLD_0 */
fun cloud(points: List<Vec3>, c: Vec4, size: Double): FLine {
    val f = FLine()
    points.forEach { f.moveTo(it) }
    f.pointed = true
    f.pointSize = size
    f.color = c
    return f
}

// A thinned set of threads over the two clouds, so the tube itself is visible and not only the
// travel: the round source below, the swollen helical target where the threads land.
val threads =
    field
        .pathsFrom(
            source.indices.filter { it % 28 == 0 }.map { source[it] },
            steps = 56,
        )
        .map {
            it.color = vec(0.44, 0.83, 0.78, 0.35)
            it.thickness = 0.8
            it
        }

threeLines(
    [
        cloud(source, vec(0.6, 0.42, 0.85, 0.9), 1.6),
        cloud(landed, vec(0.44, 0.83, 0.78, 0.9), 1.6),
    ] + threads,
    channel = "tube3d",
    height = 460,
    editable = false,
)
markdown(
    "miss3d",
    """
    ~~~
3D tube, ${field.dimension} dimensions inferred
mean landing error ${"%.2f".format(
    landed.indices.sumOf {
        (landed[it] - target[it]).length().toDouble()
    } / n,
)} of a 200-unit extent
    ~~~
""",
)/* BOX_CODE_FOLD_1 */
