val canvas = PaintCanvas(900, aspect = 1.25, ground = PaintGround.Oil, sizeMm = 250.0, seed = 5)
val brush = canvas.brush(BrushKind.Filbert, width = 70.0)
val tubes = ["ultramarine blue", "viridian", "Naples yellow", "vermilion", "rose madder", "burnt sienna", "bone black"]
tubes.forEachIndexed { i, tube ->
    brush.load(mapOf("lead white" to 2.0, tube to 1.0))
    canvas.stroke(
        FLine().moveTo(60, 90 + i * 100).cubicTo(400, 40 + i * 100, 600, 160 + i * 100, 940, 80 + i * 100),
        brush,
    )
}
canvas.dry()
canvas.glaze(rgb(0.6, 0.45, 0.2), coats = 0.15) // old varnish
canvas.crack(CrackKind.Aged)

display("main", canvas.png(relief = 0.8, gloss = 0.3))
