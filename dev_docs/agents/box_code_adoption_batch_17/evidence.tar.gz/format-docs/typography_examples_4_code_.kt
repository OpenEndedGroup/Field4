/* BOX_CODE_FOLD_0 */
val face = typeface("SansSerif", 78.0)
val ring = layoutText("AROUND AND AROUND", face, tracking = 7.0)
val wave = fline {
    moveTo(0.0, 0.0)
    cubicTo(300.0, -240.0, 720.0, 240.0, 1020.0, 0.0)
}
/* BOX_CODE_FOLD_1 */

// Size the circle to the text rather than the text to the circle: a circumference equal to the
// layout's width means the string closes exactly, with no gap and no overlap at the seam.
val circle = textCircle(radius = ring.advanceWidth / (2 * Math.PI))
val onCircle = ring.onCurve(circle, align = TextAlign.CENTER)
val onWave = layoutText("a rolling line of type", face, tracking = 2.0).onCurve(wave, align = TextAlign.CENTER)

/* BOX_CODE_FOLD_2 */
// Two figures, two CHANNELS: a second display on one channel replaces the first.
showImgGrid(
    "circumference %.1f vs width %.1f".format(circle.arcLength(), ring.advanceWidth) to
        rasterizeText(onCircle, 620, 620),
    "%d of %d glyphs turned".format(onWave.glyphs.count { kotlin.math.abs(it.rotation) > 0.05 }, onWave.glyphs.size) to
        rasterizeText(onWave, 620, 620),
    channel = "rasters",
    columns = 2,
    cellSide = 420,
)
showPlaneGrid(
    "the circle it sits on — original untouched: ${ring.glyphs.all { it.isUntransformed }}" to
        ([
            circle.copy {
                color = vec(0.4, 0.6, 0.8, 0.6)
                thickness = 1.0
            },
        ] + onCircle.toFLines(thickness = 1.0)),
    "the cubic it sits on" to
        ([
            wave.copy {
                color = vec(0.4, 0.6, 0.8, 0.6)
                thickness = 1.0
            },
        ] + onWave.toFLines(thickness = 1.0)),
    channel = "paths",
    columns = 2,
    cellWidth = 430,
    cellHeight = 430,
)/* BOX_CODE_FOLD_3 */
