val sheets =
    Paper.entries.map { paper ->
        PaintCanvas.paper(220, aspect = 1.0, paper = paper, sizeMm = 50.0, seed = 2).also { sheet ->
            sheet.drop(500.0, 500.0, Watercolors.sumi * 3.0, volumeMm3 = 15.0)
            sheet.dry()
        }
    }
display("main", pngRow(sheets))
