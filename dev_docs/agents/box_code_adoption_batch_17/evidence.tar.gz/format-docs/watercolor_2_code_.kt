fun rectBetween(x0: Double, y0: Double, x1: Double, y1: Double) = FLine().rect(x0, y0, x1 - x0, y1 - y0)

val sheet = PaintCanvas.paper(700, aspect = 1.6, paper = Paper.ColdPress, sizeMm = 160.0, seed = 3)

// wet in wet: clean water, then drops of colour into it at once
sheet.wet(rectBetween(60.0, 80.0, 460.0, 540.0), microns = 40.0)
for ((x, y) in [150.0 to 180.0, 330.0 to 260.0, 200.0 to 420.0]) sheet.drop(
    x,
    y,
    Watercolors.ultramarine * 15.0,
    volumeMm3 = 4.0,
)
for ((x, y) in [260.0 to 160.0, 380.0 to 440.0]) sheet.drop(x, y, Watercolors.quinacridoneRose * 12.0, volumeMm3 = 4.0)

// a backrun: a wash left until damp, then clean water into it
sheet.wet(rectBetween(540.0, 80.0, 940.0, 540.0), microns = 110.0, paint = Watercolors.burntSienna * 2.5)
sheet.waitSeconds(240.0)
sheet.drop(740.0, 310.0, WaterPaint.Clear, volumeMm3 = 25.0)
sheet.dry()

display("main", sheet.png())
