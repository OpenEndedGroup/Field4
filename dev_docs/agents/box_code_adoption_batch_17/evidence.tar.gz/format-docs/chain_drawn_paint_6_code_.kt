/* BOX_CODE_FOLD_0 */
notation {
    stroke(
        FLine().moveTo(80, 300).cubicTo(200, 60, 330, 420, 420, 140),
        name = "S",
        pressure = { 0.15 + 0.85 * sin(PI * it) },
    )
    stroke(
        FLine().moveTo(470, 110).cubicTo(560, 300, 700, 330, 820, 180),
        name = "sweep",
        pressure = { 1.0 - 0.85 * it },
    )
    stroke(
        FLine().moveTo(880, 330).cubicTo(1060, 300, 1020, 60, 900, 120).cubicTo(820, 160, 880, 260, 960, 250),
        name = "loop",
        pressure = { 0.15 + 0.85 * it * it },
    )
}
/* BOX_CODE_FOLD_1 */
// The strokes in that region in a 6B pencil, on a 20 cm sheet, its pressure following the pen.
val region = Rect(40.0, 40.0, 1040.0, 400.0)
val canvas = PaintCanvas(900, aspect = 3.0, view = Rect(40.0, 40.0, 1040.0, 347.0), sizeMm = 200.0)
val pencil = canvas.pencil("6B")
for (s in notation.strokes.filter { it.bounds.intersects(region) }) canvas.draw(
    s.toFLine(),
    pencil,
    pressure = s.pressuresAlong(32).ifEmpty { [0.6] },
)
display("main", canvas.png())
notation.clear()
