typeface("SansSerif", 64.0) // logical family: always resolves
Typefaces.named("Futura", 64.0, strict = true) // throws instead of substituting silently
Typefaces.firstAvailable("Futura", "Avenir", size = 64) // the first one this machine actually has
Typefaces.fromFile("/path/to/Whatever.ttf", 64.0) // Font.createFont, not registered globally
