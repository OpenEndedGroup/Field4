val layout = layoutText("aeg", typeface("Serif", 240.0))

// Every ring of the layout, still classified: depth is containment, isHole is depth parity,
// signedArea is the direction that classification forced.
val rings = layout.toContours()

/* BOX_CODE_FOLD_0 */
val lines = rings.map { ring ->
    fline {
        data("m l+", ring.points)
        lineTo(ring.points[0].x, ring.points[0].y)
        color = if (ring.isHole) vec(1.0, 0.55, 0.28, 0.95) else vec(0.5, 0.82, 1.0, 0.95)
        thickness = 1.8
    } to ring.isHole
}
val signs = rings.joinToString(" ") { if (it.signedArea > 0) "+" else "−" }
showPlaneGrid(
    "outer rings — depth even, area positive (${rings.count { !it.isHole }})" to
        lines.filter { !it.second }.map { it.first },
    "hole rings — depth odd, area negative (${rings.count { it.isHole }})" to
        lines.filter { it.second }.map { it.first },
    "all ${rings.size} rings, signs $signs" to lines.map { it.first },
    "the same layout, filled" to layout.toFLines(filled = true, stroked = false, thickness = 1.0),
    columns = 2,
    cellWidth = 460,
    cellHeight = 250,
    window = layout.bounds,
)/* BOX_CODE_FOLD_1 */
