val n = 1200

// Each sample is (s along the curve, r across it), so source and target share a point identity.
val draws: List<Pair<Double, Double>> = (0 until n).map { Pair(random(), randomGaussian()) }

fun width(s: Double): Double = 3.0 + 26.0 * sin(PI * s) * sin(PI * s)
fun centre(s: Double): Vec3 = vec(240 * (s - 0.5), 70 * sin(3 * PI * s), 0.0)

// Unit normal of the centreline: the direction the width is measured along.
fun normal(s: Double): Vec3 {
    val dy = 70.0 * 3 * PI * cos(3 * PI * s)
    val len = hypot(240.0, dy)
    return vec(-dy / len, 240.0 / len, 0.0)
}

val source = draws.map { vec(240 * (it.first - 0.5), 150 + 9 * it.second, 0.0) }
val target = draws.map { (s, r) -> centre(s) + normal(s) * (width(s) * r) }

val field = flowMatch(
    target,
    source,
    options = FlowMatchOptions(steps = 8000, seed = 11, coupling = FlowCoupling.PAIRED),
)

// Transverse spread measured along the centreline normal, so it reports width rather than a blob
// radius that would also contain the travel along the curve.
fun transverseSd(points: List<Vec3>, from: Double, to: Double): Double {
    val picked = draws.indices.filter { draws[it].first >= from && draws[it].first < to }
    val offsets = picked.map {
        val s = draws[it].first
        val d = points[it] - centre(s)
        (d.x * normal(s).x + d.y * normal(s).y).toDouble()
    }
    return sqrt(offsets.sumOf { it * it } / offsets.size)
}
/* BOX_CODE_FOLD_0 */
fun cloud(points: List<Vec3>, c: Vec4, shift: Vec3): FLine {
    val f = FLine()
    points.forEach { f.moveTo(it + shift) }
    f.pointed = true
    f.pointSize = 1.0
    f.color = c
    return f
}

val flowed = field.transport(source, steps = 64)
lines(
    [
        cloud(source, vec(0.6, 0.42, 0.85, 0.85), vec(0, 0, 0)),
        cloud(field.transport(source, to = 0.35, steps = 48), vec(0.44, 0.83, 0.78, 0.85), vec(280, 0, 0)),
        cloud(field.transport(source, to = 0.7, steps = 48), vec(0.44, 0.83, 0.78, 0.85), vec(0, 360, 0)),
        cloud(target, vec(0.35, 0.35, 0.4, 0.7), vec(280, 360, 0)),
        cloud(flowed, vec(0.44, 0.83, 0.78, 0.85), vec(280, 360, 0)),
    ],
    w = 1000.0,
    h = 540.0,
    fitToSize = true,
)

val rows =
    (0 until 8).map { bin ->
        val lo = bin / 8.0
        val hi = (bin + 1) / 8.0
        val wanted =
            draws.indices
                .filter { draws[it].first >= lo && draws[it].first < hi }
                .map { width(draws[it].first) }
                .average()
        "  %.2f-%.2f   %7.2f   %10.2f   %10.2f"
            .format(
                lo,
                hi,
                wanted,
                transverseSd(target, lo, hi),
                transverseSd(flowed, lo, hi),
            )
    }
markdown(
    "width",
    """
    ~~~
transverse width at t = 1, measured along the centreline normal

   s band     wanted   target cloud   flowed cloud
${rows.joinToString("\n")}
    ~~~
""",
)/* BOX_CODE_FOLD_1 */
