val field = flowMatch(myCloud) // from a Gaussian: a generator
val fresh = field.sample(500) // new points shaped like myCloud
val threads = field.paths(80) // the trajectories, as FLines

val morph = flowMatch(to = cloudB, from = cloudA)
val halfway = morph.transport(cloudA, to = 0.5) // a real intermediate distribution
