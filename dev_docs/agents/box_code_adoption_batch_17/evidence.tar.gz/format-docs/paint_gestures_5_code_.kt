// two metres of canvas, primed off-white
val canvas = PaintCanvas(1200, aspect = 2.1, groundColor = rgb(0.93, 0.9, 0.83), sizeMm = 2000.0, seed = 11)
val h = canvas.heightUnits

// a house painter's brush: soft, uneven hairs held together, laying a thin film of fat black
val housePainter = BrushConfig(stiffness = 0.5, ragged = 0.5, splay = 0.0, lay = 0.8, run = 1100.0)
fun brush(width: Double) =
    canvas
        .dynamicBrush(BrushKind.HogFlat, width, hairs = 48, segments = 6, config = housePainter)
        .load(rgb(0.05, 0.045, 0.04), hiding = 0.65, stiff = 0.5, oil = 1.5, amount = 0.5)

// an oval spiralling out from its middle, so its edge comes last, as the brush runs dry
fun oval(cx: Double, cy: Double, rx: Double, ry: Double): FLine {
    val line = FLine()
    line.breakNext()
    for (i in 0..120) {
        val u = i / 120.0
        val a = PI / 2 + 2 * PI * 1.8 * u
        val r = 0.2 + 0.8 * u
        line.lineTo(cx + rx * r * cos(a), cy + ry * r * sin(a))
    }
    return line
}

// three slabs, each one movement, pressed down and lifted off the canvas at its end
for ((x, width) in [120.0 to 70.0, 470.0 to 80.0, 905.0 to 65.0]) canvas.stroke(
    canvas.gesture(
        FLine().moveTo(x, 25).lineTo(x + 8, h - 25),
        speed = 260.0,
        pressure = [0.7, 1.0, 0.9, 0.4, -0.2],
        tilt = 25.0,
    ),
    brush(width),
)
// and two ovals between them
for ((cx, cy, rx) in [Triple(300.0, 250.0, 120.0), Triple(690.0, 230.0, 140.0)]) canvas.stroke(
    canvas.gesture(
        oval(cx, cy, rx, 170.0),
        speed = 320.0,
        pressure = [1.1, 1.0, 0.8, 0.4, -0.2],
        tilt = 35.0,
    ),
    brush(80.0),
)

display("main", canvas.png(relief = 0.3))
