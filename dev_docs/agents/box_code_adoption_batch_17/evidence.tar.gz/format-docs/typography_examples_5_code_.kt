/* BOX_CODE_FOLD_0 */
val face = typeface("SansSerif", 150.0)
val layout = layoutText("KINETIC", face, tracking = 16.0)
// A FIXED frame, not fit-to-contents: left to rescale to each frame's own bounds the letters would
// move and the picture would stand still. Probe both extremes of the wave and union them.
val window = run {
    val probe = layoutText("KINETIC", face, tracking = 16.0)
    probe.eachGlyph { i ->
        rotation = 0.5
        scale = vec(1.3, 1.3)
        offset = vec(0.0, 34.0)
    }
    val a = probe.bounds
    probe.eachGlyph { i ->
        rotation = -0.5
        scale = vec(1.3, 1.3)
        offset = vec(0.0, -34.0)
    }
    a.union(probe.bounds)
}
val started = AnimationClock.nowSeconds()

/* BOX_CODE_FOLD_1 */

// The line you would change: elapsed seconds and a glyph index in, a travelling wave out. During
// offline capture AnimationClock derives elapsed time exactly from frame index / fps.
fun waveAt(elapsed: Double, i: Int): Double = 1.7 * elapsed + i * 0.7

animate {
    val elapsed = AnimationClock.nowSeconds() - started
    layout.eachGlyph { i ->
        val w = waveAt(elapsed, i)
        rotation = 0.42 * kotlin.math.sin(w)
        val s = 1.0 + 0.22 * kotlin.math.cos(w)
        scale = vec(s, s)
        offset = vec(0.0, 30.0 * kotlin.math.sin(w * 1.3))
    }
    showImgGrid(
        "t = %.1fs".format(elapsed) to rasterizeText(layout, 1100, 420, window = window),
        columns = 1,
        cellSide = 820,
    )
}
