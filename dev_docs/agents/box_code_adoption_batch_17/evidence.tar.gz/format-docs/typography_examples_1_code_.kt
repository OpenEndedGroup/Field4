/* BOX_CODE_FOLD_0 */
val face = typeface("SansSerif", 220.0)
val layout = layoutText("open", face)
val window = layout.bounds
/* BOX_CODE_FOLD_1 */

// The control arm is one argument. Same filler, same NON_ZERO rule, same rings — only their
// direction differs, and NON_ZERO cancels a +1 outer against a −1 hole to leave a counter.
val withConvention = rasterizeText(
    layout,
    900,
    460,
    window = window,
    fillRule = TextFillRule.NON_ZERO,
    rings = layout.toContours(honourHoles = true),
)
val withoutConvention = rasterizeText(
    layout,
    900,
    460,
    window = window,
    fillRule = TextFillRule.NON_ZERO,
    rings = layout.toContours(honourHoles = false),
)

// EVEN_ODD counts crossings and ignores direction, depending on nesting parity instead. Over
// correct rings it must produce the IDENTICAL raster — two independent rules agreeing.
val evenOdd = rasterizeText(layout, 900, 460, window = window, fillRule = TextFillRule.EVEN_ODD)

/* BOX_CODE_FOLD_2 */
var worst = 0.0
for (y in 0 until withConvention.height) for (x in 0 until withConvention.width) {
    worst = maxOf(worst, kotlin.math.abs(withConvention.at(x, y, 0) - evenOdd.at(x, y, 0)).toDouble())
}
// Captions are drawn by montage's own 5x7 bitmap table and are clipped to the cell, so keep
// them short enough to survive.
showImgGrid(
    "convention on — %.1f%% ink".format(100 * withConvention.inkFraction()) to withConvention,
    "convention off — %.1f%% ink".format(100 * withoutConvention.inkFraction()) to withoutConvention,
    "EVEN_ODD: max diff %.5f".format(worst) to evenOdd,
    columns = 3,
    cellSide = 380,
)/* BOX_CODE_FOLD_3 */
