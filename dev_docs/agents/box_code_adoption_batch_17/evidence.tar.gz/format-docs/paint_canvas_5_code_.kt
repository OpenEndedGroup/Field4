val canvas = PaintCanvas(900, aspect = 2.0, sizeMm = 300.0)

canvas.work(rect(40.0, 60.0, 280.0, 380.0), rgb(0.2, 0.4, 0.6), Handling.Body, angle = 0.5)
canvas.work(rect(40.0, 60.0, 280.0, 180.0), rgb(0.85, 0.75, 0.5), Handling.Broad, angle = 0.0)

canvas.stipple(rect(370.0, 80.0, 260.0, 340.0), rgb(0.7, 0.2, 0.15), size = 6.0, coverage = 1.2, feather = 40.0)

val pen = canvas.brush(BrushKind.Round, 7.0, point = 1.0).load(rgb(0.08, 0.06, 0.05))
canvas.outline(
    FLine().moveTo(700, 420).lineTo(820, 90).lineTo(950, 420).lineTo(700, 420),
    pen,
    OutlineCharacter.Searching,
)

display("main", canvas.png())
