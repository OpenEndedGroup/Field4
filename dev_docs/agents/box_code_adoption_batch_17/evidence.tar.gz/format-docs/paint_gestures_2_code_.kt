val canvas = PaintCanvas(600, aspect = 2.0, groundColor = rgb(0.97, 0.96, 0.92), sizeMm = 100.0, seed = 3)
val brush = canvas.dynamicBrush(BrushKind.Round, 80.0, hairs = 24).load(rgb(0.25, 0.15, 0.1))
canvas.stroke(
    canvas.gesture(FLine().moveTo(200, 250).lineTo(500, 250), speed = 60.0, pressure = [0.8], tilt = 20.0),
    brush,
)

// x along the stroke against height: on a 100 mm canvas 10 units are a mm, so this is to scale
val side =
    canvas.hairs(brush).map { hair ->
        val l = FLine().moveTo(hair[0].first, -hair[0].third * 10)
        for ((x, _, z) in hair.drop(1)) l.lineTo(x, -z * 10)
        l.apply {
            thickness = 1.5
            color = vec(0.95, 0.8, 0.55, 1.0)
        }
    }
val paper = FLine().moveTo(300, 0).lineTo(560, 0).apply {
    thickness = 2.0
    color = vec(0.5, 0.6, 0.7, 1.0)
}
lines(side + paper, w = 520.0, h = 240.0, fitToSize = true)
