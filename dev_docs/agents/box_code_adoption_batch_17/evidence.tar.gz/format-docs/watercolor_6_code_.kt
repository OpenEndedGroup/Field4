fun rectBetween(x0: Double, y0: Double, x1: Double, y1: Double) = FLine().rect(x0, y0, x1 - x0, y1 - y0)

val sheet = PaintCanvas.paper(700, aspect = 2.0, paper = Paper.ColdPress, sizeMm = 160.0, seed = 7)
val u = Watercolors.ultramarine * 3.0
val p = Watercolors.phthaloBlue * 0.8
for ((i, paint) in [u, p, u + p].withIndex()) sheet.wet(
    rectBetween(60.0 + i * 310, 70.0, 320.0 + i * 310, 430.0),
    microns = 120.0,
    paint = paint,
)
sheet.dry()
display("main", sheet.png(relief = 0.4))
