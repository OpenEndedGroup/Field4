val sheet = PaintCanvas.paper(700, aspect = 2.5, paper = Paper.Rough, sizeMm = 150.0, seed = 5)
for ((i, fill) in [1.0, 0.25, 0.08].withIndex()) {
    val brush =
        sheet
            .dynamicBrush(BrushKind.Round, 80.0, hairs = 32)
            .loadWater(sheet, Watercolors.burntSienna * 80.0 + Watercolors.ultramarine * 40.0, fill = fill)
    val y = 70.0 + i * 120
    sheet.stroke(FLine().moveTo(60, y).lineTo(940, y), brush, pressure = [0.3], speed = 200.0, tilt = 50.0)
}
sheet.dry()
display("main", sheet.png(relief = 0.5))
