import java.util.Base64

fun rectBetween(x0: Double, y0: Double, x1: Double, y1: Double) = FLine().rect(x0, y0, x1 - x0, y1 - y0)
fun img(png: ByteArray) = "<img width='300' src='data:image/png;base64,${Base64.getEncoder().encodeToString(png)}'>"

val sheet = PaintCanvas.paper(300, aspect = 1.0, paper = Paper.ColdPress, sizeMm = 80.0, seed = 8)
sheet.wet(rectBetween(100.0, 100.0, 900.0, 900.0), microns = 80.0, paint = Watercolors.ultramarine * 1.0)
val brush = sheet.waterBrush(80.0).load(Watercolors.ultramarine * 4.0)
sheet.wash(FLine().moveTo(200, 250).cubicTo(500, 100, 500, 900, 800, 750), brush, speed = 40.0)
sheet.waitSeconds(20.0)

display(
    "main",
    img(sheet.png(wet = true)) +
        " " +
        img(sheet.waterMapPng(WaterMap.SurfaceWater)) +
        " " +
        img(sheet.waterMapPng(WaterMap.AbsorbedWater)),
)
