val canvas = PaintCanvas(900, aspect = 1.6, groundColor = rgb(0.97, 0.96, 0.92), sizeMm = 300.0)
val configs = [
    null,
    BrushConfig(bristles = 12),
    BrushConfig(bristles = 40, ragged = 1.0),
    BrushConfig(pickup = 0.9, push = 0.9),
    BrushConfig(lay = 0.4, run = 900.0),
]
configs.forEachIndexed { i, config ->
    val brush = canvas.brush(BrushKind.HogFlat, width = 60.0, config = config)
    brush.load(rgb(0.12, 0.13, 0.2), amount = 0.6)
    val x = 110.0 + i * 190
    canvas.stroke(FLine().moveTo(x, 50).cubicTo(x + 90, 230, x - 90, 400, x, 580), brush, pressure = 0.9..0.5)
}
display("main", canvas.png())
