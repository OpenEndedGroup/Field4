val sheet = PaintCanvas.paper(700, aspect = 1.5, paper = Paper.ColdPress, sizeMm = 200.0, seed = 3)
val brush = sheet.waterBrush(width = 70.0)

// the sky, in overlapping strokes while it is wet
brush.load(Watercolors.ultramarine * 3.0 + Watercolors.burntSienna * 0.5)
sheet.wash(FLine().moveTo(60, 90).lineTo(940, 90).moveTo(940, 135).lineTo(60, 135), brush, speed = 50.0)
brush.load(Watercolors.ultramarine * 1.2, fill = 0.8)
sheet.wash(FLine().moveTo(60, 180).lineTo(940, 180).moveTo(940, 225).lineTo(60, 225), brush, speed = 50.0)

// let it dry, then the hills over it
sheet.dry()
brush.load(Watercolors.burntSienna * 3.0 + Watercolors.ultramarine * 2.0)
val hills = FLine().moveTo(40, 420).cubicTo(250, 300, 450, 420, 960, 340)
sheet.wash(hills, brush, pressure = [1.0], speed = 30.0)
sheet.wash(FLine().moveTo(40, 470).lineTo(960, 450), brush, pressure = [1.0], speed = 30.0)
sheet.dry()

display("main", sheet.png())
