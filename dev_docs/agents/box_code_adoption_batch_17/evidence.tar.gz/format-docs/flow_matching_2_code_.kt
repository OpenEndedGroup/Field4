val n = 300

// Both curves are sampled in order of their own arc coordinate, so point i at one end is the same
// material point as point i at the other. That is what PAIRED needs.
fun closed(radius: Double): List<Vec3> = (0 until n).map {
    val s = it / (n - 1.0)
    vec(radius * cos(2 * PI * s), radius * sin(2 * PI * s), 0.0)
}

val target = closed(100.0)
val circleSource = closed(30.0)
val segmentSource = (0 until n).map { vec(200 * (it / (n - 1.0) - 0.5), -150.0, 0.0) }

val options = FlowMatchOptions(steps = 6000, seed = 11, coupling = FlowCoupling.PAIRED)
val fromCircle = flowMatch(target, circleSource, options = options)
val fromSegment = flowMatch(target, segmentSource, options = options)

fun miss(field: FlowMatchField, source: List<Vec3>): Double {
    val landed = field.transport(source, steps = 64)
    return landed.indices.sumOf { (landed[it] - target[it]).length().toDouble() } / n
}
/* BOX_CODE_FOLD_0 */
fun asClosed(points: List<Vec3>, c: Vec4, t: Double): FLine = fline {
    data("m l+", points)
    color = c
    thickness = t
}

/*
Grey is the target, purple the source at t = 0, cyan the flow between them -- the same three
roles, in the same three colours, as every other figure on this page. The target is drawn even
though the t = 1 stage lands on top of it, because otherwise there is nothing to judge against.
*/
fun stages(field: FlowMatchField, source: List<Vec3>): List<FLine> = [
    asClosed(target, vec(0.45, 0.45, 0.52, 0.9), 3.0),
    asClosed(source, vec(0.6, 0.42, 0.85, 1.0), 1.8),
] +
        [0.25, 0.5, 0.75, 1.0].map {
            asClosed(field.transport(source, to = it, steps = 48), vec(0.44, 0.83, 0.78, 0.9), 1.2)
        }

lines(
    stages(fromCircle, circleSource) + (stages(fromSegment, segmentSource) + vec(260, 0, 0)),
    w = 1000.0,
    h = 500.0,
    fitToSize = true,
)
markdown(
    "miss",
    """
    ~~~
closed source (circle -> ring)    mean landing error ${"%.2f".format(miss(fromCircle, circleSource))}
open source   (segment -> ring)   mean landing error ${"%.2f".format(miss(fromSegment, segmentSource))}
    ~~~
""",
)/* BOX_CODE_FOLD_1 */
