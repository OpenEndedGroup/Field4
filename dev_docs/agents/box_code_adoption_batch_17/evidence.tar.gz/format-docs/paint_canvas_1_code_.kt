val canvas = PaintCanvas(900, aspect = 2.0)
BrushKind.entries.forEachIndexed { i, kind ->
    val x = 110.0 + i * 155
    val brush = canvas.brush(kind, width = 40.0).load(rgb(0.12, 0.12, 0.18))
    canvas.stroke(FLine().moveTo(x, 70).cubicTo(x + 60, 200, x - 60, 300, x, 430), brush)
}
display("main", canvas.png())
