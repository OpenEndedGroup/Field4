fun line(x0: Double, y0: Double, x1: Double, y1: Double) = FLine().moveTo(x0, y0).lineTo(x1, y1)
val umber = rgb(0.25, 0.15, 0.1)

// a scrap canvas of the same size to abuse the brush on
val scrap = PaintCanvas(400, aspect = 1.5, sizeMm = 200.0, seed = 4)
val abused = scrap.dynamicBrush(BrushKind.HogFlat, 60.0, hairs = 40).load(umber, stiff = 0.6)
val scrub = scrap.gesture(
    FLine().moveTo(100, 300).lineTo(900, 300).lineTo(100, 310).lineTo(900, 320).lineTo(100, 330),
    speed = 120.0,
    pressure = [1.6],
    tilt = 10.0,
    roll = 0.0,
)
scrap.stroke(scrub, abused)

val canvas = PaintCanvas(900, aspect = 3.0, groundColor = rgb(0.97, 0.96, 0.92), sizeMm = 200.0, seed = 4)
val fresh = canvas.dynamicBrush(BrushKind.HogFlat, 60.0, hairs = 40)
for ((y, brush) in [100.0 to fresh, 230.0 to abused]) {
    brush.load(umber, stiff = 0.6, wipe = 1.0)
    canvas.stroke(canvas.gesture(line(100.0, y, 900.0, y), speed = 80.0, pressure = [0.5], tilt = 25.0), brush)
}
display("main", canvas.png(relief = 0.6))
markdown("retained bend: fresh %.3f rad, scrubbed %.3f rad".format(fresh.retainedBend, abused.retainedBend))
