fun cloud(points: List<Vec3>, size: Double, c: Vec4, shift: Vec3 = vec(0, 0, 0)): FLine {
    val f = FLine()
    points.forEach { f.moveTo(it + shift) }
    f.pointed = true
    f.pointSize = size
    f.color = c
    return f
}

val target = (0 until 500).map {
    val a = random() * 2 * PI
    vec(100 * cos(a), 100 * sin(a), 0.0)
}

val field = flowMatch(target, options = FlowMatchOptions(steps = 6000, seed = 11))
val samples = field.sample(500, seed = 12)

// The ring's radius is a single number, so the fit can be stated rather than eyeballed.
val radii = samples.map { hypot(it.x.toDouble(), it.y.toDouble()) }
val mean = radii.average()
val sd = sqrt(radii.sumOf { (it - mean) * (it - mean) } / radii.size)

val threads = field.paths(80, steps = 48, seed = 13).map {
    it.color = vec(0.44, 0.83, 0.78, 0.55)
    it.thickness = 0.8
    it
} + vec(330, 0, 0)
/* BOX_CODE_FOLD_0 */
lines(
    [
        // Target underneath at a larger point size, so it shows as a halo where the two agree.
        cloud(target, 3.0, vec(0.55, 0.55, 0.62, 0.9)),
        cloud(samples, 1.4, vec(0.44, 0.83, 0.78, 1.0)),
    ] + threads,
    w = 1000.0,
    h = 460.0,
    fitToSize = true,
)
markdown(
    "fit",
    """
    ~~~
generated radius   ${"%.1f".format(mean)} +/- ${"%.1f".format(sd)}   (target: 100)
chamfer to target  ${"%.2f".format(chamferDistance(samples, target))}
training loss      ${"%.4f".format(field.loss(200))} over ${field.parameterCount} parameters
    ~~~
""",
)/* BOX_CODE_FOLD_1 */
