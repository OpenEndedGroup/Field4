from pathlib import Path
import json,re,importlib.util
R=Path.cwd();H=R/'dev_docs/agents/box_code_adoption_batch_17'
ids={'5cf07a2fc9d7-01','aa7515688d96-01','fe178e5f2f54-01','fe178e5f2f54-02','d020fbb89ce4-02','265c63dc2aac-01','2f347d18c2a9-01','b3b75a3d0757-01','fd42702d1541-01','f82901d657cb-01','f1708701b118-01'}
findings=[r for r in json.loads((R/'dev_docs/agents/box_code_first_pass/findings.json').read_text()) if r['finding_id'] in ids];rows=[]
spec=importlib.util.spec_from_file_location('states17',R/'dev_docs/agents/box_code_adoption_batch_7/format_docs.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
for path in sorted({r['path'] for r in findings}):
 p=R/path;before=p.read_text();s=before
 if path.endswith(('drawn_paint.yaml','chain_drawn_paint.md')):
  s,n=re.subn(r'fun lower\(s: Mark, dy: Double\) = FLine\(\).also \{ f -> s.points.forEachIndexed \{ k, p -> if \(k == 0\) f.moveTo\(p.x, p.y \+ dy\) else f.lineTo\(p.x, p.y \+ dy\) \} \}', 'fun lower(s: Mark, dy: Double) = s.toFLine() + vec(0.0, dy)',s);assert n==1
 elif path.endswith('fline_exact_booleans.yaml'):
  a=s.index('          fun circle(');b=s.index('\n\n',a);s=s[:a]+'          fun circle(cx: Double, cy: Double, r: Double) = FLine().circle(cx, cy, r)'+s[b:]
  s=s.replace('          fun star(cx: Double, cy: Double) = fline {','          fun star(cx: Double, cy: Double) = fline {\n              breakNext()')
  s=s.replace('if (i == 0) moveTo(cx + r * kotlin.math.cos(a), cy + r * kotlin.math.sin(a))\n                  else lineTo(cx + r * kotlin.math.cos(a), cy + r * kotlin.math.sin(a))','lineTo(cx + r * kotlin.math.cos(a), cy + r * kotlin.math.sin(a))')
  pattern=r'fline \{\n\s+moveTo\(p.x \+ (2\.5|2\.0), p.y\)\n(?:\s+cubicTo\([^\n]*\)\n){4}'
  s,n=re.subn(pattern,lambda m:'FLine().circle(p.x, p.y, '+m[1]+').apply {\n',s);assert n==2
 elif path.endswith('inertial_movement.yaml'):
  old='trail.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }';assert old in s;s=s.replace(old,'path.breakNext()\n              trail.forEach { p -> path.lineTo(p.x, p.y) }')
 elif path.endswith('autodiff_examples.md'):
  a=s.index('    for (i in 0..40) {',s.index('fun marker('));b=s.index('    color =',a);s=s[:a]+'    circle(p.x, p.y, r, segments = 40)\n'+s[b:]
  s=s.replace('    moveTo(0.0, 0.0); lineTo(boxWidth, 0.0); lineTo(boxWidth, boxHeight); lineTo(0.0, boxHeight)\n    close();','    rect(0.0, 0.0, boxWidth, boxHeight);')
 elif path.endswith('flow_matching.md'):
  s,n=re.subn(r'points.forEachIndexed \{ i, p -> if \(i == 0\) moveTo\(p\) else lineTo\(p\) \}', 'data("m l+", points)',s);assert n==2
 elif path.endswith('typography_examples.md'):
  old='ring.points.forEachIndexed { i, p -> if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) }';assert old in s;s=s.replace(old,'data("m l+", ring.points)')
 elif path.endswith('paint_gestures.md'):
  old='if (i == 0) line.moveTo(cx + rx * r * cos(a), cy + ry * r * sin(a)) else line.lineTo(cx + rx * r * cos(a), cy + ry * r * sin(a))';assert s.count(old)==2;s=s.replace(old,'line.lineTo(cx + rx * r * cos(a), cy + ry * r * sin(a))');s=s.replace('    val line = FLine()\n    for (i in 0..120)', '    val line = FLine()\n    line.breakNext()\n    for (i in 0..120)')
 elif path.endswith('paint_canvas.md'):
  old='fun rect(x: Double, y: Double, w: Double, h: Double) =\n    FLine().moveTo(x, y).lineTo(x + w, y).lineTo(x + w, y + h).lineTo(x, y + h).lineTo(x, y)\n\n';assert old in s;s=s.replace(old,'');s=s.replace('FLine().moveTo(60, 60).lineTo(940, 60).lineTo(940, 600).lineTo(60, 600).lineTo(60, 60)','FLine().rect(60, 60, 880, 540)')
 elif path.endswith('watercolor.md'):
  edits=[]
  for a,b in d.sections(s):
   body=s[a:b];old='fun rect(x0: Double, y0: Double, x1: Double, y1: Double) =\n    FLine().moveTo(x0, y0).lineTo(x1, y0).lineTo(x1, y1).lineTo(x0, y1).lineTo(x0, y0)'
   if old in body:
    body=body.replace(old,'fun rectBetween(x0: Double, y0: Double, x1: Double, y1: Double) =\n    FLine().rect(x0, y0, x1 - x0, y1 - y0)');body=re.sub(r'(?<![.\w])rect\(', 'rectBetween(',body)
   body=body.replace('FLine().moveTo(200, 150).lineTo(800, 150).lineTo(800, 600).lineTo(200, 600).lineTo(200, 150)','FLine().rect(200, 150, 600, 450)');edits.append((a,b,body))
  for a,b,body in reversed(edits):s=s[:a]+body+s[b:]
 else:raise ValueError(path)
 assert before!=s,path
 rows.append({'path':path,'before':before,'after':s,'findingIds':[r['finding_id'] for r in findings if r['path']==path]})
for r in rows:(R/r['path']).write_text(r['after'])
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 t=(R/'dev_docs/agents/box_code_adoption_batch_16'/name).read_text().replace('adoption-16','adoption-17').replace('adoption_batch_16','adoption_batch_17').replace("'a3d8c0d37'","'8784d46dd'");(H/name).write_text(t)
print(len(rows),'paths;',len(ids),'findings')
