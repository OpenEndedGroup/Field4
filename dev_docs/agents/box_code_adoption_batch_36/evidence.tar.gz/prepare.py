from pathlib import Path
import yaml,json
H=Path('dev_docs/agents/box_code_adoption_batch_36');rows=[]
def disk(code):
 if 'createTempDirectory' not in code:return code
 if 'PlySupport.loadPly(file.path)' in code:
  code='import org.lwjgl.system.MemoryUtil.memFree\n\n'+code
  code=code.replace('Change the six colour triples','Change the four colour triples')
  a=code.index('val b = model.buffers');b=code.index('dir.deleteRecursively()',a)
  body=code[a:b].rstrip();code=code[:a]+'try {\n'+''.join('    '+x+'\n' if x else '\n' for x in body.splitlines())+'} finally {\n    memFree(model.buffers.vertexData)\n    model.buffers.indexData?.let { memFree(it) }\n}\n'+code[b:]
 a=code.index('\n',code.index('val dir ='))+1;b=code.index('dir.deleteRecursively()',a)
 body=code[a:b].rstrip();return code[:a]+'try {\n'+''.join('    '+x+'\n' if x else '\n' for x in body.splitlines())+'} finally {\n    dir.deleteRecursively()\n}\n'+code[b+len('dir.deleteRecursively()'):]
def repair(code):
 if 'lower.close(); knife.close(); solid.close()' not in code:return code
 a=code.index('val solid = result.mesh.toSolid()');b=code.index('lower.close(); knife.close(); solid.close()',a)
 body=code[a:b].rstrip();return code[:a]+'Solid.scope {\n'+''.join('    '+x+'\n' if x else '\n' for x in body.splitlines())+'    Unit\n}\n'+code[b+len('lower.close(); knife.close(); solid.close()'):]
for path,ids,edit in [('dev_docs/agents/transcripts/geometry_from_disk.yaml',['2380c745a1d4-01'],disk),('dev_docs/agents/transcripts/mesh_repair_demo.yaml',['b34623b0e55f-01'],repair)]:
 p=Path(path);before=p.read_text();replacements=[]
 def walk(n):
  if isinstance(n,yaml.MappingNode):
   for k,v in n.value:
    if k.value=='code' and isinstance(v,yaml.ScalarNode):
     after=edit(v.value)
     if after!=v.value:
      indent=k.start_mark.column+2;replacements.append((v.start_mark.index,v.end_mark.index,'|\n'+''.join(' '*indent+x+'\n' if x else '\n' for x in after.rstrip().splitlines())))
    else:walk(v)
  elif isinstance(n,yaml.SequenceNode):
   for v in n.value:walk(v)
 walk(yaml.compose(before));after=before
 assert len(replacements)==(2 if edit==disk else 1)
 for a,b,s in sorted(replacements,reverse=True):after=after[:a]+s+after[b:]
 p.write_text(after);rows.append(dict(path=path,findings=ids,before=before,after=after))
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(H.parent/'box_code_adoption_batch_33'/name).read_text().replace('adoption-33','adoption-36').replace('ac1bd079c','62444457e');(H/name).write_text(s)
