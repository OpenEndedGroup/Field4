#version 450
#extension GL_EXT_buffer_reference : require
layout(std430, buffer_reference) readonly buffer Values { uint value; };
layout(push_constant) uniform Push { Values values; } pc;
layout(location = 0) out vec4 color;
void main() {
    // A white frame proves that both compute dispatches ran before this draw.
    color = pc.values.value == 34u ? vec4(1.0) : vec4(1.0, 0.0, 0.0, 1.0);
}
