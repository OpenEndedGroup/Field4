var module = moduleHere {
    primitiveType = triangles
    blend = false
}
val triangle = fullscreenTriangle()
check(triangle.numVert == 3)
triangle.values = { resultBuffer }
module += "fullscreen" to triangle
renderer += "approvedDraw" to module
println("fullscreen ready")
