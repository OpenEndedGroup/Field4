import afield.graphics.vulkan.util.Options

prop<Window>(window)
prop<Renderer>(renderer)
Options.enableHDR = false
Options.profiling = false
once.renderer {
    window = Window("Approved helpers rehearsal", initialDimensions = Rect(80.0, 80.0, 320.0, 240.0))
    Renderer(window)
}
start(renderer::run)
