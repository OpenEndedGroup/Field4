#version 450
#extension GL_EXT_buffer_reference : require
layout(local_size_x = 1) in;
layout(std430, buffer_reference) buffer Values { uint value; };
layout(push_constant) uniform Push { Values values; uint count; } pc;
void main() {
    pc.values.value += pc.count;
}
