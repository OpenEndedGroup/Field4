prop<FrameBufferGroup>(resultBuffer)
prop<Int>(helperCount) = 17
var module = computeModuleHere {}
resultBuffer = defaultBuffer { size = 16 }.buffer
val a = ComputeMesh()
val b = ComputeMesh()
module.zeroBefore("clear", resultBuffer)
module += "a" to a
module += "between" to computeBarrier()
module += "b" to b
module += "publish" to computeBarrier(graphics = true)
bindPush(a, b) {
    x = 1
    y = 1
    z = 1
    values = { resultBuffer }
    count = { 17 }
}
// Both unsigned source types compile through the generated binding.
b.count = { helperCount.toUInt() }
renderer += "approvedCompute" to module
println("compute ready: two uint additions with shared live bindings")
