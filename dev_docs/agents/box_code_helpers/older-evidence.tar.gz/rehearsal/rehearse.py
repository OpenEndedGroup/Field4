from pathlib import Path
import subprocess
p=Path(__file__).resolve().parent
commands=['new-box --name HelperRenderer',f'launch @last --file {p}/renderer_code_.kt','new-box --name HelperCompute','connect HelperRenderer @last',f'set @last compute --file {p}/compute.glsl',f'launch @last --file {p}/compute_code_.kt','new-box --name HelperDraw','connect HelperCompute @last',f'set @last vertex --file {p}/vertex.glsl',f'set @last fragment --file {p}/fragment.glsl',f'launch @last --file {p}/draw_code_.kt','wait-native-renderer @last --frames 20 --timeout 40',f'native-screenshot {p}/gpu.png --uid @last --wait-frames 10 --timeout 40','run HelperCompute --value "helperCount = 18"', f'native-screenshot {p}/gpu-negative.png --uid HelperDraw --wait-frames 10 --timeout 40', 'run HelperCompute --value "helperCount = 17"', f'native-screenshot {p}/gpu-restored.png --uid HelperDraw --wait-frames 10 --timeout 40', 'stop HelperRenderer', 'new-box --name OtherHelpers --x 1000 --y 0 --w 1000', f'launch @last --file {p}/other_code_.kt', f'launch @last --file {p}/other_code_.kt', f'screenshot-box @last {p}/output.png']
args=['uv','run','--project','.','--group','backdoor','python','tools/field_backdoor.py','--json','--with-playwright','--timeout','120']
for c in commands: args += ['--command',c]
raise SystemExit(subprocess.run(args).returncode)
