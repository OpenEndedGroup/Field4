import afield.app.protocol.Rect

val reducer = Reducer(Lambda.rules(), order = ActivationOrder.HIGHEST_PAIR_ENERGY)
val net = Lambda.duplicatedConstantDemo()

net.relax(20)
val beforeLines = net.toFLines()
val beforeSummary = net.summaryHtml("Before duplication", maxNodes = 5)
val detail = reducer.stepDetailed(net)!!
net.relax(28)
val afterLines = net.toFLines()
showInteractionStages(
    stage("Before", beforeLines, beforeSummary),
    stage("After", afterLines, net.summaryHtml("After", maxNodes = 5)),
    cards = listOf(detail.summaryHtml("Rewrite")),
    channel = "overview",
)

println("interaction duplication ready")
