import afield.app.protocol.Rect

val reducer = Reducer(Lambda.rules())
val subject = net {
    val fanA = node(Lambda.DUP, id = "fanA", at = vec(-80.0, 0.0), state = Lambda.fan(1))
    val fanB = node(Lambda.DUP, id = "fanB", at = vec(80.0, 0.0), state = Lambda.fan(2))
    val c1 = node(Lambda.CONST, id = "c1", at = vec(-200.0, -80.0), state = NodeState(energy = 1.0, hue = 0.04))
    val c2 = node(Lambda.CONST, id = "c2", at = vec(-200.0, 80.0), state = NodeState(energy = 1.0, hue = 0.12))
    val c3 = node(Lambda.CONST, id = "c3", at = vec(200.0, -80.0), state = NodeState(energy = 1.0, hue = 0.20))
    val c4 = node(Lambda.CONST, id = "c4", at = vec(200.0, 80.0), state = NodeState(energy = 1.0, hue = 0.28))

    fanA.principal to fanB.principal
    fanA.aux(0) to c1.principal
    fanA.aux(1) to c2.principal
    fanB.aux(0) to c3.principal
    fanB.aux(1) to c4.principal
}

subject.relax(20)
val beforeLines = subject.toFLines()
val beforeSummary = subject.summaryHtml("Before: labels 1 and 2", maxNodes = 6)

// One step, so the commuting branch can be shown on its own.
val branch = reducer.stepDetailed(subject)!!
subject.relax(24)
val middleLines = subject.toFLines()
val middleSummary = subject.summaryHtml("After fan-fan", maxNodes = 8)

// The rest of the way. This is the part a single stepDetailed cannot reach.
val rest = reducer.reduceDetailed(subject, maxSteps = 32)
subject.relax(28)
val afterLines = subject.toFLines()

showInteractionStages(
    stage("Before", beforeLines, beforeSummary),
    stage("Middle", middleLines, middleSummary),
    stage("After", afterLines, subject.summaryHtml("After", maxNodes = 8)),
    cards = listOf(branch.summaryHtml("Rewrite")),
    channel = "overview", stageWidth = 296.0, gap = 48.0,
)

println("interaction multi-step ready: 1 + $rest reactions, ${subject.nodes.size} agents left")
