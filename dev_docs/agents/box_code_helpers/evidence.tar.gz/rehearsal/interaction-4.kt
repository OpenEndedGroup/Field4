import afield.app.protocol.Rect

val reducer = Reducer(Lambda.rules())
val net = Lambda.eraseApplicationDemo()

net.relax(20)
val beforeLines = net.toFLines()
val beforeSummary = net.summaryHtml("Before erase", maxNodes = 5)
val detail = reducer.stepDetailed(net)!!
net.relax(28)
val afterLines = net.toFLines()
showInteractionStages(
    stage("Before", beforeLines, beforeSummary),
    stage("After", afterLines, net.summaryHtml("After", maxNodes = 5)),
    cards = listOf(detail.summaryHtml("Rewrite")),
    channel = "overview",
)

println("interaction erase ready")
