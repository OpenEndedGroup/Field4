import afield.lang.rectsl.*
import java.util.concurrent.CompletableFuture

val q = smoothTo<Float>(steps = 2) { 1f }
q.startAt(0f)
check(q() == 0f)
val drawing = fline { rect(-1, -1, 1, 1); grid(Rect(0.0, 0.0, 8.0, 6.0), 2, 3) }
check(drawing.nodes.size == 19)
val matrix = WallSpec(8.0, 6.0, UnitKind.Meters, Origin.Center).worldToClip()
val elapsed = bestTimeMs(repetitions = 3, warmup = 1) { drawing.nodes.size }
check(elapsed >= 0)
val client = osc(57432)
client.on("/helper-check", runOwned = true) { gather<OscServer.Message> {} }
check(client.hasHandler("/helper-check"))
runAsync(onResult = { value: Int ->
    check(value == 7)
    println("API check complete: ${drawing.nodes.size} nodes; async result=$value; timing=${elapsed}ms")
}) { CompletableFuture.completedFuture(7) }
