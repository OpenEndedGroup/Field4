external val console: dynamic
data class P(val x: Double, val y: Double) {
    operator fun plus(o: P) = P(x + o.x, y + o.y)
    fun len() = kotlin.math.sqrt(x * x + y * y)
}
fun ring(n: Int, r: Double): List<P> = (0 until n).map { i ->
    val a = 2.0 * kotlin.math.PI * i / n
    P(kotlin.math.cos(a) * r, kotlin.math.sin(a) * r)
}
val pts = ring(32, 10.0)
val centroid = pts.reduce { u, v -> u + v }
val perimeter = pts.zipWithNext { u, v -> (u + P(-v.x, -v.y)).len() }.sum()
console.log("ring: n=" + pts.size + " sum=(" + centroid.x + "," + centroid.y + ") perimeter=" + perimeter)
