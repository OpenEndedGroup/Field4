//region block: polyfills
(function () {
  if (typeof Math.imul === 'undefined') {
    Math.imul = function imul(a, b) {
      return (a & 4.29490176E9) * (b & 65535) + (a & 65535) * (b | 0) | 0;
    };
  }
}());
(function () {
  if (typeof ArrayBuffer.isView === 'undefined') {
    ArrayBuffer.isView = function (a) {
      return a != null && a.__proto__ != null && a.__proto__.__proto__ === Int8Array.prototype.__proto__;
    };
  }
}());
//endregion
var readable_sum_0 = function (_) {
  'use strict';
  //region block: imports
  var imul = Math.imul;
  var isView = ArrayBuffer.isView;
  //endregion
  //region block: pre-declaration
  initMetadataForInterface(CharSequence, 'CharSequence');
  initMetadataForClass(Number_0, 'Number');
  initMetadataForClass(Exception, 'Exception', Exception$Exception_init_$Create$, Error);
  initMetadataForClass(RuntimeException, 'RuntimeException', RuntimeException$RuntimeException_init_$Create$, Exception);
  initMetadataForClass(UnsupportedOperationException, 'UnsupportedOperationException', UnsupportedOperationException$UnsupportedOperationException_init_$Create$, RuntimeException);
  initMetadataForClass(IllegalArgumentException, 'IllegalArgumentException', IllegalArgumentException$IllegalArgumentException_init_$Create$, RuntimeException);
  initMetadataForClass(NoSuchElementException, 'NoSuchElementException', NoSuchElementException$NoSuchElementException_init_$Create$, RuntimeException);
  initMetadataForClass(IndexOutOfBoundsException, 'IndexOutOfBoundsException', IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Create$, RuntimeException);
  initMetadataForClass(IllegalStateException, 'IllegalStateException', IllegalStateException$IllegalStateException_init_$Create$, RuntimeException);
  initMetadataForClass(ArithmeticException, 'ArithmeticException', ArithmeticException$ArithmeticException_init_$Create$, RuntimeException);
  initMetadataForClass(Error_0, 'Error', Error$Error_init_$Create$, Error);
  initMetadataForClass(NoClassDefFoundError, 'NoClassDefFoundError', VOID, Error_0);
  initMetadataForClass(ExceptionInInitializerError, 'ExceptionInInitializerError', VOID, Error_0);
  initMetadataForClass(Char, 'Char');
  initMetadataForInterface(Collection, 'Collection');
  initMetadataForCompanion(List$Companion);
  initMetadataForInterface(KtList, 'List', VOID, VOID, [Collection]);
  initMetadataForCompanion(MutableList$Companion);
  initMetadataForInterface(KtMutableList, 'MutableList', VOID, VOID, [KtList, Collection]);
  initMetadataForCompanion(Long$Companion);
  initMetadataForClass(Long, 'Long', VOID, Number_0);
  initMetadataForObject(Unit, 'Unit');
  initMetadataForClass(AbstractCollection, 'AbstractCollection', VOID, VOID, [Collection]);
  initMetadataForClass(AbstractMutableCollection, 'AbstractMutableCollection', VOID, AbstractCollection, [Collection]);
  initMetadataForClass(AbstractMutableList$IteratorImpl, 'IteratorImpl');
  initMetadataForClass(AbstractMutableList, 'AbstractMutableList', VOID, AbstractMutableCollection, [KtMutableList]);
  initMetadataForCompanion(ArrayList$Companion);
  initMetadataForClass(ArrayList, 'ArrayList', ArrayList$ArrayList_init_$Create$, AbstractMutableList, [KtMutableList]);
  initMetadataForClass(KClassImpl, 'KClassImpl');
  initMetadataForClass(PrimitiveKClassImpl, 'PrimitiveKClassImpl', VOID, KClassImpl);
  initMetadataForClass(StringBuilder, 'StringBuilder', StringBuilder$StringBuilder_init_$Create$, VOID, [CharSequence]);
  initMetadataForClass(AbstractList$IteratorImpl, 'IteratorImpl');
  initMetadataForCompanion(AbstractList$Companion);
  initMetadataForClass(AbstractList, 'AbstractList', VOID, AbstractCollection, [KtList]);
  initMetadataForObject(EmptyList, 'EmptyList', VOID, VOID, [KtList]);
  initMetadataForObject(EmptyIterator, 'EmptyIterator');
  initMetadataForClass(IntIterator, 'IntIterator');
  initMetadataForCompanion(IntRange$Companion);
  initMetadataForClass(IntProgression, 'IntProgression');
  initMetadataForClass(IntRange, 'IntRange', VOID, IntProgression);
  initMetadataForClass(IntProgressionIterator, 'IntProgressionIterator', VOID, IntIterator);
  initMetadataForCompanion(IntProgression$Companion);
  initMetadataForClass(main$P, 'P');
  //endregion
  function CharSequence() {
  }
  function Number_0() {
  }
  function UnsupportedOperationException$UnsupportedOperationException_init_$Init$($this) {
    RuntimeException$RuntimeException_init_$Init$($this);
    UnsupportedOperationException.call($this);
    return $this;
  }
  function UnsupportedOperationException$UnsupportedOperationException_init_$Create$() {
    var tmp = UnsupportedOperationException$UnsupportedOperationException_init_$Init$(objectCreate(protoOf(UnsupportedOperationException)));
    captureStack(tmp, UnsupportedOperationException$UnsupportedOperationException_init_$Create$);
    return tmp;
  }
  function UnsupportedOperationException$UnsupportedOperationException_init_$Init$_0(message, $this) {
    RuntimeException$RuntimeException_init_$Init$_0(message, $this);
    UnsupportedOperationException.call($this);
    return $this;
  }
  function UnsupportedOperationException$UnsupportedOperationException_init_$Create$_0(message) {
    var tmp = UnsupportedOperationException$UnsupportedOperationException_init_$Init$_0(message, objectCreate(protoOf(UnsupportedOperationException)));
    captureStack(tmp, UnsupportedOperationException$UnsupportedOperationException_init_$Create$_0);
    return tmp;
  }
  function UnsupportedOperationException() {
    captureStack(this, UnsupportedOperationException);
  }
  function IllegalArgumentException$IllegalArgumentException_init_$Init$($this) {
    RuntimeException$RuntimeException_init_$Init$($this);
    IllegalArgumentException.call($this);
    return $this;
  }
  function IllegalArgumentException$IllegalArgumentException_init_$Create$() {
    var tmp = IllegalArgumentException$IllegalArgumentException_init_$Init$(objectCreate(protoOf(IllegalArgumentException)));
    captureStack(tmp, IllegalArgumentException$IllegalArgumentException_init_$Create$);
    return tmp;
  }
  function IllegalArgumentException$IllegalArgumentException_init_$Init$_0(message, $this) {
    RuntimeException$RuntimeException_init_$Init$_0(message, $this);
    IllegalArgumentException.call($this);
    return $this;
  }
  function IllegalArgumentException$IllegalArgumentException_init_$Create$_0(message) {
    var tmp = IllegalArgumentException$IllegalArgumentException_init_$Init$_0(message, objectCreate(protoOf(IllegalArgumentException)));
    captureStack(tmp, IllegalArgumentException$IllegalArgumentException_init_$Create$_0);
    return tmp;
  }
  function IllegalArgumentException() {
    captureStack(this, IllegalArgumentException);
  }
  function NoSuchElementException$NoSuchElementException_init_$Init$($this) {
    RuntimeException$RuntimeException_init_$Init$($this);
    NoSuchElementException.call($this);
    return $this;
  }
  function NoSuchElementException$NoSuchElementException_init_$Create$() {
    var tmp = NoSuchElementException$NoSuchElementException_init_$Init$(objectCreate(protoOf(NoSuchElementException)));
    captureStack(tmp, NoSuchElementException$NoSuchElementException_init_$Create$);
    return tmp;
  }
  function NoSuchElementException() {
    captureStack(this, NoSuchElementException);
  }
  function IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Init$($this) {
    RuntimeException$RuntimeException_init_$Init$($this);
    IndexOutOfBoundsException.call($this);
    return $this;
  }
  function IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Create$() {
    var tmp = IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Init$(objectCreate(protoOf(IndexOutOfBoundsException)));
    captureStack(tmp, IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Create$);
    return tmp;
  }
  function IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Init$_0(message, $this) {
    RuntimeException$RuntimeException_init_$Init$_0(message, $this);
    IndexOutOfBoundsException.call($this);
    return $this;
  }
  function IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Create$_0(message) {
    var tmp = IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Init$_0(message, objectCreate(protoOf(IndexOutOfBoundsException)));
    captureStack(tmp, IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Create$_0);
    return tmp;
  }
  function IndexOutOfBoundsException() {
    captureStack(this, IndexOutOfBoundsException);
  }
  function IllegalStateException$IllegalStateException_init_$Init$($this) {
    RuntimeException$RuntimeException_init_$Init$($this);
    IllegalStateException.call($this);
    return $this;
  }
  function IllegalStateException$IllegalStateException_init_$Create$() {
    var tmp = IllegalStateException$IllegalStateException_init_$Init$(objectCreate(protoOf(IllegalStateException)));
    captureStack(tmp, IllegalStateException$IllegalStateException_init_$Create$);
    return tmp;
  }
  function IllegalStateException$IllegalStateException_init_$Init$_0(message, $this) {
    RuntimeException$RuntimeException_init_$Init$_0(message, $this);
    IllegalStateException.call($this);
    return $this;
  }
  function IllegalStateException$IllegalStateException_init_$Create$_0(message) {
    var tmp = IllegalStateException$IllegalStateException_init_$Init$_0(message, objectCreate(protoOf(IllegalStateException)));
    captureStack(tmp, IllegalStateException$IllegalStateException_init_$Create$_0);
    return tmp;
  }
  function IllegalStateException() {
    captureStack(this, IllegalStateException);
  }
  function RuntimeException$RuntimeException_init_$Init$($this) {
    Exception$Exception_init_$Init$($this);
    RuntimeException.call($this);
    return $this;
  }
  function RuntimeException$RuntimeException_init_$Create$() {
    var tmp = RuntimeException$RuntimeException_init_$Init$(objectCreate(protoOf(RuntimeException)));
    captureStack(tmp, RuntimeException$RuntimeException_init_$Create$);
    return tmp;
  }
  function RuntimeException$RuntimeException_init_$Init$_0(message, $this) {
    Exception$Exception_init_$Init$_0(message, $this);
    RuntimeException.call($this);
    return $this;
  }
  function RuntimeException() {
    captureStack(this, RuntimeException);
  }
  function Exception$Exception_init_$Init$($this) {
    extendThrowable($this);
    Exception.call($this);
    return $this;
  }
  function Exception$Exception_init_$Create$() {
    var tmp = Exception$Exception_init_$Init$(objectCreate(protoOf(Exception)));
    captureStack(tmp, Exception$Exception_init_$Create$);
    return tmp;
  }
  function Exception$Exception_init_$Init$_0(message, $this) {
    extendThrowable($this, message);
    Exception.call($this);
    return $this;
  }
  function Exception() {
    captureStack(this, Exception);
  }
  function ArithmeticException$ArithmeticException_init_$Init$($this) {
    RuntimeException$RuntimeException_init_$Init$($this);
    ArithmeticException.call($this);
    return $this;
  }
  function ArithmeticException$ArithmeticException_init_$Create$() {
    var tmp = ArithmeticException$ArithmeticException_init_$Init$(objectCreate(protoOf(ArithmeticException)));
    captureStack(tmp, ArithmeticException$ArithmeticException_init_$Create$);
    return tmp;
  }
  function ArithmeticException$ArithmeticException_init_$Init$_0(message, $this) {
    RuntimeException$RuntimeException_init_$Init$_0(message, $this);
    ArithmeticException.call($this);
    return $this;
  }
  function ArithmeticException$ArithmeticException_init_$Create$_0(message) {
    var tmp = ArithmeticException$ArithmeticException_init_$Init$_0(message, objectCreate(protoOf(ArithmeticException)));
    captureStack(tmp, ArithmeticException$ArithmeticException_init_$Create$_0);
    return tmp;
  }
  function ArithmeticException() {
    captureStack(this, ArithmeticException);
  }
  function Error$Error_init_$Init$($this) {
    extendThrowable($this);
    Error_0.call($this);
    return $this;
  }
  function Error$Error_init_$Create$() {
    var tmp = Error$Error_init_$Init$(objectCreate(protoOf(Error_0)));
    captureStack(tmp, Error$Error_init_$Create$);
    return tmp;
  }
  function Error$Error_init_$Init$_0(message, $this) {
    extendThrowable($this, message);
    Error_0.call($this);
    return $this;
  }
  function Error$Error_init_$Init$_1(message, cause, $this) {
    extendThrowable($this, message, cause);
    Error_0.call($this);
    return $this;
  }
  function Error_0() {
    captureStack(this, Error_0);
  }
  function NoClassDefFoundError$NoClassDefFoundError_init_$Init$(message, $this) {
    Error$Error_init_$Init$_0(message, $this);
    NoClassDefFoundError.call($this);
    return $this;
  }
  function NoClassDefFoundError$NoClassDefFoundError_init_$Create$(message) {
    var tmp = NoClassDefFoundError$NoClassDefFoundError_init_$Init$(message, objectCreate(protoOf(NoClassDefFoundError)));
    captureStack(tmp, NoClassDefFoundError$NoClassDefFoundError_init_$Create$);
    return tmp;
  }
  function NoClassDefFoundError() {
    captureStack(this, NoClassDefFoundError);
  }
  function ExceptionInInitializerError$ExceptionInInitializerError_init_$Init$(cause, $this) {
    Error$Error_init_$Init$_1(null, cause, $this);
    ExceptionInInitializerError.call($this);
    return $this;
  }
  function ExceptionInInitializerError$ExceptionInInitializerError_init_$Create$(cause) {
    var tmp = ExceptionInInitializerError$ExceptionInInitializerError_init_$Init$(cause, objectCreate(protoOf(ExceptionInInitializerError)));
    captureStack(tmp, ExceptionInInitializerError$ExceptionInInitializerError_init_$Create$);
    return tmp;
  }
  function ExceptionInInitializerError() {
    captureStack(this, ExceptionInInitializerError);
  }
  function staticInitializationFailure(reason, className) {
    if (reason instanceof Error_0)
      throw reason;
    else {
      if (reason == null) {
        var tmp;
        if (className == null) {
          tmp = null;
        } else {
          // Inline function 'kotlin.let' call
          tmp = 'class ' + className;
        }
        var tmp2_elvis_lhs = tmp;
        var message = 'Could not initialize ' + (tmp2_elvis_lhs == null ? 'file' : tmp2_elvis_lhs);
        throw NoClassDefFoundError$NoClassDefFoundError_init_$Create$(message);
      } else {
        throw ExceptionInInitializerError$ExceptionInInitializerError_init_$Create$(reason);
      }
    }
  }
  function joinToString(_this__u8e3s4, separator, prefix, postfix, limit, truncated, transform) {
    separator = separator === VOID ? ', ' : separator;
    prefix = prefix === VOID ? '' : prefix;
    postfix = postfix === VOID ? '' : postfix;
    limit = limit === VOID ? -1 : limit;
    truncated = truncated === VOID ? '...' : truncated;
    transform = transform === VOID ? null : transform;
    return joinTo(_this__u8e3s4, StringBuilder$StringBuilder_init_$Create$(), separator, prefix, postfix, limit, truncated, transform).toString();
  }
  function joinTo(_this__u8e3s4, buffer, separator, prefix, postfix, limit, truncated, transform) {
    separator = separator === VOID ? ', ' : separator;
    prefix = prefix === VOID ? '' : prefix;
    postfix = postfix === VOID ? '' : postfix;
    limit = limit === VOID ? -1 : limit;
    truncated = truncated === VOID ? '...' : truncated;
    transform = transform === VOID ? null : transform;
    buffer.append_jgojdo_k$(prefix);
    var count = 0;
    var inductionVariable = 0;
    var last = _this__u8e3s4.length;
    $l$loop: while (inductionVariable < last) {
      var element = _this__u8e3s4[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      count = count + 1 | 0;
      if (count > 1) {
        buffer.append_jgojdo_k$(separator);
      }
      if (limit < 0 || count <= limit) {
        appendElement(buffer, element, transform);
      } else
        break $l$loop;
    }
    if (limit >= 0 && count > limit) {
      buffer.append_jgojdo_k$(truncated);
    }
    buffer.append_jgojdo_k$(postfix);
    return buffer;
  }
  function joinToString_0(_this__u8e3s4, separator, prefix, postfix, limit, truncated, transform) {
    separator = separator === VOID ? ', ' : separator;
    prefix = prefix === VOID ? '' : prefix;
    postfix = postfix === VOID ? '' : postfix;
    limit = limit === VOID ? -1 : limit;
    truncated = truncated === VOID ? '...' : truncated;
    transform = transform === VOID ? null : transform;
    return joinTo_0(_this__u8e3s4, StringBuilder$StringBuilder_init_$Create$(), separator, prefix, postfix, limit, truncated, transform).toString();
  }
  function joinTo_0(_this__u8e3s4, buffer, separator, prefix, postfix, limit, truncated, transform) {
    separator = separator === VOID ? ', ' : separator;
    prefix = prefix === VOID ? '' : prefix;
    postfix = postfix === VOID ? '' : postfix;
    limit = limit === VOID ? -1 : limit;
    truncated = truncated === VOID ? '...' : truncated;
    transform = transform === VOID ? null : transform;
    buffer.append_jgojdo_k$(prefix);
    var count = 0;
    var _iterator__ex2g4s = _this__u8e3s4.iterator_jk1svi_k$();
    $l$loop: while (_iterator__ex2g4s.hasNext_bitz1p_k$()) {
      var element = _iterator__ex2g4s.next_20eer_k$();
      count = count + 1 | 0;
      if (count > 1) {
        buffer.append_jgojdo_k$(separator);
      }
      if (limit < 0 || count <= limit) {
        appendElement(buffer, element, transform);
      } else
        break $l$loop;
    }
    if (limit >= 0 && count > limit) {
      buffer.append_jgojdo_k$(truncated);
    }
    buffer.append_jgojdo_k$(postfix);
    return buffer;
  }
  function sum(_this__u8e3s4) {
    var sum = 0.0;
    var _iterator__ex2g4s = _this__u8e3s4.iterator_jk1svi_k$();
    while (_iterator__ex2g4s.hasNext_bitz1p_k$()) {
      var element = _iterator__ex2g4s.next_20eer_k$();
      sum = sum + element;
    }
    return sum;
  }
  function until(_this__u8e3s4, to) {
    if (to <= -2147483648)
      return IntRange$Companion$getInstance().EMPTY_1;
    return numberRangeToNumber(_this__u8e3s4, to - 1 | 0);
  }
  function Char$_get_value__jhhj6a($this) {
    return $this;
  }
  function toString($this) {
    // Inline function 'kotlin.js.unsafeCast' call
    return String.fromCharCode(Char$_get_value__jhhj6a($this));
  }
  function Char() {
  }
  function Collection() {
  }
  var List$Companion$instance;
  var List$static_init_state;
  function List$Companion() {
  }
  function KtList() {
  }
  var MutableList$Companion$instance;
  var MutableList$static_init_state;
  function MutableList$static_init() {
    var state = MutableList$static_init_state;
    if (!state)
      return Unit$instance;
    if (state === 2) {
      staticInitializationFailureWithClassName(KtMutableList);
    }
    MutableList$static_init_state = 0;
    try {
      if (MutableList$Companion$instance == null)
        new MutableList$Companion();
    } catch ($p) {
      var reason = $p;
      MutableList$static_init_state = 2;
      staticInitializationFailure(reason);
    }
  }
  function MutableList$Companion() {
    MutableList$Companion$instance = this;
  }
  function KtMutableList() {
  }
  function toString_0(_this__u8e3s4) {
    var tmp1_elvis_lhs = _this__u8e3s4 == null ? null : toString_1(_this__u8e3s4);
    return tmp1_elvis_lhs == null ? 'null' : tmp1_elvis_lhs;
  }
  var Long$Companion$instance;
  function Long$Companion$getInstance() {
    Long$static_init();
    return Long$Companion$instance;
  }
  var Long$static_init_state;
  function Long$static_init() {
    var state = Long$static_init_state;
    if (!state)
      return Unit$instance;
    if (state === 2) {
      staticInitializationFailureWithClassName(Long);
    }
    Long$static_init_state = 0;
    try {
      if (Long$Companion$instance == null)
        new Long$Companion();
    } catch ($p) {
      var reason = $p;
      Long$static_init_state = 2;
      staticInitializationFailure(reason);
    }
  }
  function Long$Companion() {
    Long$Companion$instance = this;
    this.MIN_VALUE_1 = new Long(0, -2147483648);
    this.MAX_VALUE_1 = new Long(-1, 2147483647);
    this.SIZE_BYTES_1 = 8;
    this.SIZE_BITS_1 = 64;
  }
  function Long(low, high) {
    Long$Companion$getInstance();
    Long$static_init();
    Number_0.call(this);
    this.low_1 = low;
    this.high_1 = high;
  }
  protoOf(Long).toString = function () {
    return toStringImpl(this, 10);
  };
  protoOf(Long).valueOf = function () {
    return toNumber(this);
  };
  function get_ZERO() {
    _init_properties_boxedLong_kt__v24qrw();
    return ZERO;
  }
  var ZERO;
  function get_ONE() {
    _init_properties_boxedLong_kt__v24qrw();
    return ONE;
  }
  var ONE;
  function get_NEG_ONE() {
    _init_properties_boxedLong_kt__v24qrw();
    return NEG_ONE;
  }
  var NEG_ONE;
  function get_MAX_VALUE() {
    _init_properties_boxedLong_kt__v24qrw();
    return MAX_VALUE;
  }
  var MAX_VALUE;
  function get_MIN_VALUE() {
    _init_properties_boxedLong_kt__v24qrw();
    return MIN_VALUE;
  }
  var MIN_VALUE;
  function get_TWO_PWR_24_() {
    _init_properties_boxedLong_kt__v24qrw();
    return TWO_PWR_24_;
  }
  var TWO_PWR_24_;
  var longArrayClass;
  function compare(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    if (equalsLong(_this__u8e3s4, other)) {
      return 0;
    }
    var thisNeg = isNegative(_this__u8e3s4);
    var otherNeg = isNegative(other);
    return thisNeg && !otherNeg ? -1 : !thisNeg && otherNeg ? 1 : isNegative(subtract(_this__u8e3s4, other)) ? -1 : 1;
  }
  function convertToInt(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return _this__u8e3s4.low_1;
  }
  function toNumber(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return _this__u8e3s4.high_1 * 4.294967296E9 + getLowBitsUnsigned(_this__u8e3s4);
  }
  function toStringImpl(_this__u8e3s4, radix) {
    _init_properties_boxedLong_kt__v24qrw();
    if (isZero(_this__u8e3s4)) {
      return '0';
    }
    if (isNegative(_this__u8e3s4)) {
      if (equalsLong(_this__u8e3s4, get_MIN_VALUE())) {
        var radixLong = fromInt(radix);
        var div = divide(_this__u8e3s4, radixLong);
        var rem = convertToInt(subtract(multiply(div, radixLong), _this__u8e3s4));
        var tmp = toStringImpl(div, radix);
        // Inline function 'kotlin.js.asDynamic' call
        // Inline function 'kotlin.js.unsafeCast' call
        return tmp + rem.toString(radix);
      } else {
        return '-' + toStringImpl(negate(_this__u8e3s4), radix);
      }
    }
    var digitsPerTime = radix === 2 ? 31 : radix <= 10 ? 9 : radix <= 21 ? 7 : radix <= 35 ? 6 : 5;
    var radixToPower = fromNumber(Math.pow(radix, digitsPerTime));
    var rem_0 = _this__u8e3s4;
    var result = '';
    while (true) {
      var remDiv = divide(rem_0, radixToPower);
      var intval = convertToInt(subtract(rem_0, multiply(remDiv, radixToPower)));
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.js.unsafeCast' call
      var digits = intval.toString(radix);
      rem_0 = remDiv;
      if (isZero(rem_0)) {
        return digits + result;
      } else {
        while (digits.length < digitsPerTime) {
          digits = '0' + digits;
        }
        result = digits + result;
      }
    }
  }
  function equalsLong(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    return _this__u8e3s4.high_1 === other.high_1 && _this__u8e3s4.low_1 === other.low_1;
  }
  function fromInt(value) {
    _init_properties_boxedLong_kt__v24qrw();
    return new Long(value, value < 0 ? -1 : 0);
  }
  function isNegative(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return _this__u8e3s4.high_1 < 0;
  }
  function subtract(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    return add(_this__u8e3s4, negate(other));
  }
  function getLowBitsUnsigned(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return _this__u8e3s4.low_1 >= 0 ? _this__u8e3s4.low_1 : 4.294967296E9 + _this__u8e3s4.low_1;
  }
  function isZero(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return _this__u8e3s4.high_1 === 0 && _this__u8e3s4.low_1 === 0;
  }
  function multiply(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    if (isZero(_this__u8e3s4)) {
      return get_ZERO();
    } else if (isZero(other)) {
      return get_ZERO();
    }
    if (equalsLong(_this__u8e3s4, get_MIN_VALUE())) {
      return isOdd(other) ? get_MIN_VALUE() : get_ZERO();
    } else if (equalsLong(other, get_MIN_VALUE())) {
      return isOdd(_this__u8e3s4) ? get_MIN_VALUE() : get_ZERO();
    }
    if (isNegative(_this__u8e3s4)) {
      var tmp;
      if (isNegative(other)) {
        tmp = multiply(negate(_this__u8e3s4), negate(other));
      } else {
        tmp = negate(multiply(negate(_this__u8e3s4), other));
      }
      return tmp;
    } else if (isNegative(other)) {
      return negate(multiply(_this__u8e3s4, negate(other)));
    }
    if (lessThan(_this__u8e3s4, get_TWO_PWR_24_()) && lessThan(other, get_TWO_PWR_24_())) {
      return fromNumber(toNumber(_this__u8e3s4) * toNumber(other));
    }
    var a48 = _this__u8e3s4.high_1 >>> 16 | 0;
    var a32 = _this__u8e3s4.high_1 & 65535;
    var a16 = _this__u8e3s4.low_1 >>> 16 | 0;
    var a00 = _this__u8e3s4.low_1 & 65535;
    var b48 = other.high_1 >>> 16 | 0;
    var b32 = other.high_1 & 65535;
    var b16 = other.low_1 >>> 16 | 0;
    var b00 = other.low_1 & 65535;
    var c48 = 0;
    var c32 = 0;
    var c16 = 0;
    var c00 = 0;
    c00 = c00 + imul(a00, b00) | 0;
    c16 = c16 + (c00 >>> 16 | 0) | 0;
    c00 = c00 & 65535;
    c16 = c16 + imul(a16, b00) | 0;
    c32 = c32 + (c16 >>> 16 | 0) | 0;
    c16 = c16 & 65535;
    c16 = c16 + imul(a00, b16) | 0;
    c32 = c32 + (c16 >>> 16 | 0) | 0;
    c16 = c16 & 65535;
    c32 = c32 + imul(a32, b00) | 0;
    c48 = c48 + (c32 >>> 16 | 0) | 0;
    c32 = c32 & 65535;
    c32 = c32 + imul(a16, b16) | 0;
    c48 = c48 + (c32 >>> 16 | 0) | 0;
    c32 = c32 & 65535;
    c32 = c32 + imul(a00, b32) | 0;
    c48 = c48 + (c32 >>> 16 | 0) | 0;
    c32 = c32 & 65535;
    c48 = c48 + (((imul(a48, b00) + imul(a32, b16) | 0) + imul(a16, b32) | 0) + imul(a00, b48) | 0) | 0;
    c48 = c48 & 65535;
    return new Long(c16 << 16 | c00, c48 << 16 | c32);
  }
  function negate(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return add(invert(_this__u8e3s4), new Long(1, 0));
  }
  function fromNumber(value) {
    _init_properties_boxedLong_kt__v24qrw();
    if (isNaN_0(value)) {
      return get_ZERO();
    } else if (value <= -9.223372036854776E18) {
      return get_MIN_VALUE();
    } else if (value + 1 >= 9.223372036854776E18) {
      return get_MAX_VALUE();
    } else if (value < 0) {
      return negate(fromNumber(-value));
    } else {
      var twoPwr32 = 4.294967296E9;
      // Inline function 'kotlin.js.jsBitwiseOr' call
      var tmp = value % twoPwr32 | 0;
      // Inline function 'kotlin.js.jsBitwiseOr' call
      var tmp$ret$1 = value / twoPwr32 | 0;
      return new Long(tmp, tmp$ret$1);
    }
  }
  function add(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    var a48 = _this__u8e3s4.high_1 >>> 16 | 0;
    var a32 = _this__u8e3s4.high_1 & 65535;
    var a16 = _this__u8e3s4.low_1 >>> 16 | 0;
    var a00 = _this__u8e3s4.low_1 & 65535;
    var b48 = other.high_1 >>> 16 | 0;
    var b32 = other.high_1 & 65535;
    var b16 = other.low_1 >>> 16 | 0;
    var b00 = other.low_1 & 65535;
    var c48 = 0;
    var c32 = 0;
    var c16 = 0;
    var c00 = 0;
    c00 = c00 + (a00 + b00 | 0) | 0;
    c16 = c16 + (c00 >>> 16 | 0) | 0;
    c00 = c00 & 65535;
    c16 = c16 + (a16 + b16 | 0) | 0;
    c32 = c32 + (c16 >>> 16 | 0) | 0;
    c16 = c16 & 65535;
    c32 = c32 + (a32 + b32 | 0) | 0;
    c48 = c48 + (c32 >>> 16 | 0) | 0;
    c32 = c32 & 65535;
    c48 = c48 + (a48 + b48 | 0) | 0;
    c48 = c48 & 65535;
    return new Long(c16 << 16 | c00, c48 << 16 | c32);
  }
  function isOdd(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return (_this__u8e3s4.low_1 & 1) === 1;
  }
  function lessThan(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    return compare(_this__u8e3s4, other) < 0;
  }
  function invert(_this__u8e3s4) {
    _init_properties_boxedLong_kt__v24qrw();
    return new Long(~_this__u8e3s4.low_1, ~_this__u8e3s4.high_1);
  }
  function divide(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    if (isZero(other)) {
      throw ArithmeticException$ArithmeticException_init_$Create$_0('/ by zero');
    } else if (isZero(_this__u8e3s4)) {
      return get_ZERO();
    }
    if (equalsLong(_this__u8e3s4, get_MIN_VALUE())) {
      if (equalsLong(other, get_ONE()) || equalsLong(other, get_NEG_ONE())) {
        return get_MIN_VALUE();
      } else if (equalsLong(other, get_MIN_VALUE())) {
        return get_ONE();
      } else {
        var halfThis = shiftRight(_this__u8e3s4, 1);
        var approx = shiftLeft(divide(halfThis, other), 1);
        if (equalsLong(approx, get_ZERO())) {
          return isNegative(other) ? get_ONE() : get_NEG_ONE();
        } else {
          var rem = subtract(_this__u8e3s4, multiply(other, approx));
          return add(approx, divide(rem, other));
        }
      }
    } else if (equalsLong(other, get_MIN_VALUE())) {
      return get_ZERO();
    }
    if (isNegative(_this__u8e3s4)) {
      var tmp;
      if (isNegative(other)) {
        tmp = divide(negate(_this__u8e3s4), negate(other));
      } else {
        tmp = negate(divide(negate(_this__u8e3s4), other));
      }
      return tmp;
    } else if (isNegative(other)) {
      return negate(divide(_this__u8e3s4, negate(other)));
    }
    var res = get_ZERO();
    var rem_0 = _this__u8e3s4;
    while (greaterThanOrEqual(rem_0, other)) {
      var approxDouble = toNumber(rem_0) / toNumber(other);
      var approx2 = Math.max(1.0, Math.floor(approxDouble));
      var log2 = Math.ceil(Math.log(approx2) / Math.LN2);
      var delta = log2 <= 48 ? 1.0 : Math.pow(2.0, log2 - 48);
      var approxRes = fromNumber(approx2);
      var approxRem = multiply(approxRes, other);
      while (isNegative(approxRem) || greaterThan(approxRem, rem_0)) {
        approx2 = approx2 - delta;
        approxRes = fromNumber(approx2);
        approxRem = multiply(approxRes, other);
      }
      if (isZero(approxRes)) {
        approxRes = get_ONE();
      }
      res = add(res, approxRes);
      rem_0 = subtract(rem_0, approxRem);
    }
    return res;
  }
  function shiftRight(_this__u8e3s4, numBits) {
    _init_properties_boxedLong_kt__v24qrw();
    var numBits_0 = numBits & 63;
    if (numBits_0 === 0) {
      return _this__u8e3s4;
    } else {
      if (numBits_0 < 32) {
        return new Long(_this__u8e3s4.low_1 >>> numBits_0 | 0 | _this__u8e3s4.high_1 << (32 - numBits_0 | 0), _this__u8e3s4.high_1 >> numBits_0);
      } else {
        return new Long(_this__u8e3s4.high_1 >> (numBits_0 - 32 | 0), _this__u8e3s4.high_1 >= 0 ? 0 : -1);
      }
    }
  }
  function shiftLeft(_this__u8e3s4, numBits) {
    _init_properties_boxedLong_kt__v24qrw();
    var numBits_0 = numBits & 63;
    if (numBits_0 === 0) {
      return _this__u8e3s4;
    } else {
      if (numBits_0 < 32) {
        return new Long(_this__u8e3s4.low_1 << numBits_0, _this__u8e3s4.high_1 << numBits_0 | (_this__u8e3s4.low_1 >>> (32 - numBits_0 | 0) | 0));
      } else {
        return new Long(0, _this__u8e3s4.low_1 << (numBits_0 - 32 | 0));
      }
    }
  }
  function greaterThan(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    return compare(_this__u8e3s4, other) > 0;
  }
  function greaterThanOrEqual(_this__u8e3s4, other) {
    _init_properties_boxedLong_kt__v24qrw();
    return compare(_this__u8e3s4, other) >= 0;
  }
  function isLongArray(a) {
    _init_properties_boxedLong_kt__v24qrw();
    return isJsArray(a) && a.$type$ === 'LongArray';
  }
  function longArrayClass$lambda(it) {
    _init_properties_boxedLong_kt__v24qrw();
    return !(it == null) ? isLongArray(it) : false;
  }
  var properties_initialized_boxedLong_kt_lfwt2;
  function _init_properties_boxedLong_kt__v24qrw() {
    var state = properties_initialized_boxedLong_kt_lfwt2;
    if (!state)
      return Unit$instance;
    if (state === 2)
      staticInitializationFailureWithClassName();
    properties_initialized_boxedLong_kt_lfwt2 = 0;
    try {
      ZERO = fromInt(0);
      ONE = fromInt(1);
      NEG_ONE = fromInt(-1);
      MAX_VALUE = new Long(-1, 2147483647);
      MIN_VALUE = new Long(0, -2147483648);
      TWO_PWR_24_ = fromInt(16777216);
      // Inline function 'kotlin.js.unsafeCast' call
      var tmp = Array;
      longArrayClass = new PrimitiveKClassImpl(tmp, 'LongArray', longArrayClass$lambda);
    } catch ($p) {
      var reason = $p;
      properties_initialized_boxedLong_kt_lfwt2 = 2;
      staticInitializationFailure(reason);
    }
  }
  function arrayToString(array) {
    return joinToString(array, ', ', '[', ']', VOID, VOID, arrayToString$lambda);
  }
  function arrayToString$lambda(it) {
    return toString_1(it);
  }
  function objectCreate(proto) {
    proto = proto === VOID ? null : proto;
    return Object.create(proto);
  }
  function defineProp(obj, name, getter, setter, enumerable) {
    return Object.defineProperty(obj, name, {configurable: true, get: getter, set: setter, enumerable: enumerable});
  }
  function toString_1(o) {
    var tmp;
    if (o == null) {
      tmp = 'null';
    } else if (isArrayish(o)) {
      tmp = '[...]';
    } else if (!(typeof o.toString === 'function')) {
      tmp = anyToString(o);
    } else {
      // Inline function 'kotlin.js.unsafeCast' call
      tmp = o.toString();
    }
    return tmp;
  }
  function anyToString(o) {
    return Object.prototype.toString.call(o);
  }
  function unboxIntrinsic(x) {
    // Inline function 'kotlin.error' call
    var message = 'Should be lowered';
    throw IllegalStateException$IllegalStateException_init_$Create$_0(toString_1(message));
  }
  function captureStack(instance, constructorFunction) {
    if (Error.captureStackTrace != null) {
      Error.captureStackTrace(instance, constructorFunction);
    } else {
      // Inline function 'kotlin.js.asDynamic' call
      instance.stack = (new Error()).stack;
    }
  }
  function protoOf(constructor) {
    return constructor.prototype;
  }
  function defineMessage(message, cause) {
    var tmp;
    if (isUndefined(message)) {
      var tmp_0;
      if (isUndefined(cause)) {
        tmp_0 = message;
      } else {
        var tmp1_elvis_lhs = cause == null ? null : cause.toString();
        tmp_0 = tmp1_elvis_lhs == null ? VOID : tmp1_elvis_lhs;
      }
      tmp = tmp_0;
    } else {
      tmp = message == null ? VOID : message;
    }
    return tmp;
  }
  function isUndefined(value) {
    return value === VOID;
  }
  function extendThrowable(this_, message, cause) {
    defineFieldOnInstance(this_, 'message', defineMessage(message, cause));
    defineFieldOnInstance(this_, 'cause', cause);
    defineFieldOnInstance(this_, 'name', Object.getPrototypeOf(this_).constructor.name);
  }
  function defineFieldOnInstance(this_, name, value) {
    Object.defineProperty(this_, name, {configurable: true, writable: true, value: value});
  }
  function jsGenerateInterfaceSymbol() {
    return generateInterfaceSymbolById();
  }
  function createMetadata(kind, name, defaultConstructor, associatedObjectKey, associatedObjects, suspendArity) {
    var undef = VOID;
    return {kind: kind, simpleName: name, associatedObjectKey: associatedObjectKey, associatedObjects: associatedObjects, suspendArity: suspendArity, $kClass$: undef, defaultConstructor: defaultConstructor};
  }
  function initMetadataForClass(ctor, name, defaultConstructor, parent, interfaces, suspendArity, associatedObjectKey, associatedObjects) {
    var kind = 'class';
    initMetadataFor(kind, ctor, name, defaultConstructor, parent, interfaces, suspendArity, associatedObjectKey, associatedObjects);
  }
  function initMetadataFor(kind, ctor, name, defaultConstructor, parent, interfaces, suspendArity, associatedObjectKey, associatedObjects) {
    if (!(parent == null)) {
      ctor.prototype = Object.create(parent.prototype);
      ctor.prototype.constructor = ctor;
    }
    var metadata = createMetadata(kind, name, defaultConstructor, associatedObjectKey, associatedObjects, suspendArity);
    ctor.$metadata$ = metadata;
    var prototype = ctor.prototype;
    if (!(interfaces == null)) {
      var inductionVariable = 0;
      var last = interfaces.length;
      while (inductionVariable < last) {
        var i = interfaces[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        Object.assign(prototype, i.prototype);
        prototype[i.Symbol] = true;
      }
    }
    if (kind === 'interface') {
      ctor.Symbol = generateInterfaceSymbolById();
    }
  }
  function generateInterfaceSymbolById() {
    return '#__interface_' + generateInterfaceId();
  }
  function generateInterfaceId() {
    if (globalInterfaceId === VOID) {
      globalInterfaceId = 0;
    }
    // Inline function 'kotlin.js.unsafeCast' call
    globalInterfaceId = globalInterfaceId + 1 | 0;
    return globalInterfaceId;
  }
  var globalInterfaceId;
  function initMetadataForObject(ctor, name, defaultConstructor, parent, interfaces, suspendArity, associatedObjectKey, associatedObjects) {
    var kind = 'object';
    initMetadataFor(kind, ctor, name, defaultConstructor, parent, interfaces, suspendArity, associatedObjectKey, associatedObjects);
  }
  function initMetadataForInterface(ctor, name, defaultConstructor, parent, interfaces, suspendArity, associatedObjectKey, associatedObjects) {
    var kind = 'interface';
    initMetadataFor(kind, ctor, name, defaultConstructor, parent, interfaces, suspendArity, associatedObjectKey, associatedObjects);
  }
  function initMetadataForLambda(ctor, parent, interfaces, suspendArity) {
    initMetadataForClass(ctor, 'Lambda', VOID, parent, interfaces, suspendArity);
  }
  function initMetadataForCoroutine(ctor, parent, interfaces, suspendArity) {
    initMetadataForClass(ctor, 'Coroutine', VOID, parent, interfaces, suspendArity);
  }
  function initMetadataForFunctionReference(ctor, parent, interfaces, suspendArity) {
    initMetadataForClass(ctor, 'FunctionReference', VOID, parent, interfaces, suspendArity);
  }
  function initMetadataForCompanion(ctor, parent, interfaces, suspendArity) {
    initMetadataForObject(ctor, 'Companion', VOID, parent, interfaces, suspendArity);
  }
  function numberRangeToNumber(start, endInclusive) {
    return new IntRange(start, endInclusive);
  }
  function staticInitializationFailureWithClassName(ctor) {
    var tmp1_safe_receiver = ctor == null ? null : ctor.$metadata$;
    staticInitializationFailure(null, tmp1_safe_receiver == null ? null : tmp1_safe_receiver.simpleName);
  }
  function isArrayish(o) {
    return isJsArray(o) || isView(o);
  }
  function isJsArray(obj) {
    // Inline function 'kotlin.js.unsafeCast' call
    return Array.isArray(obj);
  }
  function isInterface(obj, iface) {
    return obj[iface.Symbol] === true;
  }
  function isCharSequence(value) {
    return typeof value === 'string' || isInterface(value, CharSequence);
  }
  var VOID;
  function isNaN_0(_this__u8e3s4) {
    return Number.isNaN(_this__u8e3s4);
  }
  var Unit$instance;
  function Unit$getInstance() {
    return Unit$instance;
  }
  function Unit() {
  }
  protoOf(Unit).toString = function () {
    return 'kotlin.Unit';
  };
  function collectionToArray(collection) {
    return collectionToArrayCommonImpl(collection);
  }
  function AbstractMutableCollection() {
    AbstractCollection.call(this);
  }
  protoOf(AbstractMutableCollection).toJSON = function () {
    return this.toArray();
  };
  protoOf(AbstractMutableCollection).checkIsMutable_jn1ih0_k$ = function () {
  };
  var AbstractMutableList$static_init_state;
  function AbstractMutableList$static_init() {
    var state = AbstractMutableList$static_init_state;
    if (!state)
      return Unit$instance;
    if (state === 2) {
      staticInitializationFailureWithClassName(AbstractMutableList);
    }
    AbstractMutableList$static_init_state = 0;
    try {
      MutableList$static_init();
    } catch ($p) {
      var reason = $p;
      AbstractMutableList$static_init_state = 2;
      staticInitializationFailure(reason);
    }
  }
  function AbstractMutableList$IteratorImpl($outer) {
    this.$this_1 = $outer;
    this.index_1 = 0;
    this.last_1 = -1;
  }
  protoOf(AbstractMutableList$IteratorImpl).hasNext_bitz1p_k$ = function () {
    return this.index_1 < this.$this_1.get_size_woubt6_k$();
  };
  protoOf(AbstractMutableList$IteratorImpl).next_20eer_k$ = function () {
    if (!this.hasNext_bitz1p_k$())
      throw NoSuchElementException$NoSuchElementException_init_$Create$();
    var tmp = this;
    var _unary__edvuaz = this.index_1;
    this.index_1 = _unary__edvuaz + 1 | 0;
    tmp.last_1 = _unary__edvuaz;
    return this.$this_1.get_c1px32_k$(this.last_1);
  };
  function AbstractMutableList() {
    AbstractMutableList$static_init();
    AbstractMutableCollection.call(this);
    this.modCount_1 = 0;
  }
  protoOf(AbstractMutableList).add_utx5q5_k$ = function (element) {
    this.checkIsMutable_jn1ih0_k$();
    this.add_dl6gt3_k$(this.get_size_woubt6_k$(), element);
    return true;
  };
  protoOf(AbstractMutableList).iterator_jk1svi_k$ = function () {
    return new AbstractMutableList$IteratorImpl(this);
  };
  var ArrayList$Companion$instance;
  function ArrayList$Companion$getInstance() {
    ArrayList$static_init();
    return ArrayList$Companion$instance;
  }
  var ArrayList$static_init_state;
  function ArrayList$static_init() {
    var state = ArrayList$static_init_state;
    if (!state)
      return Unit$instance;
    if (state === 2) {
      staticInitializationFailureWithClassName(ArrayList);
    }
    ArrayList$static_init_state = 0;
    try {
      AbstractMutableList$static_init();
      MutableList$static_init();
      if (ArrayList$Companion$instance == null)
        new ArrayList$Companion();
    } catch ($p) {
      var reason = $p;
      ArrayList$static_init_state = 2;
      staticInitializationFailure(reason);
    }
  }
  function ArrayList$Companion() {
    ArrayList$Companion$instance = this;
    var tmp = this;
    // Inline function 'kotlin.also' call
    var this_0 = ArrayList$ArrayList_init_$Create$_0(0);
    this_0.isReadOnly_1 = true;
    tmp.Empty_1 = this_0;
  }
  function ArrayList$ArrayList_init_$Init$($this) {
    ArrayList$static_init();
    // Inline function 'kotlin.emptyArray' call
    var tmp$ret$0 = [];
    ArrayList.call($this, tmp$ret$0);
    return $this;
  }
  function ArrayList$ArrayList_init_$Create$() {
    return ArrayList$ArrayList_init_$Init$(objectCreate(protoOf(ArrayList)));
  }
  function ArrayList$ArrayList_init_$Init$_0(initialCapacity, $this) {
    ArrayList$static_init();
    // Inline function 'kotlin.emptyArray' call
    var tmp$ret$0 = [];
    ArrayList.call($this, tmp$ret$0);
    // Inline function 'kotlin.require' call
    if (!(initialCapacity >= 0)) {
      var message = 'Negative initial capacity: ' + initialCapacity;
      throw IllegalArgumentException$IllegalArgumentException_init_$Create$_0(toString_1(message));
    }
    return $this;
  }
  function ArrayList$ArrayList_init_$Create$_0(initialCapacity) {
    return ArrayList$ArrayList_init_$Init$_0(initialCapacity, objectCreate(protoOf(ArrayList)));
  }
  function ArrayList$rangeCheck($this, index) {
    // Inline function 'kotlin.apply' call
    AbstractList$Companion$getInstance().checkElementIndex_s0yg86_k$(index, $this.get_size_woubt6_k$());
    return index;
  }
  function ArrayList$insertionRangeCheck($this, index) {
    // Inline function 'kotlin.apply' call
    AbstractList$Companion$getInstance().checkPositionIndex_w4k0on_k$(index, $this.get_size_woubt6_k$());
    return index;
  }
  function ArrayList(array) {
    ArrayList$Companion$getInstance();
    ArrayList$static_init();
    AbstractMutableList.call(this);
    this.array_1 = array;
    this.isReadOnly_1 = false;
  }
  protoOf(ArrayList).get_size_woubt6_k$ = function () {
    return this.array_1.length;
  };
  protoOf(ArrayList).get_c1px32_k$ = function (index) {
    return this.array_1[ArrayList$rangeCheck(this, index)];
  };
  protoOf(ArrayList).add_utx5q5_k$ = function (element) {
    this.checkIsMutable_jn1ih0_k$();
    // Inline function 'kotlin.js.asDynamic' call
    this.array_1.push(element);
    this.modCount_1 = this.modCount_1 + 1 | 0;
    return true;
  };
  protoOf(ArrayList).add_dl6gt3_k$ = function (index, element) {
    this.checkIsMutable_jn1ih0_k$();
    // Inline function 'kotlin.js.asDynamic' call
    this.array_1.splice(ArrayList$insertionRangeCheck(this, index), 0, element);
    this.modCount_1 = this.modCount_1 + 1 | 0;
  };
  protoOf(ArrayList).toString = function () {
    return arrayToString(this.array_1);
  };
  protoOf(ArrayList).toArray_jjyjqa_k$ = function () {
    return [].slice.call(this.array_1);
  };
  protoOf(ArrayList).toArray = function () {
    return this.toArray_jjyjqa_k$();
  };
  protoOf(ArrayList).checkIsMutable_jn1ih0_k$ = function () {
    if (this.isReadOnly_1)
      throw UnsupportedOperationException$UnsupportedOperationException_init_$Create$();
  };
  function PrimitiveKClassImpl(jClass, simpleName, isInstanceFunction) {
    KClassImpl.call(this);
    this.jClass_1 = jClass;
    this.simpleName_1 = simpleName;
    this.isInstanceFunction_1 = isInstanceFunction;
  }
  protoOf(PrimitiveKClassImpl).get_simpleName_r6f8py_k$ = function () {
    return this.simpleName_1;
  };
  function KClassImpl() {
  }
  protoOf(KClassImpl).toString = function () {
    return 'class ' + this.get_simpleName_r6f8py_k$();
  };
  function StringBuilder$StringBuilder_init_$Init$($this) {
    StringBuilder.call($this, '');
    return $this;
  }
  function StringBuilder$StringBuilder_init_$Create$() {
    return StringBuilder$StringBuilder_init_$Init$(objectCreate(protoOf(StringBuilder)));
  }
  function StringBuilder(content) {
    this.string_1 = content;
  }
  protoOf(StringBuilder).append_t84oo1_k$ = function (value) {
    this.string_1 = this.string_1 + toString(value);
    return this;
  };
  protoOf(StringBuilder).append_jgojdo_k$ = function (value) {
    this.string_1 = this.string_1 + toString_0(value);
    return this;
  };
  protoOf(StringBuilder).toString = function () {
    return this.string_1;
  };
  function AbstractCollection$AbstractCollection$toString$lambda(this$0) {
    return function (it) {
      return it === this$0 ? '(this Collection)' : toString_0(it);
    };
  }
  function AbstractCollection() {
  }
  protoOf(AbstractCollection).isEmpty_y1axqb_k$ = function () {
    return this.get_size_woubt6_k$() === 0;
  };
  protoOf(AbstractCollection).toString = function () {
    return joinToString_0(this, ', ', '[', ']', VOID, VOID, AbstractCollection$AbstractCollection$toString$lambda(this));
  };
  protoOf(AbstractCollection).toArray = function () {
    return collectionToArray(this);
  };
  var AbstractList$Companion$instance;
  function AbstractList$Companion$getInstance() {
    AbstractList$static_init();
    return AbstractList$Companion$instance;
  }
  var AbstractList$static_init_state;
  function AbstractList$static_init() {
    var state = AbstractList$static_init_state;
    if (!state)
      return Unit$instance;
    if (state === 2) {
      staticInitializationFailureWithClassName(AbstractList);
    }
    AbstractList$static_init_state = 0;
    try {
      if (AbstractList$Companion$instance == null)
        new AbstractList$Companion();
    } catch ($p) {
      var reason = $p;
      AbstractList$static_init_state = 2;
      staticInitializationFailure(reason);
    }
  }
  function AbstractList$IteratorImpl($outer) {
    this.$this_1 = $outer;
    this.index_1 = 0;
  }
  protoOf(AbstractList$IteratorImpl).hasNext_bitz1p_k$ = function () {
    return this.index_1 < this.$this_1.get_size_woubt6_k$();
  };
  protoOf(AbstractList$IteratorImpl).next_20eer_k$ = function () {
    if (!this.hasNext_bitz1p_k$())
      throw NoSuchElementException$NoSuchElementException_init_$Create$();
    var _unary__edvuaz = this.index_1;
    this.index_1 = _unary__edvuaz + 1 | 0;
    return this.$this_1.get_c1px32_k$(_unary__edvuaz);
  };
  function AbstractList$Companion() {
    AbstractList$Companion$instance = this;
    this.maxArraySize_1 = 2147483639;
  }
  protoOf(AbstractList$Companion).checkElementIndex_s0yg86_k$ = function (index, size) {
    if (index < 0 || index >= size) {
      throw IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Create$_0('index: ' + index + ', size: ' + size);
    }
  };
  protoOf(AbstractList$Companion).checkPositionIndex_w4k0on_k$ = function (index, size) {
    if (index < 0 || index > size) {
      throw IndexOutOfBoundsException$IndexOutOfBoundsException_init_$Create$_0('index: ' + index + ', size: ' + size);
    }
  };
  function AbstractList() {
    AbstractList$Companion$getInstance();
    AbstractList$static_init();
    AbstractCollection.call(this);
  }
  protoOf(AbstractList).iterator_jk1svi_k$ = function () {
    return new AbstractList$IteratorImpl(this);
  };
  function collectionToArrayCommonImpl(collection) {
    if (collection.isEmpty_y1axqb_k$()) {
      // Inline function 'kotlin.emptyArray' call
      return [];
    }
    // Inline function 'kotlin.arrayOfNulls' call
    var size = collection.get_size_woubt6_k$();
    var destination = Array(size);
    var iterator = collection.iterator_jk1svi_k$();
    var index = 0;
    while (iterator.hasNext_bitz1p_k$()) {
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      destination[_unary__edvuaz] = iterator.next_20eer_k$();
    }
    return destination;
  }
  function emptyList() {
    return EmptyList$getInstance();
  }
  var EmptyList$static_init_state;
  function EmptyList$static_init() {
    var state = EmptyList$static_init_state;
    if (!state)
      return Unit$instance;
    if (state === 2) {
      staticInitializationFailureWithClassName(EmptyList);
    }
    EmptyList$static_init_state = 0;
  }
  var EmptyList$instance;
  function EmptyList$getInstance() {
    EmptyList$static_init();
    if (EmptyList$instance == null)
      new EmptyList();
    return EmptyList$instance;
  }
  function EmptyList() {
    EmptyList$instance = this;
    EmptyList$static_init();
    this.serialVersionUID_1 = new Long(-1478467534, -1720727600);
  }
  protoOf(EmptyList).toString = function () {
    return '[]';
  };
  protoOf(EmptyList).get_size_woubt6_k$ = function () {
    return 0;
  };
  protoOf(EmptyList).isEmpty_y1axqb_k$ = function () {
    return true;
  };
  protoOf(EmptyList).iterator_jk1svi_k$ = function () {
    return EmptyIterator$instance;
  };
  var EmptyIterator$instance;
  function EmptyIterator$getInstance() {
    return EmptyIterator$instance;
  }
  function EmptyIterator() {
  }
  protoOf(EmptyIterator).hasNext_bitz1p_k$ = function () {
    return false;
  };
  protoOf(EmptyIterator).next_20eer_k$ = function () {
    throw NoSuchElementException$NoSuchElementException_init_$Create$();
  };
  function collectionSizeOrDefault(_this__u8e3s4, default_0) {
    var tmp;
    if (isInterface(_this__u8e3s4, Collection)) {
      tmp = _this__u8e3s4.get_size_woubt6_k$();
    } else {
      tmp = default_0;
    }
    return tmp;
  }
  function IntIterator() {
  }
  protoOf(IntIterator).next_20eer_k$ = function () {
    return this.nextInt_ujorgc_k$();
  };
  function getProgressionLastElement(start, end, step) {
    var tmp;
    if (step > 0) {
      tmp = start >= end ? end : end - differenceModulo(end, start, step) | 0;
    } else if (step < 0) {
      tmp = start <= end ? end : end + differenceModulo(start, end, -step | 0) | 0;
    } else {
      throw IllegalArgumentException$IllegalArgumentException_init_$Create$_0('Step is zero.');
    }
    return tmp;
  }
  function differenceModulo(a, b, c) {
    return mod(mod(a, c) - mod(b, c) | 0, c);
  }
  function mod(a, b) {
    var mod = a % b | 0;
    return mod >= 0 ? mod : mod + b | 0;
  }
  var IntRange$Companion$instance;
  function IntRange$Companion$getInstance() {
    IntRange$static_init();
    return IntRange$Companion$instance;
  }
  var IntRange$static_init_state;
  function IntRange$static_init() {
    var state = IntRange$static_init_state;
    if (!state)
      return Unit$instance;
    if (state === 2) {
      staticInitializationFailureWithClassName(IntRange);
    }
    IntRange$static_init_state = 0;
    try {
      if (IntRange$Companion$instance == null)
        new IntRange$Companion();
    } catch ($p) {
      var reason = $p;
      IntRange$static_init_state = 2;
      staticInitializationFailure(reason);
    }
  }
  function IntRange$Companion() {
    IntRange$Companion$instance = this;
    this.EMPTY_1 = new IntRange(1, 0);
  }
  function IntRange(start, endInclusive) {
    IntRange$Companion$getInstance();
    IntRange$static_init();
    IntProgression.call(this, start, endInclusive, 1);
  }
  protoOf(IntRange).toString = function () {
    return '' + this.first_1 + '..' + this.last_1;
  };
  function IntProgressionIterator(first, last, step) {
    IntIterator.call(this);
    this.step_1 = step;
    this.finalElement_1 = last;
    this.hasNext_1 = this.step_1 > 0 ? first <= last : first >= last;
    this.next_1 = this.hasNext_1 ? first : this.finalElement_1;
  }
  protoOf(IntProgressionIterator).hasNext_bitz1p_k$ = function () {
    return this.hasNext_1;
  };
  protoOf(IntProgressionIterator).nextInt_ujorgc_k$ = function () {
    var value = this.next_1;
    if (value === this.finalElement_1) {
      if (!this.hasNext_1)
        throw NoSuchElementException$NoSuchElementException_init_$Create$();
      this.hasNext_1 = false;
    } else {
      this.next_1 = this.next_1 + this.step_1 | 0;
    }
    return value;
  };
  var IntProgression$Companion$instance;
  function IntProgression$Companion$getInstance() {
    return IntProgression$Companion$instance;
  }
  var IntProgression$static_init_state;
  function IntProgression$Companion() {
  }
  function IntProgression(start, endInclusive, step) {
    if (step === 0)
      throw IllegalArgumentException$IllegalArgumentException_init_$Create$_0('Step must be non-zero.');
    if (step === -2147483648)
      throw IllegalArgumentException$IllegalArgumentException_init_$Create$_0('Step must be greater than Int.MIN_VALUE to avoid overflow on negation.');
    this.first_1 = start;
    this.last_1 = getProgressionLastElement(start, endInclusive, step);
    this.step_1 = step;
  }
  protoOf(IntProgression).iterator_jk1svi_k$ = function () {
    return new IntProgressionIterator(this.first_1, this.last_1, this.step_1);
  };
  protoOf(IntProgression).toString = function () {
    return this.step_1 > 0 ? '' + this.first_1 + '..' + this.last_1 + ' step ' + this.step_1 : '' + this.first_1 + ' downTo ' + this.last_1 + ' step ' + (-this.step_1 | 0);
  };
  function appendElement(_this__u8e3s4, element, transform) {
    if (!(transform == null))
      _this__u8e3s4.append_jgojdo_k$(transform(element));
    else {
      if (element == null ? true : isCharSequence(element))
        _this__u8e3s4.append_jgojdo_k$(element);
      else {
        if (element instanceof Char)
          _this__u8e3s4.append_t84oo1_k$(element.value_1);
        else {
          _this__u8e3s4.append_jgojdo_k$(toString_1(element));
        }
      }
    }
  }
  function main() {
    var pts = main$ring(32, 10.0);
    // Inline function 'kotlin.collections.reduce' call
    var iterator = pts.iterator_jk1svi_k$();
    if (!iterator.hasNext_bitz1p_k$())
      throw UnsupportedOperationException$UnsupportedOperationException_init_$Create$_0("Empty collection can't be reduced.");
    var accumulator = iterator.next_20eer_k$();
    while (iterator.hasNext_bitz1p_k$()) {
      var tmp0 = accumulator;
      var v = iterator.next_20eer_k$();
      accumulator = tmp0.plus_xpr3yx_k$(v);
    }
    var centroid = accumulator;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlin.collections.zipWithNext' call
      var iterator_0 = pts.iterator_jk1svi_k$();
      if (!iterator_0.hasNext_bitz1p_k$()) {
        tmp$ret$2 = emptyList();
        break $l$block;
      }
      // Inline function 'kotlin.collections.mutableListOf' call
      var result = ArrayList$ArrayList_init_$Create$();
      var current = iterator_0.next_20eer_k$();
      while (iterator_0.hasNext_bitz1p_k$()) {
        var next = iterator_0.next_20eer_k$();
        var tmp$ret$4 = current.plus_xpr3yx_k$(new main$P(-next.x_1, -next.y_1)).len_2al1_k$();
        result.add_utx5q5_k$(tmp$ret$4);
        current = next;
      }
      tmp$ret$2 = result;
    }
    var perimeter = sum(tmp$ret$2);
    console.log('ring: n=' + pts.get_size_woubt6_k$() + ' sum=(' + centroid.x_1 + ',' + centroid.y_1 + ') perimeter=' + perimeter);
  }
  function main$P(x, y) {
    this.x_1 = x;
    this.y_1 = y;
  }
  protoOf(main$P).plus_xpr3yx_k$ = function (o) {
    return new main$P(this.x_1 + o.x_1, this.y_1 + o.y_1);
  };
  protoOf(main$P).len_2al1_k$ = function () {
    // Inline function 'kotlin.math.sqrt' call
    var x = this.x_1 * this.x_1 + this.y_1 * this.y_1;
    return Math.sqrt(x);
  };
  protoOf(main$P).toString = function () {
    return 'P(' + 'x=' + this.x_1 + ', ' + 'y=' + this.y_1 + ')';
  };
  function main$ring(n, r) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = until(0, n);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList$ArrayList_init_$Create$_0(collectionSizeOrDefault(this_0, 10));
    var inductionVariable = this_0.first_1;
    var last = this_0.last_1;
    if (inductionVariable <= last)
      do {
        var item = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var a = 2.0 * 3.141592653589793 * item / n;
        // Inline function 'kotlin.math.cos' call
        var tmp = Math.cos(a) * r;
        // Inline function 'kotlin.math.sin' call
        var tmp$ret$4 = Math.sin(a);
        var tmp$ret$2 = new main$P(tmp, tmp$ret$4 * r);
        destination.add_utx5q5_k$(tmp$ret$2);
      }
       while (!(item === last));
    return destination;
  }
  function mainWrapper() {
    main();
  }
  //region block: init
  List$Companion$instance = new List$Companion();
  List$static_init_state = 1;
  MutableList$static_init_state = 1;
  Long$static_init_state = 1;
  properties_initialized_boxedLong_kt_lfwt2 = 1;
  Unit$instance = new Unit();
  AbstractMutableList$static_init_state = 1;
  ArrayList$static_init_state = 1;
  AbstractList$static_init_state = 1;
  EmptyList$static_init_state = 1;
  EmptyIterator$instance = new EmptyIterator();
  IntRange$static_init_state = 1;
  IntProgression$Companion$instance = new IntProgression$Companion();
  IntProgression$static_init_state = 1;
  //endregion
  //region block: eager init
  VOID = void 0;
  //endregion
  mainWrapper();
  return _;
}(typeof readable_sum_0 === 'undefined' ? {} : readable_sum_0);
