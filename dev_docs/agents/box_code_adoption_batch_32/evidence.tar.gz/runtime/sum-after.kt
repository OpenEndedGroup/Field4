external val console: dynamic
data class P(val x: Double, val y: Double) {
    operator fun plus(o: P) = P(x + o.x, y + o.y)

    fun len() = kotlin.math.sqrt(x * x + y * y)
}
fun ring(n: Int, r: Double): List<P> =
    (0 until n).map { i ->
        val a = 2.0 * kotlin.math.PI * i / n
        P(kotlin.math.cos(a) * r, kotlin.math.sin(a) * r)
    }
val pts = ring(32, 10.0)
val sum = pts.reduce { u, v -> u + v }
// Include the closing edge from the final point back to the first.
val perimeter = (pts + pts.first()).zipWithNext { u, v -> (u + P(-v.x, -v.y)).len() }.sum()
console.log("ring: n=" + pts.size + " sum=(" + sum.x + "," + sum.y + ") perimeter=" + perimeter)
