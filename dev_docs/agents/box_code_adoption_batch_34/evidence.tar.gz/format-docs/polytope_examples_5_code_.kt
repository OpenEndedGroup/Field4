/* BOX_CODE_FOLD_0 */
fun Box.gallery(channel: String, columns: Int, cell: Int, panels: List<Pair<String, PolyhedralObject>>) {
    val view = MeshView(wireframe = false, distance = 2.3)
    val rows = (panels.size + columns - 1) / columns
    threeGrid(
        panels.map { (label, p) ->
            val t = p.topology
            ThreeMeshPanel(
                label,
                p.toTriMesh(),
                facts =
                    "${t.elements(0).size}v ${t.elements(1).size}e ${t.elements(2).size}f · " +
                        t.elements(2)
                            .groupingBy { t.faceCycle(it.id).size }
                            .eachCount()
                            .toSortedMap()
                            .entries
                            .joinToString(" ") { "${it.value}×${it.key}-gon" } +
                        " · χ=${t.eulerCharacteristic()}",
            )
        },
        channel = channel,
        name = "gallery-$channel",
        padding = 1.02,
        columns = columns,
        height = rows * (cell * 0.84).toInt(),
        cellWidth = cell,
        view = view,
    )
}

/* BOX_CODE_FOLD_1 */

// One seed, five primitives. `conway(...)` parses and evaluates in one call.
gallery(
    "primitives",
    columns = 3,
    cell = 380,
    panels = [
        "C    the seed" to conway("C").polyhedron,
        "dC   dual" to conway("dC").polyhedron,
        "aC   ambo" to conway("aC").polyhedron,
        "kC   kis" to conway("kC").polyhedron,
        "tC   truncate" to conway("tC").polyhedron,
        "gC   gyro" to conway("gC").polyhedron,
    ],
)
