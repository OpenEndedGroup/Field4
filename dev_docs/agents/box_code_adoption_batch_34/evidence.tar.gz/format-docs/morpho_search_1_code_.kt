import afield.lang.morpho.*

// y = (x != 0). No combination of gates turns eight wires into one bit, so the only way
// down is SPLIT: every correct answer divides and recurses.
val problem = MorphoProblems.orReduce()
println(problem)

val runs = [
    MorphoSearch.random(problem.spec, problem.generator, 6000, seed = 2),
    MorphoSearch.evolve(problem.spec, problem.generator, 6000, seed = 2, mu = 24, lambda = 40),
]
runs.forEach { println(it.summary()) }

// The cheapest correct design across both runs, or the closest one if neither solved it.
val correct = runs.mapNotNull { it.best }.filter { it.fitness.correct }
val best = correct.minByOrNull { it.gates } ?: runs.mapNotNull { it.best }.minWith(MorphoIndividual.BY_QUALITY)
println()
println(if (correct.isEmpty()) "(nothing exactly correct this run; showing the best found)" else "")
println(best.genome.phenotype().cells[0].render())

// Selected at widths 2, 3 and 5 (see "Why the width family is 2, 3 and 5" below), then
// re-compiled from the same source at widths it was never tested on.
[7, 9, 16, 32, 48].forEach { w ->
    val f = MorphoSearch.generalization(best.genome, problem.spec, [w])
    println("  at %2d bits: %s".format(w, f))
}

// The Pareto front over every correct design the two runs produced, drawn as a step
// function because there is no design at a fractional gate count.
val found = runs.flatMap { it.costPoints() }
println()
println(
    "Pareto front (gates, depth) at %d bits: %s"
        .format(
            problem.spec.widths.max(),
            runs.flatMap { it.front }.joinToString(", ") { "(${it.gates}, ${it.depth})" },
        ),
)

// The found circuit itself at three widths: one source, three signatures, three circuits.
val source = best.genome.render()
val panels =
    [4, 8, 16].map { w ->
        val c = morphoCircuit(MorphoProblems.ROOT, w, source = source)
        c.growFully(relaxSteps = 220)
        "evolved or-reduce at %d bits — %d gates, depth %d".format(w, c.netlist.gateCount, c.depth.toInt()) to
            c.flines(fit = true)
    }
showPlaneGrid(
    *panels.toTypedArray(),
    columns = 3,
    cellWidth = 300,
    cellHeight = 300,
    window = morphoUnitWindow(),
)

showPlaneGrid(
    "or-reduce — best-so-far bit error vs compiler invocations (log x)\n" + morphoRunCaption(runs) to
        morphoConvergenceFLines(runs),
    "cost of an or-reduce — depth (x) against gates (y)\n" +
        "${found.size} correct designs, ${runs.sumOf { it.front.size }} of them non-dominated. " +
        "A staircase is only drawn when the front has more than one point: for a reduction " +
        "it usually does not, because cheaper and shallower go together here" to morphoParetoFLines(found),
    channel = "cost",
    columns = 2,
    cellWidth = 430,
    cellHeight = 380,
    window = morphoPlotWindow(),
)
