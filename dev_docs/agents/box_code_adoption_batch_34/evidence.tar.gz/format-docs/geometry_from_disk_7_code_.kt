// java.io is not in a box's default imports, hence the qualified names.
mesh.saveObj(java.io.File("/tmp/thing.obj")) // keeps normals and uvs; loses colours
mesh.saveStl(java.io.File("/tmp/thing.stl")) // binary; positions only; every slicer reads it
java.io.File("/tmp/thing.stl").writeText(mesh.toStlAscii()) // ~5x larger, human-readable
