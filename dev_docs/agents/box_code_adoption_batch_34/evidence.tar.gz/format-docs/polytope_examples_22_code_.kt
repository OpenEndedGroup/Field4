val hole = 0.45f

/* BOX_CODE_FOLD_0 */
/*
This is the whole of the hole API from a caller's side: record the ring's edges as
incidences of the same face, then declare the ring with addFaceHole. Winding is a
convention — outer counter-clockwise about the normal, inner clockwise — and nothing
downstream leans on it, because the tessellator decides which ring is outer geometrically.
*/
fun plate(withRing: Boolean): PolyhedralObject {
    val outer = [Vec3(-1f, -1f, 0f), Vec3(1f, -1f, 0f), Vec3(1f, 1f, 0f), Vec3(-1f, 1f, 0f)]
    val inner = [
        Vec3(-hole, -hole, 0f),
        Vec3(-hole, hole, 0f),
        Vec3(hole, hole, 0f),
        Vec3(hole, -hole, 0f),
    ]
    // buildList, not `outer + inner`: a box has afield.geometry.path in scope, where
    // `List<Vec3> + List<Vec3>` is element-wise vector addition and returns four points.
    val points = buildList {
        addAll(outer)
        if (withRing) addAll(inner)
    }
    val rings = if (withRing) [[0, 1, 2, 3], [4, 5, 6, 7]] else [[0, 1, 2, 3]]

    val builder = PolytopeTopologyBuilder(rank = 3)
    val vertices = points.map { builder.addElement(0) }
    val face = builder.addElement(2)
    for (ring in rings) for (i in ring.indices) {
        val edge = builder.addElement(1)
        builder.addIncidence(vertices[ring[i]], edge)
        builder.addIncidence(vertices[ring[(i + 1) % ring.size]], edge)
        builder.addIncidence(edge, face)
    }
    builder.setFaceCycle(face, rings.first().map { vertices[it] })
    rings.drop(1).forEach { ring -> builder.addFaceHole(face, ring.map { vertices[it] }) }
    builder.addIncidence(face, builder.addElement(3))
    return PolyhedralObject(builder.buildValidated(), Realization3(points))
}

/* BOX_CODE_FOLD_1 */

val view = MeshView(
    yawDegrees = 0.0,
    pitchDegrees = 0.0,
    distance = 2.2,
    width = 300,
    height = 260,
    wireframe = true,
    cullBackFaces = true,
)
val cells =
    [true, false].map { withRing ->
        val plate = plate(withRing)
        val t = plate.topology
        val face = t.elements(2).single()
        ThreeMeshPanel(
            label = if (withRing) "addFaceHole(face, ring)" else "the same plate, no ring",
            mesh = plate.toTriMesh(),
            facts =
                "${t.elements(0).size}v ${t.elements(1).size}e · ${t.faceRings(face.id).size} ring(s)" +
                    " · ${plate.triangulate().triangleCount} triangles",
        )
    }
threeGrid(cells, channel = "plates", name = "plates", columns = 2, height = 260, view = view, padding = 1.02)
