val n = (1..6).map { 10.0.pow(it) }
val time = n.map { it * 1.4e-6 + 3e-4 }

Chart(title = "a log axis, and decade ticks", xLabel = "n", yLabel = "seconds")
    .also {
        it.xKind = ScaleKind.LOG
        it.yKind = ScaleKind.LOG
    }
    .line("measured", n, time)
    .points("measured", n, time)
