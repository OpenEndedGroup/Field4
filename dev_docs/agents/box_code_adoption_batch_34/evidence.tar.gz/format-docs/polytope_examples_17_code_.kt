val seeds = [
    "5-cell" to fiveCell(),
    "tesseract" to tesseract(),
    "16-cell" to sixteenCell(),
    "24-cell" to twentyFourCell(),
]

// Viewing is a Projection4 above realization, not part of the geometry.
val projection = RotatedProjection4(
    a = 0,
    b = 3,
    angle = 0.30,
    then = PerspectiveProjection4(eye = 4.2),
)

val counts =
    Table(
            [
                "seed",
                "V",
                "E",
                "F",
                "C",
                "V-E+F-C",
                "polygons per cell",
                "closed 2-manifold?",
            ],
        )
        .rows(
            seeds.map { (name, p) ->
                val s = p.summary()
                val manifold = runCatching { p.topology.validate(checkManifold = true).isValid }.getOrDefault(false)
                [
                    name,
                    s.vertices,
                    s.edges,
                    s.polygons,
                    s.cells,
                    s.eulerCharacteristic,
                    s.cellPolygonCounts,
                    manifold,
                ]
            },
        )
        // A 4-polytope is not a surface, so the manifold check should answer false.
        .expect("V-E+F-C", because = "the Euler relation for a convex 4-polytope") { it == 0 }
        .expect("closed 2-manifold?", because = "a 4-polytope is not a surface") { it == false }

/* BOX_CODE_FOLD_0 */
val lines =
    tesseract().toEdgeFLines(projection) { _, line ->
        line.stroked = true
        line.thickness = 2.0
        line.color = vec(0.30, 0.82, 0.96, 0.85)
    }
threeLines(
    lines,
    channel = "rank4",
    name = "tesseract, rotated perspective projection",
    height = 430,
    autoFrame = true,
    editable = false,
)
displayOpen("rank4")

markdown("counts", counts.h)/* BOX_CODE_FOLD_1 */
