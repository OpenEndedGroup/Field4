// A sphere with a patch of faces removed, and one more face left unwelded — the two commonest
// ways a mesh off disk fails. Built here rather than loaded, so the picture needs no file.
val base = icosphereMesh(3, 1.0)
var broken = base.filterTriangles { it >= 4 }

// Give triangle 0 its own three vertices: the crack an STL export leaves at every seam.
val pos = broken.positions.copyOf(broken.positions.size + 9)
val idx = broken.indices.copyOf()
for (k in 0..2) {
    val v = broken.indices[k]
    val d = (broken.vertexCount + k) * 3
    pos[d] = broken.x(v)
    pos[d + 1] = broken.y(v)
    pos[d + 2] = broken.z(v)
    idx[k] = broken.vertexCount + k
}
broken = TriMesh(pos, idx)

println(broken.diagnose().report())
/* BOX_CODE_FOLD_0 */
/*
No `view` argument, and that is the point: the camera aims itself at the worst defect. The hole
is on the far side from the default three-quarter view, so without that this figure would be a
photograph of an apparently perfect sphere captioned "4 faces removed".
*/
showMeshDiagnosis(broken, title = "4 faces removed, plus one unwelded face")/* BOX_CODE_FOLD_1 */
