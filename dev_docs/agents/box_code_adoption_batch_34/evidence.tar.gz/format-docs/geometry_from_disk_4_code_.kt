// A four-vertex coloured square, written as ASCII PLY and read back. The same code path a 10-million-
// point scan takes; small enough to read here.
val dir = java.nio.file.Files.createTempDirectory("ply-demo").toFile()
val file = java.io.File(dir, "square.ply")
file.writeText(
    """
    ply
    format ascii 1.0
    element vertex 4
    property float x
    property float y
    property float z
    property uchar red
    property uchar green
    property uchar blue
    element face 2
    property list uchar int vertex_indices
    end_header
    0 0 0 255 40 40
    1 0 0 40 255 40
    1 1 0 60 60 255
    0 1 0 255 235 40
    3 0 1 2
    3 0 2 3
    """
        .trimIndent() + "\n",
)

// The loader is PlySupport — no renderer, no Vulkan, no Box context needed.
val model = PlySupport.loadPly(file.path)
val b = model.buffers
println(
    "vertices ${b.vertexCount}, indices ${b.indexCount}, colours ${b.hasColors}, " +
        "normals in the file ${b.hasNormals}, point cloud ${b.isPointCloud}",
)
println(
    "packed as ${b.vertexData.capacity() / (b.vertexCount * 4)} floats per vertex: " +
        "[pos.xyz][normal.xyz][color.rgba]",
)

// ...and the bridge into a TriMesh keeps the colours.
val mesh = model.toTriMesh()
println("as a TriMesh: ${mesh.summary()}")
println("colours survived: ${mesh.hasColors}, vertex 0 is ${mesh.color(0)}")
println(
    "normals dropped: ${!mesh.hasNormals} — the file had none, and the loader's " +
        "invented (0,0,1) would shade the whole thing as if it faced you",
)
/* BOX_CODE_FOLD_0 */
showMesh(
    mesh,
    view = MeshView(yawDegrees = 0.0, pitchDegrees = 0.0, width = 420, height = 315),
    title = "square.ply — per-vertex colours",
)
dir.deleteRecursively()/* BOX_CODE_FOLD_1 */
