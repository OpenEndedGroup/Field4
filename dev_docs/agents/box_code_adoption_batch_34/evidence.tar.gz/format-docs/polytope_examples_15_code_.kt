// kis applied twice to the cube: 38 vertices, 108 edges, 72 faces. The standing counter-example.
// relaxWithCeres needs the native wrapper: ./gradlew buildCeresRedistributable
val seed = conway("kkC").polyhedron
val iterated = seed.canonicalize()
val solved = seed.relaxWithCeres(RelaxationPlan.canonicalConditions(), CeresRelaxationOptions(maxIterations = 500))

/* BOX_CODE_FOLD_0 */
val gauge = RigidGauge()
val panels = [
    "kkC as built" to seed.normalize(gauge),
    "canonicalize()" to iterated.polyhedron.normalize(gauge),
    "relaxWithCeres()" to solved.realization.polyhedron.normalize(gauge),
]
threeGrid(
    panels.map { (label, p) -> ThreeMeshPanel(label, p.toTriMesh()) },
    channel = "kkc3d",
    name = "embeddings",
    columns = 3,
    height = 340,
    cellWidth = 380,
    view = MeshView(wireframe = false, distance = 3.2),
    padding = 1.26,
)
val sci = { v: Any? -> "%.3e".format(v) }
fun row(label: String, p: PolyhedralObject): List<Any?> {
    val d = p.canonicalDiagnostics()
    return [
        label,
        d.tangencyRadiusSpread,
        d.tangencyCentroidOffset,
        d.maxFacePlanarityError,
        d.dihedralAngleMin,
    ]
}

val metrics =
    Table(
            [
                "embedding",
                "tangency radius spread",
                "tangency centroid offset",
                "max planarity err",
                "min dihedral",
            ],
        )
        .rows(panels.map { (label, p) -> row(label, p) })
        .format("tangency radius spread", sci)
        .format("tangency centroid offset", sci)
        .format("max planarity err", sci)
        .format("min dihedral") { "%.3f".format(it) }

markdown(
    "kkc",
    """
    ${metrics.h}

    canonicalize(): converged = ${iterated.converged} · reason = ${iterated.reason}

    relaxWithCeres(): ${solved.summary.md}
""",
)/* BOX_CODE_FOLD_1 */
