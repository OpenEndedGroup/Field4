GeometryAgentTools.addSearchRoot(java.io.File(System.getProperty("user.home"), "scans"))
GeometryAgentTools.register()
