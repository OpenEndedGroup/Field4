val rows =
    ConwayOperator.entries.joinToString("\n") { op ->
        // primitiveExpansion is in EXECUTION order (seed outward). Prefix notation writes it
        // the other way round, so reverse it to get the string you would actually type.
        val execution = op.primitiveExpansion.joinToString("") { it.symbol.toString() }
        val written = op.primitiveExpansion.reversed().joinToString("") { it.symbol.toString() }
        "| `${op.symbol}` | ${op.displayName} | ${if (op.primitive) "primitive" else "composite"} " +
            "| `$execution` | `${written}C` |"
    }
markdown(
    "ops",
    """
#### `ConwayOperator.entries`

| letter | name | kind | primitives, seed outward | equivalent notation |
|---|---|---|---|---|
$rows
""",
    width = 780,
)
