showMesh("/path/to/thing.glb")
