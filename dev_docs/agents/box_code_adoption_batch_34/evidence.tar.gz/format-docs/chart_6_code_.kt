val c = Chart(yLabel = "gates").bars("cost", "xor" to 6, "adder" to 27)
c.onPick = { pick ->
    print("${pick.series}/${pick.category} = ${pick.y}")
}
showChart(c)
