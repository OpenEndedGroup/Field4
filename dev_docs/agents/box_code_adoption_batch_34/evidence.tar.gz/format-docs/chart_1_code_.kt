showSignals("residual" to residual, "step" to step, title = "per iteration")
