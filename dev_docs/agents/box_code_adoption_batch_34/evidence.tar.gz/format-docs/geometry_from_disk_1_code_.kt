/*
The same file public/docs/fabricate_renderer.md renders with full PBR — here through the plain
Three.js viewer instead, which is `showMesh`'s default and gives you a solid you can orbit.
`renderer = MeshRenderer.CPU` for the static z-buffer figure, which needs no GPU at all.
*/
val glb = java.io.File("public/docs/assets/fabricate_demo/ToyCar.glb")
println("${glb.name}: ${glb.length()} bytes on disk")

val car = meshFromAnyFile(glb.path)
println(car.summary())

// Three mesh/material buckets, assembled by node transform rather than heaped at the origin.
val b = car.bounds()
println(
    "assembled extent %.4f x %.4f x %.4f metres"
        .format(
            b.max.x - b.min.x,
            b.max.y - b.min.y,
            b.max.z - b.min.z,
        ),
)
/* BOX_CODE_FOLD_0 */
showMesh(
    car,
    view = MeshView(width = 560, height = 420, wireframe = false),
    title = "ToyCar.glb — 108,936 triangles in the Three.js viewer",
)/* BOX_CODE_FOLD_1 */
