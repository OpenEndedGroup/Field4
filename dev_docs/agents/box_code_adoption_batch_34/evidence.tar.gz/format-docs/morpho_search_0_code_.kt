import afield.lang.morpho.*

/*
A problem is what the circuit should compute, the widths to test it at, and the cells a
candidate may use. The only thing said about addition is `sum, c_out = a + b + c_in`;
the cells are morpho's own eight standard ones.
*/
val problem = MorphoProblems.fullAdderCell()
val budget = 4000
println(problem)
println("palette: " + MorphoPalette.standard.luts.joinToString { it.name })
println(
    "input space at 1 bit: ${problem.spec.inputSpace(1)} vectors, " + "exhaustive = ${problem.spec.isExhaustiveAt(1)}",
)

// Three drivers with the same generator, seed and budget. One unit of budget is one
// invocation of morpho's compiler.
val runs = [
    MorphoSearch.random(problem.spec, problem.generator, budget, seed = 2),
    MorphoSearch.hillClimb(problem.spec, problem.generator, budget, seed = 2),
    MorphoSearch.evolve(problem.spec, problem.generator, budget, seed = 2),
]
runs.forEach { println(it.summary()) }

// What was actually found, in MorphoHDL. This is paste-into-a-morpho-box text.
runs
    .firstOrNull { it.solved }
    ?.best
    ?.let { winner ->
        println()
        println(winner.genome.phenotype().cells[0].render())
        println("cost: ${winner.fitness.cost}")
    }

/*
Cyan is random sampling, orange the hill climb, green the population. A dropped tick
marks the invocation at which a run first became exactly correct, since a curve that
reaches zero and one that reaches 0.004 look the same at this scale.
*/
showPlaneGrid(
    "one-bit full adder — best-so-far bit error vs compiler invocations (log x, $budget budget)\n" +
        morphoRunCaption(runs) to morphoConvergenceFLines(runs),
    columns = 1,
    cellWidth = 700,
    cellHeight = 420,
    window = morphoPlotWindow(),
)
