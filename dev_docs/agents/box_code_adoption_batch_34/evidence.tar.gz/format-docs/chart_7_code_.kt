import org.jetbrains.kotlinx.dataframe.api.*

val people = dataFrameOf("name", "age")("Alice", 15, "Bob", 30, "Cara", 45)

people.chart() // bars: age per name
people.chart(x = "name", y = ["age"]) // choose both axes explicitly
showChart(people) // straight from a frame to the screen
