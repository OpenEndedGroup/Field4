// The gyro-cube, exactly as the operator built it, and the same combinatorics canonicalized.
val built = conway("gC").polyhedron
val run = built.canonicalize()

// Both panels are gauged to the same mean edge length, so the comparison is about shape, not size.
val gauge = RigidGauge()
val before = built.normalize(gauge)
val after = run.polyhedron.normalize(gauge)

/* BOX_CODE_FOLD_0 */
threeGrid(
    "gC as the operator built it" to before.toTriMesh(),
    "gC.canonicalize()" to after.toTriMesh(),
    channel = "canon3d",
    name = "embeddings",
    columns = 2,
    height = 380,
    cellWidth = 430,
    view = MeshView(wireframe = false, distance = 3.2),
    padding = 1.26,
)
val sci = { v: Any? -> "%.3e".format(v) }
fun row(label: String, d: CanonicalDiagnostics) = [
    label,
    d.tangencyRadiusSpread,
    d.tangencyCentroidOffset,
    d.maxFacePlanarityError,
    d.dihedralAngleMean,
    d.dihedralAngleSpread,
]
fun degrees(o: PolyhedralObject) =
    o.topology.elements(2).mapNotNull { o.topology.faceCycleOrNull(it.id)?.size }.distinct().sorted()

val metrics =
    Table(
            [
                "embedding",
                "tangency radius spread",
                "tangency centroid offset",
                "max planarity err",
                "dihedral mean",
                "dihedral spread",
            ],
        )
        .rows([row("as built", run.initialDiagnostics), row("canonical", run.finalDiagnostics)])
        .format("tangency radius spread", sci)
        .format("tangency centroid offset", sci)
        .format("max planarity err", sci)
        .format("dihedral mean") { "%.4f".format(it) }
        .format("dihedral spread", sci)

markdown(
    "canon",
    """
    ${metrics.h}

    converged = ${run.converged} · reason = ${run.reason} ·
    reciprocal iterations = ${run.reciprocalIterations} ·
    relaxation iterations = ${run.relaxationIterations} · reseeded = ${run.reseeded}

    distinct face degrees, before and after = ${degrees(before).md} →
    ${degrees(after).md} · topology object identical =
    ${run.polyhedron.topology === built.topology}
""",
)/* BOX_CODE_FOLD_1 */
