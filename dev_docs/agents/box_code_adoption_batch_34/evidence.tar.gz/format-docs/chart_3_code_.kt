Chart(title = "bars put their categories on the axis", yLabel = "gates")
    .bars("cost", ["xor", "maj3", "adder", "mux", "parity"], [6, 11, 27, 4, 19])
