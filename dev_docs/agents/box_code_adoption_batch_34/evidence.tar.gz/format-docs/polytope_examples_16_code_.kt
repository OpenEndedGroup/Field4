// Throw the coordinates away and keep only the incidence structure.
val topologyOnly: PolytopeTopology = conway("gC").polyhedron.topology

val spectral = topologyOnly.realize(SpectralRealization())
val recovered = spectral.canonicalize()

// The same combinatorics reached the other way, for comparison.
val fromOperator = conway("gC").polyhedron.canonicalize()

/* BOX_CODE_FOLD_0 */
val gauge = RigidGauge()
threeGrid(
    "1 · spectral only" to spectral.normalize(gauge).toTriMesh(),
    "2 · canonicalize()" to recovered.polyhedron.normalize(gauge).toTriMesh(),
    "3 · canonicalize()" to fromOperator.polyhedron.normalize(gauge).toTriMesh(),
    channel = "spectral3d",
    name = "routes",
    columns = 3,
    height = 330,
    cellWidth = 380,
    view = MeshView(wireframe = false, distance = 3.2),
    padding = 1.26,
)
val dev = recovered.polyhedron.symmetryDeviation()
val spectralOnly = spectral.canonicalDiagnostics()
val sci = { v: Any? -> "%.3e".format(v) }
val routes =
    Table(["route", "tangency spread", "dihedral mean (rad)"])
        .rows(
            [
                ["1 · spectral only", spectralOnly.tangencyRadiusSpread, spectralOnly.dihedralAngleMean],
                [
                    "2 · from combinatorics alone",
                    recovered.finalDiagnostics.tangencyRadiusSpread,
                    recovered.finalDiagnostics.dihedralAngleMean,
                ],
                [
                    "3 · from the operator's coordinates",
                    fromOperator.finalDiagnostics.tangencyRadiusSpread,
                    fromOperator.finalDiagnostics.dihedralAngleMean,
                ],
            ],
        )
        .format("tangency spread", sci)
        .format("dihedral mean (rad)") { "%.4f".format(it) }

markdown(
    "spectral",
    """
    ${routes.h}

    {muted:2 and 3 agree on the dihedral mean to} ${"%.2e".format(
        Math.abs(recovered.finalDiagnostics.dihedralAngleMean -
            fromOperator.finalDiagnostics.dihedralAngleMean,),)} rad

    {muted:symmetry readout of the recovered solid}

    vertex-radius spread ${sci(dev.vertexRadiusSpread)} ·
    edge-length spread ${sci(dev.edgeLengthSpread)} ·
    face-distance spread ${sci(dev.faceDistanceSpread)}

    combinatorial classes — vertices ${dev.orbits.vertexClassSizes.md} ·
    edges ${dev.orbits.edgeClassSizes.md} · faces ${dev.orbits.faceClassSizes.md} ·
    fully transitive = ${dev.orbits.fullyTransitive}
""",
)/* BOX_CODE_FOLD_1 */
