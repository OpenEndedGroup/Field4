val solid = cubeWithWindow(side = 0.45f)
val topology = solid.topology
val windowed = topology.elements(2).single { topology.faceHasHoles(it.id) }
val geometry = solid.triangulate()
val rimTriangles = (0 until geometry.triangleCount).count { geometry.sourceFace(it) == windowed.id }
val manifold = topology.validate(checkManifold = true)

// Everything a holed face refuses, and the message it refuses with.
val refusals =
    listOf<Pair<String, () -> Any>>(
            "topology.dual()" to { topology.dual() },
            "solid.bevel()" to { solid.bevel() },
            "solid.toOff()" to { solid.toOff() },
            "solid.triangulate(FanFaceTriangulator)" to { solid.triangulate(FanFaceTriangulator) },
        )
        .map { (name, call) ->
            name to (runCatching { call() }.exceptionOrNull()?.message ?: "no exception — unexpected")
        }

/* BOX_CODE_FOLD_0 */
markdown(
    "window",
    """
#### One face, two boundary rings

| | value |
|---|---|
| outer cycle (`faceCycle`) | ${topology.faceCycle(windowed.id).size} vertices |
| inner rings (`faceHoles`) | ${topology.faceHoles(windowed.id).map { it.size }} |
| all rings (`faceRings`) | ${topology.faceRings(windowed.id).size} |
| &chi; counting elements | ${topology.eulerCharacteristic()} |
| &chi; counting cells | ${topology.cellularEulerCharacteristic()} |
| closed manifold | ${manifold.isValid}, with ${manifold.issues.size} one-sided window edges |
| triangles cut from that face | $rimTriangles — a solid square is 2 |

#### What a holed face refuses, by name

| call | message |
|---|---|
${refusals.joinToString("\n") { (call, message) -> "| `$call` | ${message.md} |" }}
""",
    width = 940,
)/* BOX_CODE_FOLD_1 */
