val mesh = meshFromAnyFile("scan.glb")
println(mesh.diagnose().report()) // why, worst first
val fixed = mesh.repairToSolid()
println(fixed.report()) // what was done, and what was not
if (fixed.isSolid) display(fixed.mesh.toSolid() - drill)
