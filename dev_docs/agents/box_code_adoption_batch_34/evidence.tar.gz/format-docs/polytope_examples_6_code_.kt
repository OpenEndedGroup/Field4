// Shading cannot separate coplanar faces, so give each polygon its own colour instead. The
// triangle -> source-polygon map is what makes that possible on a triangle mesh at all.
val gyro = conway("gC").polyhedron
val g = gyro.triangulate()
val faceOrder = gyro.topology.elements(2).mapIndexed { i, f -> f.id.value to i }.toMap()

val colors = FloatArray(g.mesh.vertexCount * 3)
for (tri in 0 until g.triangleCount) {
    // A hue wheel over the 24 pentagons; nothing here knows or cares where they are in space.
    val turn = faceOrder.getValue(g.sourceFace(tri).value) * 2.0 * Math.PI / faceOrder.size
    for (k in 0..2) {
        val vi = g.mesh.indices[tri * 3 + k]
        colors[vi * 3] = (0.55 + 0.42 * Math.cos(turn)).toFloat()
        colors[vi * 3 + 1] = (0.55 + 0.42 * Math.cos(turn - 2.09)).toFloat()
        colors[vi * 3 + 2] = (0.55 + 0.42 * Math.cos(turn + 2.09)).toFloat()
    }
}
val painted = TriMesh(g.mesh.positions, g.mesh.indices, g.mesh.normals, null, colors)

/* BOX_CODE_FOLD_0 */
// A separate channel from the caption below: `display` REPLACES a channel's content, so a caption
// written to "gyro" would silently take the viewer's place and the figure would lose its mesh.
three(
    painted,
    channel = "gyro3d",
    name = "gyro",
    view = MeshView(wireframe = false, width = 860, height = 560, distance = 2.4),
    padding = 1.02,
    facts = false,
)
// The count behind the flatness: 24 faces sharing only 6 distinct outward normals.
val distinctNormals =
    gyro.topology
        .elements(2)
        .map { gyro.faceNormal(it.id) }
        .map { "%.3f,%.3f,%.3f".format(it.x, it.y, it.z) }
        .distinct()

markdown(
    "gyro",
    """
    gC · ${gyro.topology.elements(2).size} faces, all
    ${gyro.topology.elements(2).map { gyro.topology.faceCycle(it.id).size }.distinct().joinToString("/")}-gons ·
    ${distinctNormals.size} distinct face normals: ${distinctNormals.joinToString(" ") { "($it)" }.md}
""",
)/* BOX_CODE_FOLD_1 */
