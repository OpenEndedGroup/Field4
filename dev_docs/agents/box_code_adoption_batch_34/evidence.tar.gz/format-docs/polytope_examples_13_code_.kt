import kotlin.random.Random

// Take a real Conway output and jitter every vertex. The topology is not touched at all.
val clean = conway("aC").polyhedron
val rng = Random(7)
val jittered = clean.copy(
    realization = Realization3(
        clean.realization!!.vertexCoordinates.map {
            Vec3(it)
                .add(
                    (rng.nextDouble() - 0.5).toFloat() * 0.62f,
                    (rng.nextDouble() - 0.5).toFloat() * 0.62f,
                    (rng.nextDouble() - 0.5).toFloat() * 0.62f,
                )
        },
    ),
)

val solved = jittered.solveRealization()

/* BOX_CODE_FOLD_0 */
threeGrid(
    "aC as built" to clean.toTriMesh(),
    "every vertex jittered" to jittered.toTriMesh(),
    "solveRealization()" to solved.polyhedron.toTriMesh(),
    channel = "solve3d",
    name = "embeddings",
    columns = 3,
    height = 340,
    cellWidth = 400,
    view = MeshView(wireframe = false, distance = 2.5),
    padding = 1.02,
)
// A Table for the diagnostics — the numeric columns right-align themselves and each carries its
// own format — inside a markdown card that holds the solver's summary as prose.
val sci = { v: Any? -> "%.3e".format(v) }
fun row(label: String, d: RealizationDiagnostics) = [
    label,
    d.edgeLengthMean,
    d.edgeLengthRmsDeviation,
    d.maxFacePlanarityError,
    d.facePlanarityRmsError,
    d.degenerateFaces.size,
]

val metrics =
    Table(
            [
                "embedding",
                "edge mean",
                "edge RMS dev",
                "max planarity err",
                "planarity RMS",
                "degenerate",
            ],
        )
        .rows(
            [
                row("aC as built", clean.geometryDiagnostics()),
                row("jittered", solved.initialDiagnostics),
                row("after solveRealization()", solved.finalDiagnostics),
            ],
        )
        .format("edge mean") { "%.5f".format(it) }
        .format("edge RMS dev", sci)
        .format("max planarity err", sci)
        .format("planarity RMS", sci)

markdown(
    "solve",
    """
    ${metrics.h}

    converged = ${solved.converged} · iterations = ${solved.iterations} ·
    rmsResidual = ${sci(solved.rmsResidual)} · reason = ${solved.reason} ·
    topology object identical = ${solved.polyhedron.topology === jittered.topology}
""",
)/* BOX_CODE_FOLD_1 */
