// One expression: kis of bevel of the dodecahedron. Three chained operators, 360 output faces.
val chain = conway("kbD")
val run = chain.polyhedron.canonicalize()
val solid = if (run.converged) run.polyhedron else chain.polyhedron

/*
Now colour every one of those faces by the element of the ORIGINAL DODECAHEDRON it descends
from. Not by position, not by normal, not by size — `sourceElements` walks each output face's
lineage back through kis, through truncate, through ambo, to a single seed element. The
symmetry you can see is therefore a picture of the incidence structure, not of the geometry.
*/
/* BOX_CODE_FOLD_0 */
fun hsv(hue: Double, s: Double, v: Double): Triple<Double, Double, Double> {
    val h = ((hue % 1.0) + 1.0) % 1.0
    val i = Math.floor(h * 6).toInt()
    val f = h * 6 - i
    val p = v * (1 - s)
    val q = v * (1 - f * s)
    val t = v * (1 - (1 - f) * s)
    return when (i % 6) {
        0 -> Triple(v, t, p)
        1 -> Triple(q, v, p)
        2 -> Triple(p, v, t)
        3 -> Triple(p, q, v)
        4 -> Triple(t, p, v)
        else -> Triple(v, p, q)
    }
}

/*
Which of the dodecahedron's twelve pentagons does an output face descend from? Element ids are
allocated rank by rank, so "the lowest source id" would silently pick a vertex every time — ask
for the rank-2 sources specifically. A face over the interior of one pentagon has exactly one; a
face straddling an original edge or corner has two or three, whose colors are blended.
*/
val faces = solid.topology.elements(2)
fun seedFacesOf(id: ElementId) = chain.sourceElements(id).filter { it.rank == 2 }.map { it.id.value }.sorted()

val pentagons = faces.flatMap { seedFacesOf(it.id) }.distinct().sorted()
val share = faces.groupingBy { seedFacesOf(it.id).size }.eachCount().toSortedMap()

/*
A face over one pentagon takes that pentagon's hue. A face straddling two or three of them takes
the blend — so the seams of the original dodecahedron colour themselves in between, and the
twelve-fold pattern reads without a single line being drawn. Saturation and brightness carry a
second signal: how many seed vertices and edges the face also touches.
*/
fun hueOf(pentagon: Int) = pentagons.indexOf(pentagon).toDouble() / pentagons.size
val faceLines = solid.toFaceFLines { face, line ->
    val owners = seedFacesOf(face.id)
    val sources = chain.sourceElements(face.id)
    val corners = sources.count { it.rank == 0 }
    val edges = sources.count { it.rank == 1 }
    val sat = (1.00 - 0.16 * corners).coerceIn(0.38, 1.0)
    val value = (0.78 + 0.16 * edges + 0.12 * owners.size).coerceIn(0.74, 1.0)
    val mixed =
        if (owners.isEmpty()) Triple(0.70, 0.74, 0.80)
        else
            owners
                .map { hsv(hueOf(it), sat, value) }
                .reduce { a, b -> Triple(a.first + b.first, a.second + b.second, a.third + b.third) }
                .let { Triple(it.first / owners.size, it.second / owners.size, it.third / owners.size) }
    line.filled = true
    line.stroked = false
    line.color = vec(mixed.first, mixed.second, mixed.third, if (owners.size == 1) 0.32 else 0.21)
    line.hoverColor = vec(0.98, 0.99, 1.00, 0.95)
}

threeLines(
    faceLines,
    channel = "hero",
    name = "kbD, canonical, coloured by seed provenance",
    height = 560,
    autoFrame = true,
    editable = false,
)
displayOpen("hero")

val topology = solid.topology
markdown(
    "what you are looking at",
    [
            "`kbD` = kis · bevel · dodecahedron, canonicalized",
            "${topology.elements(0).size} vertices · ${topology.elements(1).size} edges · " +
                "${topology.elements(2).size} faces · chi = ${topology.eulerCharacteristic()}",
            "seed pentagons found in the lineage: ${pentagons.size}",
            "output faces by how many of those pentagons they straddle: $share",
            "canonical: converged = ${run.converged}, reason = ${run.reason}, " +
                "tangency radius spread ${"%.3e".format(run.initialDiagnostics.tangencyRadiusSpread)} " +
                "→ ${"%.3e".format(run.finalDiagnostics.tangencyRadiusSpread)}",
        ]
        .joinToString("<br/>"),
)/* BOX_CODE_FOLD_1 */
