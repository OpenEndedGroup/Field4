/* BOX_CODE_FOLD_0 */
fun Box.gallery(channel: String, columns: Int, cell: Int, panels: List<Pair<String, PolyhedralObject>>) {
    val view = MeshView(wireframe = false, distance = 2.3)
    val rows = (panels.size + columns - 1) / columns
    threeGrid(
        panels.map { (label, p) ->
            val t = p.topology
            ThreeMeshPanel(
                label,
                p.toTriMesh(),
                facts =
                    "${t.elements(0).size}v ${t.elements(1).size}e ${t.elements(2).size}f · " +
                        t.elements(2)
                            .groupingBy { t.faceCycle(it.id).size }
                            .eachCount()
                            .toSortedMap()
                            .entries
                            .joinToString(" ") { "${it.value}×${it.key}-gon" } +
                        " · χ=${t.eulerCharacteristic()}",
            )
        },
        channel = channel,
        name = "gallery-$channel",
        padding = 1.02,
        columns = columns,
        height = rows * (cell * 0.84).toInt(),
        cellWidth = cell,
        view = view,
    )
}

/* BOX_CODE_FOLD_1 */

gallery(
    "composites",
    columns = 4,
    cell = 290,
    panels = [
        "jC   join = da" to conway("jC").polyhedron,
        "nC   needle = kd" to conway("nC").polyhedron,
        "zC   zip = dk" to conway("zC").polyhedron,
        "oC   ortho = jj" to conway("oC").polyhedron,
        "eC   expand = aa" to conway("eC").polyhedron,
        "sC   snub = dgd" to conway("sC").polyhedron,
        "mC   meta = kj" to conway("mC").polyhedron,
        "bC   bevel = ta" to conway("bC").polyhedron,
    ],
)
