import afield.io.osc.query.*

var cutoff = 1000.0
var on = true

val q = oscQuery("My piece")
q.float("/synth/cutoff", 20.0..20000.0, cutoff, "filter cutoff in Hz") { cutoff = it }
q.bool("/synth/on", on) { on = it }
q.menu("/scene", ["dawn", "dusk", "night"]) { scene -> markdown("scene: $scene") }
