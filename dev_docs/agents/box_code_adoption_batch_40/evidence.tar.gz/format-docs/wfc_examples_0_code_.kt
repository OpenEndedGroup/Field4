val SEA = 0
val SAND = 1
val GRASS = 2
val names = ["sea", "sand", "grass"]

// The primitive is directional. "May touch", for tiles that have no orientation, is that
// primitive applied both ways round in both authored directions.
fun WfcRulesBuilder.mayTouch(a: Int, b: Int) {
    for (d in [WFC_EAST, WFC_SOUTH]) {
        allow(d, a, b)
        allow(d, b, a)
    }
}

val rules = wfcRules(tileCount = 3) {
    weights(3.0, 1.0, 3.0) // sea and grass equally likely; sand rare, so it stays an interface
    mayTouch(SEA, SEA)
    mayTouch(SEA, SAND)
    mayTouch(SAND, SAND)
    mayTouch(SAND, GRASS)
    mayTouch(GRASS, GRASS)
    // Note what is absent: mayTouch(SEA, GRASS). That single omission is the whole model.
}

val solver = WfcSolver(width = 22, height = 14, rules = rules, seed = 12L)

/*
Seed both phases: sea pinned down the left edge, grass down the right. Without this the field
simply phase-separates — with only a one-cell-wide legal interface between them, whichever of
the two nucleates first tends to fill the whole grid. (The scalar field below shows that happening.)
*/
val outcome = solver.solveWithRetries {
    for (row in 0 until 14) {
        forceTile(0, row, SEA)
        forceTile(21, row, GRASS)
    }
}
val grid = solver.resolvedTileGridOrNull()!!

// Read the table back out of the model rather than restating it from the source above.
val table =
    (0..2).joinToString("<br>") { a ->
        "may sit east of <b>${names[a]}</b>: " +
            (0..2).filter { rules.allows(WFC_EAST, a, it) }.joinToString(", ") { names[it] }
    }
/* BOX_CODE_FOLD_0 */
// One display() per channel: a second display() on the same channel REPLACES the first.
markdown(
    "rules",
    """
    $table

    solved in ${outcome.attempts} attempt(s) · symmetric: ${rules.findAsymmetry() ?: "yes"}

    ${grid.count { it == SEA }} sea, ${grid.count { it == SAND }} sand, ${grid.count { it == GRASS }} grass of ${grid.size} cells
""",
)

/* BOX_CODE_FOLD_1 */

/* BOX_CODE_FOLD_2 */
val palette = [
    Triple(0.07f, 0.20f, 0.33f),
    Triple(0.85f, 0.78f, 0.55f),
    Triple(0.28f, 0.52f, 0.22f),
]
val img = Img.generateRGB(22, 14) { x, y -> palette[grid[x + y * 22]] }
showImgGrid("22x14 cells, seed 12" to img.upscaleNearest(26), columns = 1, cellSide = 700)/* BOX_CODE_FOLD_3 */
