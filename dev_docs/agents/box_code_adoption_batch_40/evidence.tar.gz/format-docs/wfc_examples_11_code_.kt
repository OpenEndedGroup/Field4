/*
Over-constrained: a strict 0 -> 1 -> 2 chain and nothing else. Hand-authored rules do
NOT get the widening that fromSampleGrid applies, so "nothing may sit east of tile 2" stands.
The longest fillable row is therefore three cells, and a 6x6 grid cannot be filled at all.
*/
val strict = wfcRules(tileCount = 3) {
    allow(WFC_EAST, 0, 1)
    allow(WFC_EAST, 1, 2)
    allow(WFC_SOUTH, 0, 1)
    allow(WFC_SOUTH, 1, 2)
}
val stuck = WfcSolver(6, 6, strict, seed = 1L)
val stuckOutcome = stuck.solveWithRetries(maxAttempts = 8)

// The same rules plus the fallback: every mask that was empty becomes "anything", symmetrically.
val relaxed = wfcRules(tileCount = 3) {
    allow(WFC_EAST, 0, 1)
    allow(WFC_EAST, 1, 2)
    allow(WFC_SOUTH, 0, 1)
    allow(WFC_SOUTH, 1, 2)
    allowMissingAnything()
}
val relaxedOutcome = WfcSolver(6, 6, relaxed, seed = 1L).solveWithRetries()

val report =
    [
            "strict rules:   ${stuckOutcome.status} after ${stuckOutcome.attempts} attempt(s)",
            "  east of 2:    ${(0..2).filter { strict.allows(WFC_EAST, 2, it) }} (nothing may follow it)",
            "  symmetric?    ${strict.findAsymmetry() ?: "yes"}",
            "relaxed rules:  ${relaxedOutcome.status} after ${relaxedOutcome.attempts} attempt(s)",
            "  east of 2:    ${(0..2).filter { relaxed.allows(WFC_EAST, 2, it) }}",
            "  symmetric?    ${relaxed.findAsymmetry() ?: "yes"}",
        ]
        .joinToString("\n")
/* BOX_CODE_FOLD_0 */
markdown(
    "deadlock",
    """
    ~~~
$report
    ~~~
""",
)

/* BOX_CODE_FOLD_1 */

/* BOX_CODE_FOLD_2 */
val chain = wfcRules(tileCount = 3) {
    weights(3.0, 1.0, 4.0)
    for (d in [WFC_EAST, WFC_SOUTH]) {
        allow(d, 0, 0)
        allow(d, 0, 1)
        allow(d, 1, 0)
        allow(d, 1, 1)
        allow(d, 1, 2)
        allow(d, 2, 1)
        allow(d, 2, 2)
    }
}
val shades = [Triple(0.07f, 0.20f, 0.33f), Triple(0.85f, 0.78f, 0.55f), Triple(0.28f, 0.52f, 0.22f)]
fun draw(seed: Long): Img {
    val s = WfcSolver(34, 22, chain, seed = seed)
    s.solveWithRetries()
    val g = s.resolvedTileGridOrNull()!!
    return Img.generateRGB(34, 22) { x, y -> shades[g[x + y * 34]] }.upscaleNearest(8)
}
showImgGrid(
    "seed 42" to draw(42L),
    "seed 42 again" to draw(42L),
    "seed 43" to draw(43L),
    columns = 3,
    cellSide = 300,
)/* BOX_CODE_FOLD_3 */
