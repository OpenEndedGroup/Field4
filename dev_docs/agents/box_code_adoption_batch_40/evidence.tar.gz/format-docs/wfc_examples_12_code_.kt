// The same two rule sets as the figure above, this time just looked at. One adjacency matrix per
// direction: row = tile, column = the neighbour that may sit at that offset from it.
val strict = wfcRules(tileCount = 3) {
    weights(3.0, 1.0, 2.0)
    allow(WFC_EAST, 0, 1)
    allow(WFC_EAST, 1, 2)
    allow(WFC_SOUTH, 0, 1)
    allow(WFC_SOUTH, 1, 2)
}
display("a. strict", strict.h)

val relaxed = wfcRules(tileCount = 3) {
    weights(3.0, 1.0, 2.0)
    allow(WFC_EAST, 0, 1)
    allow(WFC_EAST, 1, 2)
    allow(WFC_SOUTH, 0, 1)
    allow(WFC_SOUTH, 1, 2)
    allowMissingAnything()
}
display("b. widened", relaxed.h)

// And a learned model, for the zero-weight case: tile 2 never appears in the sample.
val learned = WfcRules.fromSampleGrid(
    sampleTileIds = intArrayOf(0, 1, 0, 1),
    sampleWidth = 4,
    sampleHeight = 1,
    tileCount = 3,
    wrapX = true,
)
display("c. learned, with an unused tile", learned.h)

println("strict:  " + strict)
println(
    "relaxed: " +
        relaxed +
        ", empty masks: " +
        (0 until 4).sumOf { d -> (0 until 3).count { relaxed.allowedCount(d, it) == 0 } },
)
println("learned: " + learned + ", weights " + learned.weights.toList())
