import afield.lang.morpho.*

/*
Same width, same colormap, same window, same everything except the algorithm. Colour is arrival
time normalised PER PANEL, so each shows its own critical path end to end -- the comparison is the
shape of the gradient, not its absolute value, which the depth numbers in the titles carry.
*/
val ripple = morphoCircuit("ripple_adder", 32, 32, 1)
val bk = morphoCircuit("brent_kung_adder", 32, 32, 1)
[ripple, bk].forEach { it.growFully(relaxSteps = 260) }

["ripple_adder" to ripple, "brent_kung_adder" to bk].forEach { (name, c) ->
    println(
        "%-18s %3d gates  depth %2d  %d nets"
            .format(
                name,
                c.netlist.gateCount,
                c.depth.toInt(),
                c.netlist.nNets,
            ),
    )
}

showPlaneGrid(
    "ripple_adder(32,32,1) — 64 gates, depth ${ripple.depth.toInt()}" to ripple.flines(fit = true),
    "brent_kung_adder(32,32,1) — 190 gates, depth ${bk.depth.toInt()}" to bk.flines(fit = true),
    columns = 2,
    cellWidth = 470,
    cellHeight = 470,
    window = morphoUnitWindow(),
)
