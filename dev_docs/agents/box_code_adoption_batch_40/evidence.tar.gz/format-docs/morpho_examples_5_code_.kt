import afield.lang.morpho.*

/*
One circuit, one layout, three cameras. XY is the view morpho's own renderer is restricted to,
because force_layout.js pins z. XZ looks straight down the axis XY drops: if the layout really
were planar, THAT panel would be a horizontal line and nothing else.
*/
val c = morphoCircuit("brent_kung_adder", 32, 32, 1)
c.growFully(relaxSteps = 300)

val b = c.layout.bounds()
println("extent  x %.1f  y %.1f  z %.1f".format(b[3] - b[0], b[4] - b[1], b[5] - b[2]))
println("z / max(x,y) = %.2f".format(c.layout.flatness()))

showPlaneGrid(
    "XY — what morpho's own renderer sees" to c.flines(projection = MorphoProjection.XY, fit = true),
    "XZ — down the axis XY discards" to c.flines(projection = MorphoProjection.XZ, fit = true),
    "isometric" to c.flines(projection = MorphoProjection.ISOMETRIC, fit = true),
    columns = 3,
    cellWidth = 340,
    cellHeight = 340,
    window = morphoUnitWindow(),
)
