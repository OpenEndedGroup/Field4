/* BOX_CODE_FOLD_0 */
fun bump(u: Double, v: Double, cx: Double, cy: Double, r: Double): Double {
    val dx = u - cx
    val dy = v - cy
    return exp(-(dx * dx + dy * dy) / (2.0 * r * r))
}

val palette = [
    Triple(0.08f, 0.20f, 0.31f), // deep water
    Triple(0.18f, 0.48f, 0.66f), // shallow water
    Triple(0.85f, 0.78f, 0.55f), // sand
    Triple(0.31f, 0.55f, 0.24f), // grass
    Triple(0.12f, 0.29f, 0.14f), // forest
]

val sw = 26
val sh = 18
val bands = IntArray(sw * sh)
for (cy in 0 until sh) for (cx in 0 until sw) {
    val u = cx / (sw - 1.0)
    val v = cy / (sh - 1.0)
    val e =
        bump(u, v, 0.30, 0.40, 0.25) + 0.90 * bump(u, v, 0.70, 0.62, 0.21) + 0.55 * bump(u, v, 0.82, 0.22, 0.13) -
            0.62 * bump(u, v, 0.34, 0.44, 0.085)
    bands[cx + cy * sw] = if (e < 0.16) 0 else if (e < 0.32) 1 else if (e < 0.44) 2 else if (e < 0.74) 3 else 4
}
val source = Img.generateRGB(sw, sh) { x, y -> palette[bands[x + y * sw]] }
/* BOX_CODE_FOLD_1 */

// The one changed line: 3x3 windows of the source instead of its five colours. wrapY = false so
// the model never learns that the top of the map sits above the bottom of it.
val patterns = source.toBufferedImage().sliceIntoOverlappingPatterns(3, 3, wrapX = false, wrapY = false)
val rules = patterns.toRules()

val outW = 40
val outH = 26

// Twelve seeds, because one picture of a stochastic process is an anecdote. No pinning, no
// re-weighting: this is the learned model exactly as `toRules()` handed it over.
val seeds = [1L, 3L, 5L, 7L, 9L, 11L, 12L, 17L, 23L, 42L, 101L, 2026L]
val panels = mutableListOf<Pair<String, Img>>()
var firstAttempt = 0
for (seed in seeds) {
    val solver = WfcSolver(outW, outH, rules, seed = seed)
    val outcome = solver.solveWithRetries(maxAttempts = 30)
    if (outcome.attempts == 1) firstAttempt++
    val grid = solver.resolvedTileGridOrNull() ?: continue
    panels.add("seed $seed" to patterns.toImg(grid, outW, outH).upscaleNearest(6))
}

/*
Why this figure has no ground constraint, read out of the model rather than asserted. The source's
corner is deep water, so that pixel identifies the band without re-deriving the palette's rounding.

An explicit loop with a typed `px`, not `.first { ... .all { it == deepArgb } }`: a box's scope is
crowded enough that `all` inside a nested lambda whose receiver has no written-down type resolves
to something else entirely, and the error surfaces on a later line.
*/
val deepArgb: Int = source.toBufferedImage().getRGB(0, 0)
var uniformDeep: Int = -1
for (id in 0 until patterns.tileCount) {
    val px: IntArray = patterns.patterns[id]
    if (px.all { v -> v == deepArgb }) {
        uniformDeep = id
        break
    }
}

val successors: String = (0..3).joinToString("  ") { d -> "dir " + d + " " + rules.allowedCount(d, uniformDeep) }
/* BOX_CODE_FOLD_2 */
val modelReport =
    "${patterns.tileCount} distinct 3x3 windows · ${panels.size}/${seeds.size} seeds solved, " +
        "$firstAttempt on the first attempt\n" +
        "the all-deep window may be followed by: " +
        successors
markdown(
    "model",
    """
    ~~~
$modelReport
    ~~~
""",
)

/* BOX_CODE_FOLD_3 */

display("main", montage(panels, columns = 4, cellSide = 300).toPngBytes())
