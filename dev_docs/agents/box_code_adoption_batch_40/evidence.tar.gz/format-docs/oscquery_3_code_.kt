import afield.io.osc.query.*

var gain = 0.5
var mute = false
val q = oscQuery("My piece", httpPort = 0)
q.controls("/surface") {
    slider("gain", 0.0, 1.0, initialValue = gain) { gain = it }
    checkbox("mute", mute) { mute = it }
}

val published = oscQueryRemote("127.0.0.1", q.httpPort).params.filter { it.path.startsWith("/surface") }
markdown(published.joinToString("\n") { "- `${it.path}` ${it.type} ${it.range}" })
