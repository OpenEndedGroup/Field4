val services = oscQueryDiscover()
markdown(services.joinToString("\n") { s -> "- **${s.instance}** at `${s.address}:${s.port}`" })

val chataigne = OscQueryRemote.find("Chataigne") // the first one whose name matches, or null
