import afield.lang.morpho.*

val c = morphoCircuit("wallace_multiplier", 16, 16)
c.growFully(relaxSteps = 250)
println(c.summary())

// The simulator is Field's, not morpho's -- there is no logic evaluator in the JavaScript at all.
val a = 48271L
val b = 16807L
val product = c.evaluateOne(a, b)[0]
val check = "%d x %d = %d %s".format(a, b, product, if (product == a * b) "(Kotlin agrees)" else "WRONG")

// Put the check in the panel's title, next to the circuit it is about.
showPlaneGrid(
    "${c.summary()}  |  $check" to c.flines(),
    columns = 1,
    cellWidth = 620,
    cellHeight = 620,
    window = morphoPlaneWindow(c.planeBounds()),
)
