import afield.lang.morpho.*

// Two designs growing on the same clock. Both start as ONE unexpanded cell -- everything you see
// arrive is morpho's compiler dividing a cell and rewiring what it divided.
val adder = morphoCircuit("brent_kung_adder", 32, 32, 1)
val shell = morphoCircuit("triangle", 32)

// Each panel fits its current geometry into the unit square. As the circuit grows, its scale
// changes too. New cells start at their parent's position before layout relaxation separates them.

loop {
    adder.step(grow = 2, relax = 5)
    shell.step(grow = 12, relax = 5)

    showPlaneGrid(
        "brent_kung_adder — %d gates, %d expansions".format(adder.netlist.gateCount, adder.expansions) to
            adder.flines(fit = true),
        "triangle(32) — %d gates, %d expansions".format(shell.netlist.gateCount, shell.expansions) to
            shell.flines(fit = true),
        columns = 2,
        cellWidth = 470,
        cellHeight = 470,
        window = morphoUnitWindow(),
    )
    frame()
}
