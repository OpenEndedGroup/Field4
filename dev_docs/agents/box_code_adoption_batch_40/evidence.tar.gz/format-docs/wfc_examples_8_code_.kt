/* BOX_CODE_FOLD_0 */
fun bump(u: Double, v: Double, cx: Double, cy: Double, r: Double): Double {
    val dx = u - cx
    val dy = v - cy
    return exp(-(dx * dx + dy * dy) / (2.0 * r * r))
}
val palette = [
    Triple(0.08f, 0.20f, 0.31f),
    Triple(0.18f, 0.48f, 0.66f),
    Triple(0.85f, 0.78f, 0.55f),
    Triple(0.31f, 0.55f, 0.24f),
    Triple(0.12f, 0.29f, 0.14f),
]
val bands = IntArray(26 * 18)
for (cy in 0 until 18) for (cx in 0 until 26) {
    val u = cx / 25.0
    val v = cy / 17.0
    val e =
        bump(u, v, 0.30, 0.40, 0.25) + 0.90 * bump(u, v, 0.70, 0.62, 0.21) + 0.55 * bump(u, v, 0.82, 0.22, 0.13) -
            0.62 * bump(u, v, 0.34, 0.44, 0.085)
    bands[cx + cy * 26] = if (e < 0.16) 0 else if (e < 0.32) 1 else if (e < 0.44) 2 else if (e < 0.74) 3 else 4
}
val source = Img.generateRGB(26, 18) { x, y -> palette[bands[x + y * 26]] }
val tiles = source.toBufferedImage().sliceIntoUniqueTiles(1, 1)
val rules = tiles.toRules()
val tileOfBand = IntArray(palette.size)
for (i in bands.indices) tileOfBand[bands[i]] = tiles.sampleIds[i]
rules.weights[tileOfBand[0]] *= 2.0
rules.weights[tileOfBand[1]] *= 1.5
rules.weights[tileOfBand[2]] *= 10.0

/* BOX_CODE_FOLD_1 */

// Halfway through a collapse. `.h` is the fragment ToHTML returns, so this is exactly what the box
// shows when its last expression is `solver` — nothing here is a special-purpose figure.
val solver = WfcSolver(34, 24, rules, seed = 5L)
while (solver.resolvedFraction() < 0.45 && solver.step() == WfcStatus.Running) {}
display("a. mid-collapse", solver.h)

/*
The same view of a failure. The over-constrained chain from the contradictions section: nothing may sit east of tile
2, so
a 6x6 grid cannot be filled, and propagation empties a cell.
*/
val strict = wfcRules(tileCount = 3) {
    allow(WFC_EAST, 0, 1)
    allow(WFC_EAST, 1, 2)
    allow(WFC_SOUTH, 0, 1)
    allow(WFC_SOUTH, 1, 2)
}
val stuck = WfcSolver(6, 6, strict, seed = 1L)
stuck.run()
display("b. contradicted", stuck.h)

/* BOX_CODE_FOLD_2 */
// And the numbers the panels are drawn from, so the picture can be checked against them.
val readBack =
    "mid-collapse: ${solver}\n" +
        "  entropy range drawn: 0 .. ${"%.3f".format(rules.fullSetEntropy())} nats" +
        " (${solver.entropyHeatmap().nonFiniteCount} cells undefined)\n" +
        "contradicted: ${stuck}\n" +
        "  cells with no possibilities left: ${stuck.possibilityCountGrid().count { it == 0 }}"
markdown(
    "c. read back",
    """
    ~~~
$readBack
    ~~~
""",
)/* BOX_CODE_FOLD_3 */
