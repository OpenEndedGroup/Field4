/* BOX_CODE_FOLD_0 */
fun bump(u: Double, v: Double, cx: Double, cy: Double, r: Double): Double {
    val dx = u - cx
    val dy = v - cy
    return exp(-(dx * dx + dy * dy) / (2.0 * r * r))
}
val palette = [
    Triple(0.08f, 0.20f, 0.31f),
    Triple(0.18f, 0.48f, 0.66f),
    Triple(0.85f, 0.78f, 0.55f),
    Triple(0.31f, 0.55f, 0.24f),
    Triple(0.12f, 0.29f, 0.14f),
]
val bands = IntArray(26 * 18)
for (cy in 0 until 18) for (cx in 0 until 26) {
    val u = cx / 25.0
    val v = cy / 17.0
    val e =
        bump(u, v, 0.30, 0.40, 0.25) + 0.90 * bump(u, v, 0.70, 0.62, 0.21) + 0.55 * bump(u, v, 0.82, 0.22, 0.13) -
            0.62 * bump(u, v, 0.34, 0.44, 0.085)
    bands[cx + cy * 26] = if (e < 0.16) 0 else if (e < 0.32) 1 else if (e < 0.44) 2 else if (e < 0.74) 3 else 4
}
val source = Img.generateRGB(26, 18) { x, y -> palette[bands[x + y * 26]] }
val tiles = source.toBufferedImage().sliceIntoUniqueTiles(1, 1)
val rules = tiles.toRules()

// The terrain's boost, so the collapse has all five bands in it and is worth watching.
val tileOfBand = IntArray(palette.size)
for (i in bands.indices) tileOfBand[bands[i]] = tiles.sampleIds[i]
rules.weights[tileOfBand[0]] *= 2.0
rules.weights[tileOfBand[1]] *= 1.5
rules.weights[tileOfBand[2]] *= 10.0

/* BOX_CODE_FOLD_1 */

val solver = WfcSolver(44, 30, rules, seed = 3L)
println("wfc collapse animation ready")

/*
A few step()s per displayed frame, then push the wave to the box's output channel.

One display() per frame, with the label drawn INTO the raster by montage(). showImg(caption = …)
would also be a single payload, but it is an HTML figure the browser re-parses every frame; baked
pixels keep a 20fps recording cheap, and the label cannot lag the picture it describes.
*/
loop {
    if (solver.status == WfcStatus.Running) solver.step() // one WFC iteration per displayed frame
    val label = "${(solver.resolvedFraction() * 100).toInt()}% decided — ${solver.status}"
    display(
        "main",
        montage(
                [label to tiles.waveToImg(solver).upscaleNearest(8)],
                columns = 1,
                cellSide = 460,
            )
            .toPngBytes(),
    )
    frame()
}
