oscQueryMirror(td, "td") { it.path.startsWith("/project1/") }
