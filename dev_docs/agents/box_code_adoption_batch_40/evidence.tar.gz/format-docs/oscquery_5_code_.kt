import afield.io.osc.query.*

val q = oscQuery("My piece", httpPort = 0)
q.float("/synth/cutoff", 20.0..20000.0, 1000.0, "filter cutoff in Hz") {}
q.bool("/synth/on", true) {}
q.menu("/scene", ["dawn", "dusk", "night"]) {}

val self = oscQueryRemote("127.0.0.1", q.httpPort)
markdown(self.params.joinToString("\n") { "- `${it.path}` ${it.type} ${it.range}" })
