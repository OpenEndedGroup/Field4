/* BOX_CODE_FOLD_0 */
fun bump(u: Double, v: Double, cx: Double, cy: Double, r: Double): Double {
    val dx = u - cx
    val dy = v - cy
    return exp(-(dx * dx + dy * dy) / (2.0 * r * r))
}

val palette = [
    Triple(0.08f, 0.20f, 0.31f), // deep water
    Triple(0.18f, 0.48f, 0.66f), // shallow water
    Triple(0.85f, 0.78f, 0.55f), // sand
    Triple(0.31f, 0.55f, 0.24f), // grass
    Triple(0.12f, 0.29f, 0.14f), // forest
]

val sw = 26
val sh = 18

// Keep the band index per cell as well as the picture: it is what lets the histogram below talk
// about terrain instead of about opaque tile IDs.
val bands = IntArray(sw * sh)
for (cy in 0 until sh) for (cx in 0 until sw) {
    val u = cx / (sw - 1.0)
    val v = cy / (sh - 1.0)
    val e =
        bump(u, v, 0.30, 0.40, 0.25) + 0.90 * bump(u, v, 0.70, 0.62, 0.21) + 0.55 * bump(u, v, 0.82, 0.22, 0.13) -
            0.62 * bump(u, v, 0.34, 0.44, 0.085)
    bands[cx + cy * sw] = if (e < 0.16) 0 else if (e < 0.32) 1 else if (e < 0.44) 2 else if (e < 0.74) 3 else 4
}
val source = Img.generateRGB(sw, sh) { x, y -> palette[bands[x + y * sw]] }
/* BOX_CODE_FOLD_1 */

// One pixel per tile. Five bands in, five unique tiles out.
val tiles = source.toBufferedImage().sliceIntoUniqueTiles(1, 1)
val rules = tiles.toRules()

// Tile IDs are discovery order, not band order. sampleIds is row-major over the same grid the
// source was drawn on, so one pass recovers the correspondence both ways.
val bandOfTile = IntArray(tiles.tileCount)
val tileOfBand = IntArray(palette.size)
for (cy in 0 until sh) for (cx in 0 until sw) {
    val i = cx + cy * sw
    bandOfTile[tiles.sampleIds[i]] = bands[i]
    tileOfBand[bands[i]] = tiles.sampleIds[i]
}

val outW = 40
val outH = 26

fun solveWith(model: WfcRules): IntArray {
    val solver = WfcSolver(outW, outH, model, seed = 12L)
    solver.solveWithRetries(maxAttempts = 30)
    return solver.resolvedTileGridOrNull()!!
}

val learned = solveWith(rules)

// The learned weights are just a DoubleArray, and the solver reads it live — so a learned model is
// editable. Boost the rare bands, and above all the *interface* band, sand.
val reweighted = tiles.toRules()
reweighted.weights[tileOfBand[0]] *= 2.0 // deep water
reweighted.weights[tileOfBand[1]] *= 1.5 // shallow water
reweighted.weights[tileOfBand[2]] *= 10.0 // sand, the only band that may touch both sides
val boosted = solveWith(reweighted)

val bandNames = ["deep", "shallow", "sand", "grass", "forest"]
fun histogram(cells: IntArray, bandOf: (Int) -> Int): String =
    palette.indices.joinToString("  ") { b ->
        bandNames[b] + " " + (cells.count { bandOf(it) == b } * 100 / cells.size).toString().padStart(2) + "%"
    }

/* BOX_CODE_FOLD_2 */
val bandReport =
    "source    ${histogram(bands) { it }}\n" +
        "learned   ${histogram(learned) { bandOfTile[it] }}\n" +
        "boosted   ${histogram(boosted) { bandOfTile[it] }}"
markdown(
    "bands",
    """
    ~~~
$bandReport
    ~~~
""",
)

/* BOX_CODE_FOLD_3 */

// Scale factors chosen so every panel is 360px tall: montage gives each cell the height of the
// tallest one, so mismatched panels leave a big empty band.
showImgGrid(
    "source 26x18" to source.upscaleNearest(20),
    "learned weights" to tiles.toImg(learned, outW, outH).upscaleNearest(14),
    "sand boosted x10" to tiles.toImg(boosted, outW, outH).upscaleNearest(14),
    columns = 1,
    cellSide = 620,
)
