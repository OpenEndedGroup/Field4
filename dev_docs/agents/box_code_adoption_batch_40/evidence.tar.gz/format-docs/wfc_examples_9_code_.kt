/* BOX_CODE_FOLD_0 */
fun bump(u: Double, v: Double, cx: Double, cy: Double, r: Double): Double {
    val dx = u - cx
    val dy = v - cy
    return exp(-(dx * dx + dy * dy) / (2.0 * r * r))
}

val sw = 26
val sh = 18
val levels = 6
val source = FloatArray(sw * sh)
for (cy in 0 until sh) for (cx in 0 until sw) {
    val u = cx / (sw - 1.0)
    val v = cy / (sh - 1.0)
    val e =
        (bump(u, v, 0.32, 0.42, 0.26) + 0.85 * bump(u, v, 0.70, 0.60, 0.22) + 0.50 * bump(u, v, 0.80, 0.24, 0.14))
            .coerceIn(0.0, 1.0)
    // Quantise, or exact-float dedup gives one tile per distinct value instead of six.
    source[cx + cy * sw] = (Math.round(e * (levels - 1)).toDouble() / (levels - 1)).toFloat()
}

/* BOX_CODE_FOLD_1 */

/*
Both float paths, on the same source. sliceIntoUniqueTiles2D is the FloatArray counterpart of
sliceIntoUniqueTiles(1, 1): one value per tile. sliceIntoOverlappingPatterns2D takes 3x3 windows
of *values* instead of colours.
*/
val tiles = source.sliceIntoUniqueTiles2D(sw, sh, tileWidth = 1, tileHeight = 1)
val patterns = source.sliceIntoOverlappingPatterns2D(sw, sh, 3, 3, wrapX = false, wrapY = false)

val outW = 40
val outH = 26

/* BOX_CODE_FOLD_2 */
// The lowest level, found by value rather than by ID: IDs are discovery order. For the overlapping
// set the equivalent is the 3x3 window that is uniformly at that level.
var lowestTile = 0
for (id in 0 until tiles.tileCount) {
    if (tiles.tiles[id][0] < tiles.tiles[lowestTile][0]) lowestTile = id
}
// Not "the uniformly-lowest window": this source has no 3x3 block entirely at level 0, because the
// lowest level only occupies a corner or two. The lowest window *on average* always exists.
var lowestPattern = 0
var lowestSum = Float.MAX_VALUE
for (id in 0 until patterns.tileCount) {
    var sum = 0f
    for (v in patterns.patterns[id]) sum += v
    if (sum < lowestSum) {
        lowestSum = sum
        lowestPattern = id
    }
}

/* BOX_CODE_FOLD_3 */

/*
Pin the border to the lowest level in both. Without it the field settles on whichever level
nucleates first, for exactly the reason the terrain did; with it, the field has to rise
inward through the chain.
*/
val tiledSolver = WfcSolver(outW, outH, tiles.toRules(), seed = 5L)
val tiledOutcome = tiledSolver.solveWithRetries(maxAttempts = 30) {
    for (x in 0 until outW) {
        forceTile(x, 0, lowestTile)
        forceTile(x, outH - 1, lowestTile)
    }
    for (y in 0 until outH) {
        forceTile(0, y, lowestTile)
        forceTile(outW - 1, y, lowestTile)
    }
}
/*
render() on a FloatTileSet gives back a FloatArray, not an image.
`throw`, not `error(...)`: a Field box has its own `error` in scope, and it does not return
Nothing, so the elvis would widen this to Any.
*/
val tiledGrid: IntArray =
    tiledSolver.resolvedTileGridOrNull() ?: throw IllegalStateException("tiled model ended " + tiledSolver.status)
val tiledHeights: FloatArray = tiles.render(tiledGrid, outW, outH)

/*
The pattern model gets no pinning at all. Pinning the whole border to one window over-constrains
it into a contradiction (a corner has to satisfy the ring in both directions at once) -- and it
does not need the help: a 3x3 window of values already encodes what a slope looks like.
*/
val patternSolver = WfcSolver(outW, outH, patterns.toRules(), seed = 5L)
val patternOutcome = patternSolver.solveWithRetries(maxAttempts = 30)
val patternGrid: IntArray =
    patternSolver.resolvedTileGridOrNull() ?: throw IllegalStateException("pattern model ended " + patternSolver.status)
val patternHeights: FloatArray = patterns.render(patternGrid, outW, outH)

/*
And the same pattern set closed under the symmetries of the square. A heightfield has no up, so
a rotated legal arrangement is also legal -- expandSymmetry says exactly that, and it is the one
line that turns the banded result below into terrain.

Three seeds rather than one, because the claim is about the ensemble: each field keeps a grain,
and what symmetry closure removes is every field having the SAME grain. One panel cannot show that.
*/
val symmetric = patterns.expandSymmetry(WfcSymmetry.All)
val symSeeds = [5L, 23L, 42L]
val symFields = mutableListOf<Pair<Long, FloatArray>>()
for (seed in symSeeds) {
    val solver = WfcSolver(outW, outH, symmetric.toRules(), seed = seed)
    solver.solveWithRetries(maxAttempts = 30)
    val grid: IntArray =
        solver.resolvedTileGridOrNull()
            ?: throw IllegalStateException("symmetric model, seed " + seed + ", ended " + solver.status)
    symFields.add(seed to symmetric.render(grid, outW, outH))
}
val symHeights: FloatArray = symFields[0].second

val tiledField = floatsToImg(tiledHeights, outW, outH)
val patternField = floatsToImg(patternHeights, outW, outH)
// The contour panel is taken from seed 23, the middle one below, so it can be matched to its field.
val symField = floatsToImg(symFields[1].second, outW, outH)

/* BOX_CODE_FOLD_4 */
// Mean |difference| between neighbours along rows vs down columns. One number per axis is all it
// takes to say "banded" out loud instead of pointing at the picture.
fun grain(v: FloatArray, w: Int, h: Int): Pair<Double, Double> {
    var hs = 0.0
    var vs = 0.0
    var hn = 0
    var vn = 0
    for (y in 0 until h) for (x in 0 until w) {
        if (x + 1 < w) {
            hs += kotlin.math.abs(v[x + y * w] - v[x + 1 + y * w])
            hn++
        }
        if (y + 1 < h) {
            vs += kotlin.math.abs(v[x + y * w] - v[x + (y + 1) * w])
            vn++
        }
    }
    return (hs / hn) to (vs / vn)
}

val plainGrain = grain(patternHeights, outW, outH)
val symLines =
    symFields.joinToString("\n") { entry ->
        val g = grain(entry.second, outW, outH)
        "3x3 + D4 seed " +
            entry.first.toString().padEnd(3) +
            " grain along rows ${"%.3f".format(g.first)} / down columns ${"%.3f".format(g.second)}" +
            ", ratio ${"%.1f".format(maxOf(g.first, g.second) / maxOf(1e-6, minOf(g.first, g.second)))}x"
    }
/* BOX_CODE_FOLD_5 */

/* BOX_CODE_FOLD_6 */
val statsReport =
    "${tiles.tileCount} levels; ${patterns.tileCount} distinct 3x3 windows -> " +
        "${symmetric.tileCount} once closed under D4\n" +
        "1x1 tiles          mean ${"%.2f".format(tiledHeights.average())}, " +
        "${tiledOutcome.attempts} attempt(s)\n" +
        "3x3 patterns       grain along rows ${"%.3f".format(plainGrain.first)} / down columns " +
        "${"%.3f".format(plainGrain.second)}" +
        ", ratio ${"%.1f".format(maxOf(plainGrain.first, plainGrain.second) / maxOf(1e-6, minOf(plainGrain.first, plainGrain.second)))}x\n" +
        symLines
markdown(
    "stats",
    """
    ~~~
$statsReport
    ~~~
""",
)

/* BOX_CODE_FOLD_7 */

/* BOX_CODE_FOLD_8 */
/*
Terraced levels contour into blocky steps, so smooth before extracting geometry. This is the whole
point of ending up in a FloatArray rather than in pixels: iso-contours are FLines. Contour the D4
field -- the banded one has nothing worth contouring.
*/
val smooth = symField.gaussianBlur(1.2)
val contours = ArrayList<FLine>()
for (iso in [0.15, 0.35, 0.55, 0.75]) {
    for (line in smooth.isoContourFLines(iso)) {
        line.color = vec(0.30 + iso * 0.65, 0.95 - iso * 0.45, 0.40 + iso * 0.45, 0.95)
        line.thickness = 1.6
        contours.add(line)
    }
}

val panels = mutableListOf(
    "source 26x18, 6 levels" to
        floatsToImg(source, sw, sh).colormap("viridis", lo = 0f, hi = 1f).upscaleNearest(14),
    "1x1 tiles, border pinned" to tiledField.colormap("viridis", lo = 0f, hi = 1f).upscaleNearest(9),
    "3x3 patterns, as learned" to patternField.colormap("viridis", lo = 0f, hi = 1f).upscaleNearest(9),
)
for (entry in symFields) {
    panels.add(
        "3x3 + D4, seed ${entry.first}" to
            floatsToImg(entry.second, outW, outH).colormap("viridis", lo = 0f, hi = 1f).upscaleNearest(9),
    )
}
/* BOX_CODE_FOLD_9 */
showImgGrid(*panels.toTypedArray(), columns = 3, cellSide = 400)
lines(contours, channel = "contours", w = 900.0, h = 560.0, fitToSize = true)
