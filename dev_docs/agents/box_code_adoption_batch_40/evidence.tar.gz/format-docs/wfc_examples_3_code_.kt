// Sockets per tile, in WFC_NORTH, WFC_EAST, WFC_SOUTH, WFC_WEST order. 1 = a trace leaves this edge.
val sockets = [
    intArrayOf(0, 0, 0, 0), // blank
    intArrayOf(0, 1, 0, 1), // horizontal
    intArrayOf(1, 0, 1, 0), // vertical
    intArrayOf(1, 1, 0, 0), // elbow N-E
    intArrayOf(0, 1, 1, 0), // elbow E-S
    intArrayOf(0, 0, 1, 1), // elbow S-W
    intArrayOf(1, 0, 0, 1), // elbow W-N
    intArrayOf(1, 1, 1, 1), // cross
]

// Edge matching, stated once. Everything else about the picture follows from it.
val rules = wfcRules(tileCount = sockets.size) {
    weights(6.0, 2.0, 2.0, 1.0, 1.0, 1.0, 1.0, 0.35)
    for (a in sockets.indices) for (b in sockets.indices) {
        if (sockets[a][WFC_EAST] == sockets[b][WFC_WEST]) allow(WFC_EAST, a, b)
        if (sockets[a][WFC_SOUTH] == sockets[b][WFC_NORTH]) allow(WFC_SOUTH, a, b)
    }
}

/* BOX_CODE_FOLD_0 */
val side = 11
val c = side / 2
val bg = 0xFF10241C.toInt()
val trace = 0xFF64E0A0.toInt()
val pad = 0xFFB8FFDA.toInt()

// A top-level fun, not one nested inside the Array(...) lambda below: a local fun declared inside
// a lambda in a Field box trips a K2 codegen assertion ("has no callableId").
fun traceArt(s: IntArray): IntArray {
    val px = IntArray(side * side) { bg }
    if (s[WFC_NORTH] == 1)
        for (y in 0..c) {
            px[c + y * side] = trace
            px[(c - 1) + y * side] = trace
        }
    if (s[WFC_SOUTH] == 1)
        for (y in c until side) {
            px[c + y * side] = trace
            px[(c - 1) + y * side] = trace
        }
    if (s[WFC_WEST] == 1)
        for (x in 0..c) {
            px[x + c * side] = trace
            px[x + (c - 1) * side] = trace
        }
    if (s[WFC_EAST] == 1)
        for (x in c until side) {
            px[x + c * side] = trace
            px[x + (c - 1) * side] = trace
        }
    if (s.any { it == 1 }) for (y in (c - 1)..c) for (x in (c - 1)..c) px[x + y * side] = pad
    return px
}

// A PngTileSet can be assembled from hand-drawn art; sampleIds is just the atlas row here,
// because nothing is being learned from it.
val tiles = PngTileSet(
    side,
    side,
    Array(sockets.size) { traceArt(sockets[it]) },
    IntArray(sockets.size) { it },
    sockets.size,
    1,
)
/* BOX_CODE_FOLD_1 */

val solver = WfcSolver(34, 22, rules, seed = 20260728L)
val outcome = solver.solveWithRetries()
val grid = solver.resolvedTileGridOrNull()!!

// Separate channels rather than one montage: the atlas strip and the output have wildly different
// aspect ratios, and a uniform grid would give the strip a cell 5 times taller than it needs.
display("tiles", tiles.sampleToImg().upscaleNearest(6).toPngBytes())
display("main", tiles.toImg(grid, 34, 22).upscaleNearest(2).toPngBytes())
/* BOX_CODE_FOLD_2 */
markdown(
    "counts",
    "${outcome.attempts} attempt(s) · ${grid.count { it == 7 }} crossings · " +
        "${grid.count { it == 0 }} blank of ${grid.size} cells",
) /* BOX_CODE_FOLD_3 */
