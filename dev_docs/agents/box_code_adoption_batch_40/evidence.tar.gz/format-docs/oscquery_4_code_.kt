val td = oscQueryRemote("127.0.0.1", 9000)
td["/project1/level"].set(0.5) // sent as OSC, as the type the server declares
td["/project1/level"].listen { v -> markdown("level: $v") }

markdown(td.params.joinToString("\n") { "- `${it.path}` ${it.type} ${it.range}" })
