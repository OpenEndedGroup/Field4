val symmetric = patterns.expandSymmetry(WfcSymmetry.All)
