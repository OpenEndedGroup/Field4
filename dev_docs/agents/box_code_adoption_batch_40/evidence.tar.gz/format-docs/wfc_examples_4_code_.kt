val SKY = Triple(0.75f, 0.86f, 0.94f)
val SOIL = Triple(0.42f, 0.29f, 0.16f)
val STEM = Triple(0.24f, 0.56f, 0.23f)
val BLOSSOM = Triple(0.88f, 0.34f, 0.42f)

val sw = 26
val sh = 18
val soilTop = 13
val flowers = [3 to 4, 8 to 6, 13 to 3, 18 to 5, 22 to 4] // column to stem height

val source =
    Img.generateRGB(sw, sh) { x, y ->
        val flower = flowers.firstOrNull { it.first == x }
        when {
            y >= soilTop -> SOIL
            flower != null && y == soilTop - flower.second - 1 -> BLOSSOM
            flower != null && y >= soilTop - flower.second -> STEM
            else -> SKY
        }
    }

// Every 3x3 window, deduped. wrapY = false: wrapping vertically would teach it that soil sits
// above sky, which is the one thing this source is trying to say is untrue.
val patterns = source.toBufferedImage().sliceIntoOverlappingPatterns(3, 3, wrapX = true, wrapY = false)
val rules = patterns.toRules()

// Named outW/outH, not w/h: inside a lambda that has its own receiver (solveWithRetries' prepare
// block below), a bare `h` resolves to the Box's own frame height rather than to this local.
val outW = 60
val outH = 16

// WFC has no notion of absolute position. Left alone it will happily satisfy every rule with
// "soil everywhere", which is a perfectly legal tiling of this pattern set.
val free = WfcSolver(outW, outH, rules, seed = 9L)
free.solveWithRetries(maxAttempts = 30)
val freeOut = patterns.toImg(free.resolvedTileGridOrNull()!!, outW, outH)

/*
So pin the boundary: the classic WFC "ground" constraint. Note that reset() clears forced cells
too, so the pinning goes in solveWithRetries' prepare block to be re-applied on every attempt.
(Named groundPattern/skyPattern because a bare `sky` is already taken in a Field box's scope.)
The all-soil and all-sky 3x3 patterns, found by looking for a flat window and testing its blue.
*/
var groundPattern: Int = -1
var skyPattern: Int = -1
for (id in 0 until patterns.tileCount) {
    val px: IntArray = patterns.patterns[id]
    if (!px.all { v -> v == px[0] }) continue
    val blue: Int = px[0] and 0xff
    if (blue < 0x60) groundPattern = id
    if (blue > 0xC0) skyPattern = id
}

val solver = WfcSolver(outW, outH, rules, seed = 4L)
val outcome = solver.solveWithRetries(maxAttempts = 30) {
    for (x in 0 until outW) {
        forceTile(x, outH - 1, groundPattern)
        forceTile(x, 0, skyPattern)
    }
}
val out = patterns.toImg(solver.resolvedTileGridOrNull()!!, outW, outH)

/* BOX_CODE_FOLD_0 */
markdown(
    "model",
    "${patterns.tileCount} distinct 3x3 patterns · ground pattern \\#$groundPattern, " +
        "sky pattern \\#$skyPattern · solved in ${outcome.attempts} attempt(s)",
)
/* BOX_CODE_FOLD_1 */
showImgGrid(
    "source 26x18" to source.upscaleNearest(9),
    "no ground constraint" to freeOut.upscaleNearest(9),
    "ground + sky pinned" to out.upscaleNearest(9),
    columns = 1,
    cellSide = 620,
)
