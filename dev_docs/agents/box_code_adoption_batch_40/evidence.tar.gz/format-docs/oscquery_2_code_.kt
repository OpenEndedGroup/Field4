val level = q.float("/meter/level", 0.0..1.0, access = OscAccess.READ)
loop {
    level.set(0.5 + 0.5 * sin(AnimationClock.nowSeconds()))
    delay(30)
}
