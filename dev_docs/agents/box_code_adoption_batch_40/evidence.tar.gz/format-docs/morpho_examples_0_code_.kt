import afield.lang.morpho.*

/*
Each panel gets its OWN window: these are four different circuits at four different sizes, and a
shared frame would shrink the shifter to a speck to fit the multiplier. Where a shared frame IS
required -- the two adders below, the three projections further down -- it is used and said so.
*/
val designs = [
    Triple("ripple_adder", intArrayOf(16, 16, 1), "carry chain"),
    Triple("brent_kung_adder", intArrayOf(16, 16, 1), "prefix tree"),
    Triple("right_shifter", intArrayOf(32, 5, 1), "mux cascade"),
    Triple("wallace_multiplier", intArrayOf(8, 8), "compression tree"),
]

val panels = designs.map { (design, sig, kind) ->
    val c = morphoCircuit(design, *sig)
    c.growFully(relaxSteps = 220)
    println(
        "%-20s %4d gates  depth %2d  z/xy %.2f  (%s)"
            .format(
                design,
                c.netlist.gateCount,
                c.depth.toInt(),
                c.layout.flatness(),
                kind,
            ),
    )
    "%s(%s) — %d gates, depth %d".format(design, sig.joinToString(","), c.netlist.gateCount, c.depth.toInt()) to
        c.flines(fit = true)
}

// fit = true normalises each panel into the unit square, which is the only way showPlaneGrid can
// frame four differently-sized circuits independently: it takes one window for the whole grid.
showPlaneGrid(
    *panels.toTypedArray(),
    columns = 2,
    cellWidth = 430,
    cellHeight = 430,
    window = morphoUnitWindow(),
)
