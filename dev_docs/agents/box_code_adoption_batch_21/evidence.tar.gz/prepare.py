from pathlib import Path
import json,yaml
h=Path('dev_docs/agents/box_code_adoption_batch_21');rows=[]
def edit(path,ids,fn):
 p=Path(path);before=p.read_text();after=fn(before);assert after!=before;rows.append(dict(path=path,before=before,after=after,findingIds=ids));p.write_text(after)
for name in ['corpus','classify']:
 edit(f'dev_docs/agents/demos/completion_rank_at_scale/{name}_code_.kt',['529867af68d6-01'] if name=='corpus' else [],lambda s:s.replace('.bufferedReader().readLines()', '.bufferedReader().use { it.readLines() }'))
path='dev_docs/agents/demos/pattern_condense/condense_invents_nothing_code_.kt'
edit(path,['771fe021c5ec-01'],lambda s:s.replace('val trials = 300','''val trials = 300

require(density > 0) { "density must be positive (one step in N is on)" }
require(trials > 0) { "trials must be positive to compare compression" }'''))
side=rows[-1]
p=Path('dev_docs/agents/demos/pattern_condense/build.yaml');before=p.read_text();node=yaml.compose(before);edits=[]
def visit(n):
 if isinstance(n,yaml.MappingNode):
  for k,v in n.value:
   if k.value=='code' and isinstance(v,yaml.ScalarNode) and 'val trials = 300' in v.value:
    after=v.value.replace('val trials = 300','val trials = 300\n\nrequire(density > 0) { "density must be positive (one step in N is on)" }\nrequire(trials > 0) { "trials must be positive to compare compression" }');indent=k.start_mark.column+2;value='|\n'+''.join(' '*indent+x+'\n' if x else '\n' for x in after.rstrip('\n').splitlines());edits.append((v.start_mark.index,v.end_mark.index,value))
   else:visit(v)
 elif isinstance(n,yaml.SequenceNode):
  for v in n.value:visit(v)
visit(node);assert len(edits)==1;after=before
for a,b,v in reversed(edits):after=after[:a]+v+after[b:]
p.write_text(after);rows.append(dict(path=str(p),before=before,after=after,findingIds=[]))
edit('dev_docs/agents/transcripts/control_surface_laws.yaml',['c1345019b329-02'],lambda s:s.replace('log += if (down) "gate down" else "gate up"','log += if (down) "gate down" else "gate up"\n                  if (log.size > 6) log.removeAt(0)').replace('println(log.takeLast(6).joinToString("  "))','println(log.joinToString("  "))'))
edit('dev_docs/agents/transcripts/inertial_movement.yaml',['d020fbb89ce4-01'],lambda s:s.replace('seen += eased()','seen += eased()\n              if (target.size > 240) {\n                  target.removeAt(0)\n                  seen.removeAt(0)\n              }').replace('fromRest += restarted()','fromRest += restarted()\n              if (target.size > 300) {\n                  target.removeAt(0)\n                  reSolved.removeAt(0)\n                  fromRest.removeAt(0)\n              }').replace('target.takeLast(240)','target').replace('seen.takeLast(240)','seen').replace('target.takeLast(300)','target').replace('reSolved.takeLast(300)','reSolved').replace('fromRest.takeLast(300)','fromRest'))
(h/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(h.parent/'box_code_adoption_batch_20'/name).read_text().replace('adoption-20','adoption-21').replace("'68c5d6fa3'","'a8a5d6e4f'");(h/name).write_text(s)
