/*
A polyline's content is its node list, which is one property among four. The adapter
turns it into a node table: index, instruction kind, control-point count, endpoint, and how
many per-node properties each carries.

This example is open. Add close() to inspect a Close row, which has no stored endpoint.
*/

val f = FLine().moveTo(0.15, 0.2).lineTo(0.85, 0.2).cubicTo(0.95, 0.5, 0.75, 0.8, 0.5, 0.8).lineTo(0.15, 0.5)

display("fline", f.h2)
displayOpen("fline")
