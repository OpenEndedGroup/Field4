import afield.graphics.text.slug.*
import org.lwjgl.vulkan.VK10.*

name = "5e. Slug filled paths"
// Build the optional helper once: bash native/field-slug/build.sh
val path =
    FLine().moveTo(-1, -1).lineTo(1, -1).cubicTo(vec(1.4, 0, 0), vec(0.8, 1.3, 0), vec(0, 1, 0)).lineTo(-1, 1).close()
// Clockwise inner contour cuts a hole in the counterclockwise outer contour.
path.moveTo(-0.3, -0.3).lineTo(-0.3, 0.3).lineTo(0.3, 0.3).lineTo(0.3, -0.3).close()
val prepared = SlugPath.compile(path, "field-slug".file)

// Prepare the native path above before running this GPU setup fragment.
//%-
val module = moduleHere {
    primitiveType = triangles
    srcAlpha = VK_BLEND_FACTOR_ONE
    depthWrite = false
}
val mesh = Mesh()
module += "slug" to mesh
renderer += module
mesh.resize(6)
val data = SlugBuffer(renderer, prepared)

RunScope.current()!!.own(policy = ReleasePolicy.RUNNING) {
    if (module.current.meshes["slug"] === mesh) module.current.meshes.remove("slug")
    data.close()
}

mesh.slugData = { data }
val camera = Camera()
camera.at = vec(0, 0, -4)

mesh.mvp = { Matrix4f(camera.p.evaluateUniform()).mul(camera.modelView()) }
mesh.viewport = {
    val extent = renderer.swapChain.swapChainExtent
    vec(extent.width(), extent.height())
}
var tint = vec(0.9, 0.9, 0.9, 0.8)
mesh.tint = { tint }

// Focus the renderer window: WASD/arrows move, E/C rise/fall, R resets.
var kc by keyCamera(camera = camera)

/*
Change tint or camera without preparing geometry again.
Geometry edits: prepare a new SlugPath, then data.replace(newPath) on the render thread.
Re-running/stopping this box removes its mesh before retiring the atlas.
*/
