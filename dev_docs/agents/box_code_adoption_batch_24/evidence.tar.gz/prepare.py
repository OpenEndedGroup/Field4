from pathlib import Path
import json
h=Path('dev_docs/agents/box_code_adoption_batch_24');rows=[]
def edit(path,ids,fn):
 p=Path(path);before=p.read_text();after=fn(before);assert after!=before;rows.append(dict(path=path,before=before,after=after,findingIds=ids));p.write_text(after)
def replace_block(s,start,end,new):
 a=s.index(start);b=s.index(end,a);return s[:a]+new+s[b:]
b='dev_docs/agents/demos/skinned_characters/'
edit(b+'c82c404d-a15d-4f51-a06f-66dfc2a00364_code_.kt',['6caa5d8a54fe-01'],lambda s:replace_block(replace_block(s,'// ONE mesh, deliberately.','var (module, models)',"// Both mesh views would share inst's uploaded vertex buffer. Use one mesh per chosen method.\n\n"),'// These four lines were left over','val radius =','// Compare the deformed joint ring with its rest radius.\n'))
edit(b+'gpu_skin_code_.kt',['6caa5d8a54fe-02','6caa5d8a54fe-04'],lambda s:replace_block(s,'// This box needs a renderer','var (module, models)','// Launch the connected renderer parent first.\n\n').split('// ----------------------------------------------------------------------------------------------')[0].rstrip()+'\n\n// Pose and upload once; edit poseTime and rerun to inspect a different bend.\n')
edit(b+'f5e60137-f514-4c01-865c-5af02f1d8eee_code_.kt',[],lambda s:replace_block(s,'// The window and renderer','prop<Window>',"// Publish the window and renderer for the connected drawing boxes.\n"))
edit(b+'path_trace_code_.kt',[],lambda s:replace_block(s,'// The line this whole branch','val rig =','// Compare path-tracing geometry imported at rest and at the selected bend pose.\n\n'))
edit(b+'rig_facts_code_.kt',[],lambda s:replace_block(s,'// Field could load a glTF','val rig =','// Inspect the rig, joint weights and sampled poses before drawing the deformed mesh.\n\n'))
for file,id in [('emptry_fragment','b07235012645-01'),('plain_fragment','f7d1b3cac96f-01')]:
 edit(f'src/jvmMain/resources/{file}.glsl',[id],lambda s:s.replace('    vec4 c = texture(bbc, textCoords.yx);','    // Preserve this material\'s transposed texture orientation: sample (V, U).\n    vec4 c = texture(bbc, textCoords.yx);'))
for file,id,comment in [('e3fe297a-36b5-450a-8343-116e105de4ee','2792e161f146-02','Use the interpolated vertex RGB with opaque alpha.'),('8b78e419-cd1e-4111-96ab-899eb3ed47d1',None,'Start opaque; the sampled texture RGB below replaces this base color.')]:
 edit(f'templates/advanced_remote/{file}_fragment_.glsl',[id] if id else [],lambda s:s.replace('// this is our translucent red','// '+comment))
edit('templates/h2-explorer-examples/15301b9c-4454-4b37-b439-7c5fc2c8d06d_code_.kt',['60769e678e73-01'],lambda s:replace_block(s,'// Note the `Close` row:','import afield', '// This example is open. Add close() to inspect a Close row, which has no stored endpoint.\n\n'))
edit('dev_docs/graphics/slug-prototype/code.kt',['a7adc74d5415-01'],lambda s:s.replace('//%-','// Prepare the native path above before running this GPU setup fragment.\n//%-',1))
edit('public/docs/assets/three_mesh_pick_demo/mesh-pick-clearance_code_.kt',['875122303a20-01'],lambda s:replace_block(replace_block(s,'// A SOLID and its ANNOTATIONS','// Run this box.','// A solid and its annotations share one scene and one measurement tool.\n//\n'),'// it, and the viewer\'s toolbar','//             Where you click', '// it. Use the ruler to click the slab, then the conduit: the dimension measures\n// their closest approach between the selected triangle and line segment.\n//\n'))
(h/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
