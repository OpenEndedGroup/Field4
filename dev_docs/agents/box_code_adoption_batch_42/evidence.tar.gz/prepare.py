from pathlib import Path
import json,yaml
H=Path('dev_docs/agents/box_code_adoption_batch_42');rows=[]
def record(p,b,a):
 assert b!=a,p;p.write_text(a);rows.append({'path':str(p),'before':b,'after':a})
p=Path('public/docs/chain_scene_to_light.md');b=p.read_text();a=b
start=a.index('// Plain objects rather than the box helpers');end=a.index(':::endfold',start)
a=a[:start]+'''// Nested scopes close the sender even if receiver construction fails.
val port = 35692
DmxOutput(DmxProtocol.SACN, host = "127.0.0.1", port = port, autoStart = false, discovery = false).use { out ->
    DmxInput(DmxProtocol.SACN, port = port, bindAddress = "127.0.0.1").use { node ->
        rig.patch.render(out)
        out.flush()
        val deadline = System.nanoTime() + 2_000_000_000L
        while ((node.version(1) == 0L || node.version(2) == 0L) && System.nanoTime() < deadline) Thread.sleep(5)
        check(node.version(1) > 0L && node.version(2) > 0L) {
            "Incomplete sACN frame on port $port after 2 seconds: universe 1=${node.version(1)}, universe 2=${node.version(2)}. Check sender address/port."
        }
        showPatch(rig.patch, channel = "sent", w = 540.0, h = 330.0)
        showReceived(rig.patch, node, channel = "received", w = 540.0, h = 330.0)
    }
}
'''+a[end:];record(p,b,a)
p=Path('public/docs/rtp_midi.md');b=p.read_text();a=b
start=a.index('for (pitch in [60, 64, 67, 72])');end=a.index('\n```',start)
a=a[:start]+'''frames {
    for (pitch in [60, 64, 67, 72]) {
        midi.noteOn(pitch, 90)
        try {
            delay(150) // Milliseconds; yields to Field while the note sounds.
        } finally {
            midi.noteOff(pitch) // Stop or rerun also releases the current note.
        }
    }
    midi.controlChange(74, 100)
    midi.pitchBend(-2000)
    midi.sysex(byteArrayOf(0x7D, 1, 2, 3)) // The F0 ... F7 framing is added.
}'''+a[end:]
a=a.replace('Whatever a box sends goes to every connected peer:','Whatever a box sends goes to every connected peer. **Launch** this sequence; Stop or rerun\ncancels its wait and releases the current note:');record(p,b,a)
p=Path('dev_docs/agents/transcripts/rtp_midi_demo.yaml');b=p.read_text();d=yaml.safe_load(b);by={o['create']['box']:o['create'] for o in d['operations'] if 'create' in o}
peer=by['rtpm-peer']['properties']['code'];start=peer.index('// The invitation and the first clock exchange');tail=peer[peer.index('markdown("peers"',start):]
peer=peer[:start]+'''// Launch: wait for a real connection and clock sample, with a bounded deadline.
frames {
    val deadline = System.nanoTime() + 12_000_000_000L
    while (other.peers.none { it.connected && it.roundTripStatsMs != null }) {
        check(System.nanoTime() < deadline) { "RTP-MIDI peer did not connect and synchronize within 12 seconds" }
        frame()
    }
'''+''.join('    '+line+'\n' for line in tail.rstrip().splitlines())+'}\n'
play=by['rtpm-play']['properties']['code'];start=play.index('for (pitch in');play=play[:start]+'''val field = rtpMidi("Field")

// Launch: cancellation releases the current note before this sequence ends.
frames {
    for (pitch in [60, 64, 67, 72]) {
        other.noteOn(pitch, 90)
        try {
            delay(150) // Milliseconds; the receiver keeps processing while we wait.
        } finally {
            other.noteOff(pitch)
        }
    }
    other.controlChange(74, 100)
    delay(100) // Let the last packets arrive before reading the receiver's counters.
    markdown("received", "box 1's session has received ${field.messageCount} messages; held notes: ${field.held.size}")
}
'''
replacements={'rtpm-peer':peer,'rtpm-play':play};edits=[]
def visit(node):
 if isinstance(node,yaml.MappingNode):
  mapping={k.value:v for k,v in node.value}
  if 'create' in mapping:
   c=mapping['create'];cm={k.value:v for k,v in c.value};box=cm['box'].value
   if box in replacements:
    props={k.value:v for k,v in cm['properties'].value};v=props['code'];indent=v.start_mark.column+2
    # Scalar's start is on the properties key line; body indentation follows the code key.
    indent=next(k.start_mark.column+2 for k,x in cm['properties'].value if k.value=='code')
    value='|\n'+''.join(' '*indent+line+'\n' if line else '\n' for line in replacements[box].rstrip('\n').splitlines());edits.append((v.start_mark.index,v.end_mark.index,value))
  for k,v in node.value:visit(v)
 elif isinstance(node,yaml.SequenceNode):
  for v in node.value:visit(v)
visit(yaml.compose(b));a=b
for x,y,v in sorted(edits,reverse=True):a=a[:x]+v+a[y:]
a=a.replace('session join it, and play notes and a controller into it. Run them in order;', 'session join it, and play notes and a controller into it. Run box 1, then launch boxes 2 and 3;')
a=a.replace('2. A peer joins (run)','2. A peer joins (launch)').replace('3. Play into it (run)','3. Play into it (launch)');record(p,b,a)
folder=Path('public/docs/assets/rtp_midi_demo')
for box in ['rtpm-session','rtpm-peer','rtpm-play']:
 p=folder/(box+'_code_.kt');b=p.read_text();a=replacements.get(box,b)
 # Include the unchanged session in mechanical coverage and canonical consistency proof.
 p.write_text(a);rows.append({'path':str(p),'before':b,'after':a})
p=folder/'README.md';s=p.read_text().replace('and run the boxes\nin order.','and run box 1, then launch boxes 2 and 3\nin order.').replace('| run |','| launch |');p.write_text(s)
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(H.parent/'box_code_adoption_batch_41'/name).read_text().replace('adoption-41','adoption-42').replace('25e96457c','6147d3463');(H/name).write_text(s)
p=Path('dev_docs/agents/box_code_second_pass/checkpoint.json');d=json.loads(p.read_text());d['inProgress']={'batch':42,'branch':'codex/box-code-readability-42','baseline':'6147d3463','state':'DMX nested socket scopes and receive diagnostics; owned MIDI frame sequences with note release in finally and real connection readiness. Formatting, saved sync and real loopback verification remain.','evidence':'build/box-code-revision/adoption-42'};p.write_text(json.dumps(d,indent=2)+'\n')
