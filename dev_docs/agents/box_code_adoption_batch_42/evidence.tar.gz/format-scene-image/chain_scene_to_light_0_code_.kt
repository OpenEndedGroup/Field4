import afield.io.dmx.*
import afield.lang.rectsl.*

// The scene, drawn on the CPU: 256 x 128 pixels of a 16 x 8 wall, at one second in.
val scene = RectSLImager(SceneOnARig.SCENE)
val frame = scene.frame(1.0, 256, 128)
showImg(frame, channel = "scene")

// A 16 x 8 grid of RGB pixels in universe 1 and four RGBWA washes in universe 2, coloured from
// the frame shrunk to one pixel per fixture.
val rig = SceneOnARig.Rig()
rig.show(frame)

/* BOX_CODE_FOLD_0 */
// Nested scopes close the sender even if receiver construction fails.
val port = 35692
DmxOutput(DmxProtocol.SACN, host = "127.0.0.1", port = port, autoStart = false, discovery = false).use { out ->
    DmxInput(DmxProtocol.SACN, port = port, bindAddress = "127.0.0.1").use { node ->
        rig.patch.render(out)
        out.flush()
        val deadline = System.nanoTime() + 2_000_000_000L
        while ((node.version(1) == 0L || node.version(2) == 0L) && System.nanoTime() < deadline) Thread.sleep(5)
        check(node.version(1) > 0L && node.version(2) > 0L) {
            "Incomplete sACN frame on port $port after 2 seconds: universe 1=${node.version(1)}, universe 2=${node.version(2)}. Check sender address/port."
        }
        showPatch(rig.patch, channel = "sent", w = 540.0, h = 330.0)
        showReceived(rig.patch, node, channel = "received", w = 540.0, h = 330.0)
    }
}/* BOX_CODE_FOLD_1 */
