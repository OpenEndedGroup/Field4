val scene = RectSLImager(source)
val img = scene.frame(1.5, 256, 128) // colours as typed: 0x808080 is 0.502
val light = scene.frame(1.5, 256, 128, linear = true) // the light that stands for: 0.216
