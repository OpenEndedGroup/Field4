import afield.io.dmx.*

val trip = SceneOnARig.roundTrip(port = 35693)
val timing = SceneOnARig.timing(port = 35694, seconds = 3.0)
val floor = SceneOnARig.decodeErrors()

/* BOX_CODE_FOLD_0 */
fun f(v: Double, d: Int = 2) = "%.${d}f".format(v)
markdown(
    "roundtrip",
    """
#### ${trip.frames} frames, ${trip.fixtures} fixtures, two universes, sACN to 127.0.0.1 and back

| | |
|---|---|
| slot bytes compared | ${trip.slotsCompared} |
| slot bytes that changed on the way | **${trip.levelErrors}** |
| worst RGB pixel, asked for vs decoded | ${f(trip.worstGridLevels, 3)} of 255 levels |
| worst RGBWA wash, asked for vs decoded | ${f(trip.worstWashLevels, 3)} of 255 levels |
| packets sent / received | ${trip.packetsSent} / ${trip.packetsReceived} |
| median send-to-merged latency | ${f(trip.medianLatencyMicros / 1000.0, 2)} ms |

#### ${f(timing.seconds, 0)} s animated on the sender's clock

| | median | 95th percentile |
|---|---|---|
| one look: draw 256 × 128, shrink, map (ms) | ${f(timing.frameMedian)} | ${f(timing.frameP95)} |
| gap between universe-1 frames at the receiver (ms) | ${f(timing.arrivalMedian)} | ${f(timing.arrivalP95)} |

${timing.ticks} looks computed; ${timing.arrivalMillis.size + 1} frames of universe 1 received, ${f(timing.receivedHz, 1)} per second.

#### What each profile's slots cost, with no network: 2000 random colours each

| profile | ${floor.keys.joinToString(" | ") { it.name }} |
|---|${floor.keys.joinToString("") { "---|" }}
| worst error, levels | ${floor.values.joinToString(" | ") { f(it, 3) }} |
""",
    width = 1000,
)/* BOX_CODE_FOLD_1 */
