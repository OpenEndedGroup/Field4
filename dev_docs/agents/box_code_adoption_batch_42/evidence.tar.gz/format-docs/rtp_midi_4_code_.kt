markdown(
    midi.peers.joinToString("\n") { p ->
        "- **${p.name}** ${p.state}, round trip ${p.roundTripMs} ms, ${p.received} received"
    },
)
