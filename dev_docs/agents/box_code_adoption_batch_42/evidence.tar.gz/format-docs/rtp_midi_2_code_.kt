frames {
    for (pitch in [60, 64, 67, 72]) {
        midi.noteOn(pitch, 90)
        try {
            delay(150) // Milliseconds; yields to Field while the note sounds.
        } finally {
            midi.noteOff(pitch) // Stop or rerun also releases the current note.
        }
    }
    midi.controlChange(74, 100)
    midi.pitchBend(-2000)
    midi.sysex(byteArrayOf(0x7D, 1, 2, 3)) // The F0 ... F7 framing is added.
}
