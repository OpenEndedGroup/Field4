val cutoff = 200.0 + 8000.0 * midi.knob(74) // 0..1, 0 until the knob first moves
val held = midi.held.keys.map { (_, pitch) -> pitch }
