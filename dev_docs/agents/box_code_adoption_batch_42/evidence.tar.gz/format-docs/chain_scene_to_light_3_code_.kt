import afield.io.dmx.*
import afield.lang.rectsl.*

val (point, area) = SceneOnARig.aliasing()

/* BOX_CODE_FOLD_0 */
val times = (0 until point.total.size).map { 0.5 + 3.0 * it / (point.total.size - 1.0) }
showSignals(
    "point samples of the 256 × 128 frame" to point.total.toList(),
    "area average to 16 × 8 first" to area.total.toList(),
    x = times,
    channel = "light on the rig",
    // No third trace for the truth: it is 2.0, exactly under the area-averaged route.
    title = "Light on the grid; the line is worth ${SceneOnARig.LINE_TRUTH}",
    xTitle = "seconds",
    yTitle = "fully lit fixtures",
)

// The first instant at which the point-sampled rig is dark.
val k = point.peak.indexOfFirst { it < 0.01 }.coerceAtLeast(0)
val frame = RectSLImager(SceneOnARig.LINE).frame(times[k], 256, 128, linear = true)
val rig = SceneOnARig.Rig()
rig.show(frame, area = false)
showPatch(rig.patch, channel = "point samples at t = ${"%.3f".format(times[k])} s", w = 540.0, h = 300.0)
rig.show(frame, area = true)
showPatch(rig.patch, channel = "area average at t = ${"%.3f".format(times[k])} s", w = 540.0, h = 300.0)

markdown(
    "counts",
    """
| route | frames with the rig dark | light on the rig, min – max | mean over the sweep | (max − min) / mean |
|---|---|---|---|---|
| point samples | ${point.darkFrames} of ${point.total.size} | ${"%.2f".format(point.min)} – ${"%.2f".format(point.max)} | ${"%.3f".format(point.mean)} | ${"%.2f".format(point.flicker)} |
| area average | ${area.darkFrames} of ${area.total.size} | ${"%.3f".format(area.min)} – ${"%.3f".format(area.max)} | ${"%.3f".format(area.mean)} | ${"%.4f".format(area.flicker)} |
""",
    width = 1000,
)/* BOX_CODE_FOLD_1 */
