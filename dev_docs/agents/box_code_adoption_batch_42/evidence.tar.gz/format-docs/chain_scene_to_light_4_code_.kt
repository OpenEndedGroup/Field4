patch.mapImage(frame.resize(16, 8)) // one pixel per fixture, each the mean of its cell
