for (s in rtpMidiDiscover()) markdown("- **${s.instance}** at `${s.address}:${s.port}`")
