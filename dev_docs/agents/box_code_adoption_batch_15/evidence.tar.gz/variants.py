import importlib.util,sys,asyncio,yaml
from pathlib import Path
R=Path.cwd();sys.path.insert(0,str(R/'dev_docs/agents/box_code_adoption_batch_3'))
s=importlib.util.spec_from_file_location('variants15',R/'dev_docs/agents/box_code_adoption_batch_3/rehearse.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.PORT=9700;m.ROOT=R;m.OUT=R/'build/box-code-revision/adoption-15/runtime';m.OUT.mkdir(parents=True,exist_ok=True)
ops=yaml.safe_load((R/'dev_docs/agents/transcripts/polytope_conway_gallery.yaml').read_text())['operations'];code=next(o['create']['properties']['code'] for o in ops if o.get('create',{}).get('box')=='polytope_parameter_field')
async def main():
 for name,a,b,check in [('empty','"band" to (y < 0.62)','"band" to false','check(deployed.isEmpty())'),('constant','"spike" to (0.10 + 0.80 * (x + 1.0) / 2.0)','"spike" to 0.4','check(deployed.isNotEmpty() && deployed.all { it == 0.4 })')]:
  assert a in code,name
  v=code.replace(a,b)+'\n'+check+'\ncheck(faceLines.all { f -> [f.color.x,f.color.y,f.color.z,f.color.w].all { it.isFinite() } })\nprintln("variant passed")'
  await m.program(name,v)
asyncio.run(main())
