from pathlib import Path
import importlib.util,json,re
H=Path('dev_docs/agents/box_code_adoption_batch_33');rows=[]
def edit(path,ids,change):
 p=Path(path);before=p.read_text();after=change(before);assert before!=after,path;p.write_text(after);rows.append({'path':path,'findings':ids,'before':before,'after':after})
def transcript(s):
 a=s.index('          // A property is saved');b=s.index('          val rings = sourceFramesStudy',a)
 s=s[:a]+'''          // sourceFramesStudy saves the source property. Keep a person's edited text on rerun.
          prop<String>(rings)
          once.rings { "7 rings 0.05 ink 0.8 warmth" }
          prop<SourceFramesStudy>(ringsStudy)

'''+s[b:]
 s=s.replace('val rings = sourceFramesStudy','ringsStudy = sourceFramesStudy')
 s=re.sub(r'          val rings = fromContextWithNameOrNull<SourceFramesStudy>\("rings"\)!!\n','',s)
 s=s.replace('rings.', 'ringsStudy.').replace('once.ringsStudy {','once.rings {')
 s=s.replace('registerStudyTools("Rings", rings,','registerStudyTools("Rings", ringsStudy,')
 s=s.replace('child, finds the study with fromContextWithNameOrNull,','child, inherits the typed study handle,')
 return s
edit('dev_docs/agents/transcripts/studies_rings.yaml',['a3a5be415f98-01'],transcript)
spec=importlib.util.spec_from_file_location('sections33',H.parent/'box_code_adoption_batch_7/format_docs.py');docs=importlib.util.module_from_spec(spec);spec.loader.exec_module(docs)
def study_code(c):
 c=c.replace('thisBox.setPropertyRaw("rings", "7 rings 0.05 ink 0.8 warmth")','prop<String>(rings)\nrings = "7 rings 0.05 ink 0.8 warmth"')
 if 'sourceFramesStudy("rings"' in c:
  c=c.replace('val rings = sourceFramesStudy','val ringsStudy = sourceFramesStudy').replace('rings.','ringsStudy.').replace('registerStudyTools("Rings", rings,','registerStudyTools("Rings", ringsStudy,')
  c=c.replace('thisBox.getPropertyRaw("rings", "")','rings')
 c=c.replace('thisBox.setPropertyRaw("loot", "L1 12, L3 41, L7 30")','prop<String>(loot)\nloot = "L1 12, L3 41, L7 30"').replace('thisBox.getPropertyRaw("loot", "").toString()','loot')
 c=c.replace('thisBox.setPropertyRaw("plan", "four rooms, two doors")','prop<String>(plan)\nplan = "four rooms, two doors"').replace('thisBox.getPropertyRaw("plan", "").toString()','plan')
 if 'thisBox.getPropertyRaw("rooms", "2")' in c:
  c='prop<String>(rooms, "2")\n\n'+c
  c=c.replace('thisBox.getPropertyRaw("rooms", "2").toString()','rooms').replace('(2..6).map { rooms ->','(2..6).map { roomCount ->').replace('thisBox.setPropertyRaw("rooms", "$rooms")','rooms = "$roomCount"')
 return c
def studies(s):
 edits=[]
 for a,b in docs.sections(s):
  v=study_code(s[a:b])
  if v!=s[a:b]:edits.append((a,b,v))
 for a,b,v in reversed(edits):s=s[:a]+v+s[b:]
 return s
edit('public/docs/studies.md',['f9f433271058-01'],studies)
edit('public/docs/kits.md',['d05cb6b8df0f-01'],lambda s:s.replace('prop<String?>(roomRules)\nval rules = (roomRules ?: "").lines()', 'prop<String>(roomRules, "")\nval rules = roomRules.lines()'))
(H/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(H.parent/'box_code_adoption_batch_26'/name).read_text().replace('adoption-26','adoption-33').replace("'dcc0dd98f'","'ac1bd079c'")
 (H/name).write_text(s)
# Remove formatting noise from previously added rehearsal harnesses.
for p in [H.parent/'box_code_adoption_batch_29/mechanical.py',H.parent/'box_code_adoption_batch_32/rehearse.py']:
 p.write_text('\n'.join(line.rstrip() for line in p.read_text().splitlines()).rstrip()+'\n')
