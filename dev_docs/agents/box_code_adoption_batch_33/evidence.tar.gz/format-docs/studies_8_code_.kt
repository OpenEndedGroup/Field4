val builds = studyBuilds(
    "search",
    [
        StudyBuildStage("route", "Search for routes", "route-v1", setOf("rooms")) { c ->
            val budget = (c.request["budgetSeconds"] as? Number)?.toInt() ?: 10
            c.progress(0.5, "Searching for $budget s")
            c.file("route.txt").writeText("${c.inputs.getValue("rooms")} rooms searched for $budget s")
            StudyBuildProduct(["route.txt"], mapOf("budgetSeconds" to budget))
        },
    ],
) {
        mapOf("rooms" to "6")
    }

builds.start("route", builds.stages().single().fingerprint!!, mapOf("budgetSeconds" to 60))
showStudyBuilds("search")
