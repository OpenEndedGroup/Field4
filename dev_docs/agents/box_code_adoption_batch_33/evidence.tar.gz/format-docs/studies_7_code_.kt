// Each loot point, and how many steps it is from the spawn.
prop<String>(loot)
loot = "L1 12, L3 41, L7 30"

val reachable =
    StudyBuildGate("reachable loot", dependencies = ["paths"]) { evidence ->
        val far = evidence.facts("paths")["outOfReach"] as List<*>
        if (far.isEmpty()) null else "Out of reach (more than 30 steps): ${far.joinToString()}."
    }
val builds = studyBuilds(
    "loot",
    [
        StudyBuildStage("paths", "Measure paths", "paths-v1", setOf("loot")) { c ->
            val steps = c.inputs.getValue("loot").split(", ").associate {
                it.substringBefore(' ') to it.substringAfter(' ').toInt()
            }
            c.file("steps.txt").writeText(steps.toString())
            StudyBuildProduct(["steps.txt"], mapOf("outOfReach" to steps.filterValues { it > 30 }.keys.toList()))
        },
        StudyBuildStage("place", "Place loot", "place-v1", setOf("reachable loot"), ["paths"]) { c ->
            c.file("placed.txt").writeText("loot placed along " + c.dependencyFile("paths", "steps.txt").readText())
            StudyBuildProduct(["placed.txt"])
        },
    ],
    gates = [reachable],
) {
        mapOf("loot" to loot)
    }

builds.await(builds.start("paths", builds.stages().first { it.id == "paths" }.fingerprint!!).id)
showStudyBuilds("loot")
