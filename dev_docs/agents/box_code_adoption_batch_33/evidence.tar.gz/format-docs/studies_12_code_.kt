prop<String>(rooms, "2")

val builds = studyBuilds(
    "walls",
    [
        StudyBuildStage("mesh", "Mesh the walls", "mesh-v1", setOf("rooms")) { c ->
            c.file("walls.obj").writeText("v 0 0 0\n".repeat(20_000 * c.inputs.getValue("rooms").toInt()))
            StudyBuildProduct(["walls.obj"])
        },
    ],
) {
        mapOf("rooms" to rooms)
    }

// Five versions of the level, each built once.
val built =
    (2..6).map { roomCount ->
        rooms = "$roomCount"
        builds.await(builds.start("mesh", builds.stages().single().fingerprint!!).id)
    }
val preview = builds.prune(pins = setOf(built.first().id), dryRun = true)
val pruned = builds.prune(pins = setOf(built.first().id))
markdown(
    "main",
    "A dry run would delete ${preview.deleted.size} attempts. Pruning deleted ${pruned.deleted.size} " +
        "and freed ${pruned.freedBytes / 1000} kB, keeping ${pruned.kept.size}: the current walls and the pinned first version.",
)
