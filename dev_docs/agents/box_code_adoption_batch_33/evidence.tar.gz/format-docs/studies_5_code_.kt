resultNotes = { result ->
    val count = (result.facts["unresolved"] as? Number)?.toInt() ?: 0
    if (count > 0) [StudyBuildNotice("$count findings remain. Inspect the retained report.")] else emptyList()
}
