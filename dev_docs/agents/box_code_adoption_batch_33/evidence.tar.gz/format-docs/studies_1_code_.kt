prop<String>(rings)
rings = "7 rings 0.05 ink 0.8 warmth"

val ringsStudy = sourceFramesStudy(
    "rings",
    studyFrames("rings, drawn on the CPU") { source: String, w: Int, h: Int, t: Double ->
        val (count, ink, warmth) = StudyKnobs.plainNumbers(source).map { it.value.toFloat() }
        val px = FloatArray(w * h * 4)
        for (y in 0 until h) for (x in 0 until w) {
            val d = Math.hypot(x + 0.5 - w / 2.0, y + 0.5 - h / 2.0) / w
            val v = (0.5 + 0.5 * Math.cos(d * count * 12.0 - t * 2.0)).toFloat()
            val i = (y * w + x) * 4
            px[i] = v * warmth + ink * (1 - v)
            px[i + 1] = v * 0.5f + ink * (1 - v)
            px[i + 2] = v * (1 - warmth) + ink * (1 - v)
            px[i + 3] = 1f
        }
        afield.lang.stacksl.cpu.CpuRaster(w, h, px)
    },
)

val first = ringsStudy.edit(
    StudyCall.Edit(
        "empty",
        ringsStudy.inspect(StudyCall.Inspect()).facts["liveSourceHash"] as String,
        "7 rings 0.05 ink 0.8 warmth",
        "seven warm rings",
    ),
)
val hash = ringsStudy.inspect(StudyCall.Inspect()).facts["liveSourceHash"] as String

val cooler =
    ringsStudy.setNumbers(StudyCall.SetNumbers(first.revision, hash, [StudyCall.Number(2, 0.2)], "cooler rings"))
val late = runCatching {
    ringsStudy.edit(StudyCall.Edit(first.revision, hash, "3 rings 0.5 ink 0.5 warmth", "an edit from a stale read"))
}
val kept = ringsStudy.compare(StudyCall.Compare(first.revision, cooler.revision, mode = "luma"))

markdown(
    "main",
    "The box holds `${rings}`. The stale edit: ${late.exceptionOrNull()?.message} " +
        "Luma preserved: ${kept.facts["preservedOutsideRegion"]}.\n\n" +
        cooler.h,
)
