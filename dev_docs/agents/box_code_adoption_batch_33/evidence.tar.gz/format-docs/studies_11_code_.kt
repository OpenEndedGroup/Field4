import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

val script = "%document/relax.py".file
script.writeText(
    """
import json, time
for n in range(1, 5):
    json.dump({"fraction": n / 4, "message": f"pass {n} of 4"}, open("progress.json", "w"))
    time.sleep(3)
open("relaxed.txt", "w").write("relaxed in 4 passes")
"""
        .trimStart(),
)

val builds = studyBuilds(
    "external",
    [
        StudyBuildStage("relax", "Relax in Python", "relax-" + fileIdentity(script), setOf("route")) { c ->
            c.runProcess(
                ["python3", script.path],
                progressFile = "progress.json",
                stall = 30.seconds,
                deadline = 10.minutes,
            )
            StudyBuildProduct(["relaxed.txt", "process.log"])
        },
    ],
) {
        mapOf("route" to "spawn to L7")
    }

builds.start("relax", builds.stages().single().fingerprint!!)
showStudyBuilds("external")
