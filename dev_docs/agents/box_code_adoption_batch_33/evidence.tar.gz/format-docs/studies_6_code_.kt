throw StudyBuildFailure(
    StudyBuildProblem(
        "stair-clash",
        "Wall W3 crosses the stair opening",
        ["Move the stair or shorten W3"],
        details = mapOf("geometryView" to mapOf("box" to thisBox.id, "caption" to "W3 and the stair opening")),
    ),
)
