val builds = studyBuilds(
    "reports",
    [
        StudyBuildStage("summary", "Source report", "report-v1", setOf("source")) { context ->
            val source = context.inputs.getValue("source")
            context.progress(0.5, "Writing the report")
            context.file("summary.txt").writeText("${source.lines().size} source lines")
            StudyBuildProduct(["summary.txt"])
        },
    ],
) {
        mapOf("source" to design.liveSource())
    }
showStudyBuilds("reports")
