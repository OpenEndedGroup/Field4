val lookOnly = object : LiveStudy {
    override fun inspect(q: StudyRequest.Inspect) =
        StudyReport("current", mapOf("source" to "nothing to edit here"))
}
val tools = registerStudyTools("Look", lookOnly, verbs = setOf(StudyVerb.INSPECT, StudyVerb.OBSERVE))

val read = lookOnly.inspect(StudyCall.Inspect())
val look = runCatching { lookOnly.observe(StudyCall.Observe(seconds = [0.0])) }

markdown(
    "main",
    "Tools: ${tools.values.joinToString { "`${it.name}`" }}. Inspect: ${read.facts}. " +
        "Observe: ${look.exceptionOrNull()?.message}.",
)
