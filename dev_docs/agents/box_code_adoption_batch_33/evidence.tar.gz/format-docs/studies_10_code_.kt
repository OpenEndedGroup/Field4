val builds = studyBuilds(
    "relax",
    [
        StudyBuildStage("relax", "Relax the route", "relax-v1", setOf("route")) { c ->
            (c.request["resume"] as? String)?.let { c.resumeFrom(it, ["checkpoint.txt"]) }
            val checkpoint = c.file("checkpoint.txt")
            val passes = (if (checkpoint.isFile) checkpoint.readText().toInt() else 0) + 100
            checkpoint.writeText("$passes")
            StudyBuildProduct(["checkpoint.txt"], mapOf("passes" to passes))
        },
    ],
) {
        mapOf("route" to "spawn to L7")
    }

val fingerprint = builds.stages().single().fingerprint!!
val first = builds.await(builds.start("relax", fingerprint).id)
builds.await(builds.start("relax", fingerprint, mapOf("resume" to first.id)).id)
showStudyBuilds("relax")
