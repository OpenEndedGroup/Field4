prop<String>(plan)
plan = "four rooms, two doors"

val level = studyBuilds(
    "level",
    [
        StudyBuildStage("blockout", "Block out walls", "blockout-v1", setOf("plan")) { c ->
            c.file("walls.txt").writeText("walls for " + c.inputs.getValue("plan"))
            StudyBuildProduct(["walls.txt"])
        },
    ],
) {
        mapOf("plan" to plan)
    }

val loot = studyBuilds(
    "loot",
    [
        StudyBuildStage("place", "Place loot", "place-v1", dependencies = [dependsOn("level", "blockout")]) { c ->
            val walls = c.dependencyFile(dependsOn("level", "blockout"), "walls.txt").readText()
            c.file("loot.txt").writeText("loot placed inside $walls")
            StudyBuildProduct(["loot.txt"])
        },
    ],
) {
        emptyMap()
    }

level.await(level.start("blockout", level.stages().single().fingerprint!!).id)
showStudyBuilds("loot")
