prop<String>(rings)
rings = "7 rings 0.05 ink 0.8 warmth"

val ringsStudy = sourceFramesStudy(
    "rings",
    studyFrames("rings, drawn on the CPU") { source: String, w: Int, h: Int, t: Double ->
        val (count, ink, warmth) = StudyKnobs.plainNumbers(source).map { it.value.toFloat() }
        val px = FloatArray(w * h * 4)
        for (y in 0 until h) for (x in 0 until w) {
            val d = Math.hypot(x + 0.5 - w / 2.0, y + 0.5 - h / 2.0) / w
            val v = (0.5 + 0.5 * Math.cos(d * count * 12.0 - t * 2.0)).toFloat()
            val i = (y * w + x) * 4
            px[i] = v * warmth + ink * (1 - v)
            px[i + 1] = v * 0.5f + ink * (1 - v)
            px[i + 2] = v * (1 - warmth) + ink * (1 - v)
            px[i + 3] = 1f
        }
        afield.lang.stacksl.cpu.CpuRaster(w, h, px)
    },
)

val first = ringsStudy.edit(
    StudyCall.Edit(
        "empty",
        ringsStudy.inspect(StudyCall.Inspect()).facts["liveSourceHash"] as String,
        "7 rings 0.05 ink 0.8 warmth",
        "seven warm rings",
    ),
)

val swept = ringsStudy.sweep(StudyCall.Sweep(knob = 0, values = [3.0, 5.0, 7.0, 11.0, 15.0]))
val tried = ringsStudy.tryVariants(
    StudyCall.TryVariants(
        [
            StudyCall.Variant("tight", source = "15 rings 0.05 ink 0.8 warmth", note = "twice the rings"),
            StudyCall.Variant("cold", edits = [StudySourceEdit("0.8 warmth", "0.1 warmth")]),
            StudyCall.Variant("short", source = "7 rings"),
        ],
    ),
)

val now = ringsStudy.inspect(StudyCall.Inspect())
val adopted = ringsStudy.adoptVariant(StudyCall.Adopt(now.revision, now.facts["liveSourceHash"] as String, "cold"))

markdown(
    "main",
    (tried.facts["variants"] as List<*>).joinToString("\n") { "- $it" } +
        "\n\nAdopted `${adopted.revision}`; the box holds `${rings}`.\n\n" +
        swept.h +
        "\n\n" +
        tried.h,
)
