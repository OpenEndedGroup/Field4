import afield.geometry.mesh.tetgen.*
import afield.geometry.solid.manifold.*

val part = Solid.cube(80.0, 40.0, 15.0) + Solid.cube(15.0, 40.0, 70.0) // an L, 30 triangles
val mesh = Tetgen.tetrahedralize(part.toTriMesh(), targetEdgeLength = 5.0)

mesh.nodeCount // 2287
mesh.cellCount // 10093
mesh.volume() // 81000.00000000007, against Manifold's exact 81000.0
