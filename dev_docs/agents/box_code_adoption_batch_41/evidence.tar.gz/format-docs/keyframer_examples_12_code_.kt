val scope = KeyframeScope()
val key = scope.Key(
    mutableMapOf<String, Any?>(
        "gain" to 0.65f, // a Float, and the 'f' suffix matters
        "steps" to 12,
        "seed" to 99L,
        "pos" to Vector3f(1.5f, 0f, -2.25f),
        "spin" to Quaternionf().setAngleAxis(0.7f, 0f, 1f, 0f),
        "voice" to stackSLString("sin 220 * fold"),
        // A source block whose body mentions a '$'. Emitting this as a Kotlin *raw* string would
        // have let the '$' interpolate at paste time; it now falls back to an escaped literal.
        "block" to SourceBackedBlock<Any?>("box-1", "val total = 2\nprintln(\"sum: \$total\")"),
        "notes" to listOf<String>("unsupported", "on purpose"), // typed: a bare [..] has no element type here
    ),
)

/* BOX_CODE_FOLD_0 */
// A multi-line value goes into a fence at column zero, so it arrives byte for byte.
markdown(
    "code",
    """
    ~~~kotlin
${key.updateCode("look")}
    ~~~
""",
)/* BOX_CODE_FOLD_1 */
