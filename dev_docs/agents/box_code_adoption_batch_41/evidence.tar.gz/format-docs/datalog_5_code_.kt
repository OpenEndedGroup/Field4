fun boxNamed(id: String, name: String, parent: Box?): Box {
    val b = Box(id)
    b.name = name
    if (parent != null) {
        parent.children.add(b)
        b.parents.add(parent)
    }
    return b
}

val root = boxNamed("root", "document", null)
val loader = boxNamed("loader", "loader", root)
val mesh = boxNamed("mesh", "mesh", loader)
val shader = boxNamed("shader", "shader", loader)
val draw = boxNamed("draw", "draw", mesh)
val notes = boxNamed("notes", "notes", root)

val d = Datalog()
d.addBoxGraph(root)
d.add(
    """
    #datalog
    downstream(A, B) :- child(A, B).
    downstream(A, C) :- downstream(A, B), child(B, C).
    leaf(X) :- box(X), !child(X, _).
""",
)

display("main", d.query("downstream(loader, X), name(X, N)"))
display("leaves", d.query("leaf(X), name(X, N)"))
