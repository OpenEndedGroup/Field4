var m = Mesh()
var module = moduleHere()
module += "mainMesh" to m
renderer += module

val camera = afield.graphics.vulkan.util.Camera()

// The same white fan as above — every colour on screen still comes from the tint alone.
val N = 48
m.set(3 * N, 1 * N) {
    N {
        val a0 = it / N.toDouble() * Math.PI * 2.0
        val a1 = (it + 0.62) / N.toDouble() * Math.PI * 2.0
        pos.add(
            0.0,
            0.0,
            0.0,
            2.4 * kotlin.math.cos(a0),
            2.4 * kotlin.math.sin(a0),
            0.0,
            2.4 * kotlin.math.cos(a1),
            2.4 * kotlin.math.sin(a1),
            0.0,
        )
        3 { col.add(1, 1, 1, 1) }
        tri.add(0 + 3 * it, 1 + 3 * it, 2 + 3 * it)
    }
}

val scope = KeyframeScope()
scope.camera(camera) // a CameraPose target — sclerped, not lerped
scope.target("tint", module.look) // the uniform block's live Structure

/*
Two endpoints. The camera swings about 60 degrees around the fan and lifts, while the tint goes cool to
warm. Poses are read off the camera rather than constructed, so this is exactly what capture()
would have stored. Tint is a literal here rather than a captured value, since there is nothing
to capture from yet — the uniform is untouched until the first key lands on it.
*/
camera.at = vec(0, 0, 3.5)
camera.target = vec(0, 0, 0)
val poseCool = camera.pose()
camera.at = vec(-3.03, 1.0, 1.75)
camera.target = vec(0, 0, 0)
val poseWarm = camera.pose()

val cool = scope.Key(mutableMapOf("camera" to poseCool, "tint" to vec(0.20, 0.65, 1.00, 1.0)))
val warm = scope.Key(mutableMapOf("camera" to poseWarm, "tint" to vec(1.00, 0.50, 0.12, 1.0)))

val t = 0.0
scope.interpolate(cool, warm, t)()

// Applying the key moved the Camera object; the projection uniforms are read off it afterwards.
module.look.p = camera.p()
module.look.m = camera.m()
