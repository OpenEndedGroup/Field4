var gain = 0.35f
var projectedOnly = false
val keys = KeyframeScope()

thisBox.controlGroup("projected light") {
    keyframeFloatSlider(
        scope = keys,
        name = "light.gain",
        label = "gain",
        min = 0.0,
        max = 4.0,
        get = { gain },
        set = { gain = it },
    )
    keyframeCheckbox(
        scope = keys,
        name = "light.projectedOnly",
        label = "projected only",
        get = { projectedOnly },
        set = { projectedOnly = it },
    )
}
