val linear = Tetgen.tetrahedralize(surface, targetEdgeLength = 5.0)
val quadratic = Tetgen.tetrahedralize(surface, targetEdgeLength = 5.0, order = 2)

// equivalently, from a mesh already in hand: linear.quadratic()

linear.nodeCount // 8279
quadratic.nodeCount // 57495 — 6.94x, one new node per distinct edge
quadratic.cellCount // 36475, the same tetrahedra
quadratic.nodesPerCell // 10
quadratic.volume() // 76958.90896392865 — linear.volume() to the last bit
quadratic.corners() // the 4-node view back, sharing the same node array
