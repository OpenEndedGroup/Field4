val d = Datalog()
d.add(
    """
    #datalog
    edge(a, b). edge(b, c). edge(c, d). edge(d, b).
    path(X, Y) :- edge(X, Y).
    path(X, Z) :- path(X, Y), edge(Y, Z).
""",
)

display("main", d.why("path(a, d)"))
