class Look : KeyframeContributor {
    var opacity = 1f
    var position = vec(0, 0, 0)

    override fun registerKeyframes(scope: KeyframeScope, prefix: String) = with(scope) {
        floatTarget("$prefix.opacity", { opacity }) { opacity = it }
        vector3Target("$prefix.position", { position }) { position = it }
    }
}

val keys = KeyframeScope(schemaVersion = 2).include(Look(), prefix = "foreground")
