import java.nio.file.Files

// A fresh private parent keeps this lesson's four keys separate from other boxes and checkouts.
// The leaf name stays readable in the browser header.
val dir = Files.createTempDirectory("keyframer-docs-").resolve("glow-looks")
Files.createDirectories(dir)

// One pass with three uniforms, and a scope that watches them.
val glow = Structure()
val scope = KeyframeScope()
scope.target("glow@radius", glow)
scope.target("glow@intensity", glow)
scope.target("glow@falloff", glow)

// Four looks, each saved as its own key with a note.
[
        Triple("soft", [3f, 0.20f, 1.5f], "first pass"),
        Triple("hot", [9f, 0.80f, 0.6f], "too much"),
        Triple("mid", [6f, 0.50f, 1.0f], "between the two"),
        Triple("wide", [12f, 0.35f, 2.2f], "for the long shot"),
    ]
    .forEach { (name, v, note) ->
        glow.bind("radius") { v[0] }
        glow.bind("intensity") { v[1] }
        glow.bind("falloff") { v[2] }
        scope.capture().save(dir.resolve(name), note)
    }

keyframeBrowser(dir, scope = scope, height = 330)
