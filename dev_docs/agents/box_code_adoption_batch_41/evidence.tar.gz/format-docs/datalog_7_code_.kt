val links = [0 to 1, 1 to 2, 2 to 3, 3 to 4, 4 to 0, 1 to 5, 5 to 6, 6 to 2]

val d = Datalog()
d.facts("edge", links.map { [it.first, it.second] })
d.add(
    """
    #datalog
    path(X, Y) :- edge(X, Y).
    path(X, Z) :- path(X, Y), edge(Y, Z).
    implied(X, Y) :- path(X, Y), !edge(X, Y), X != Y.
""",
)

val n = 7
fun at(i: Int): Vec2 {
    val a = i * 2.0 * PI / n - PI / 2
    return vec(340.0 + 300.0 * cos(a), 170.0 + 135.0 * sin(a))
}
fun link(a: Int, b: Int, c: Vec4, t: Double) = fline {
    val p = at(a)
    val q = at(b)
    moveTo(p.x, p.y)
    lineTo(q.x, q.y)
    color = c
    thickness = t
}
fun dot(i: Int) = fline {
    val p = at(i)
    val r = 5.0
    moveTo(p.x - r, p.y)
    lineTo(p.x, p.y - r)
    lineTo(p.x + r, p.y)
    lineTo(p.x, p.y + r)
    close()
    filled = true
    color = vec(0.98, 0.86, 0.30, 1.0)
}
// Node numbers, set just outside the ring so an edge never runs through one. Glyphs move with
// FLine.transform, which carries the cubic handles; nudging a node's point alone smears the letter.
fun label(i: Int): List<FLine> {
    val a = i * 2.0 * PI / n - PI / 2
    val p = at(i)
    val layout = layoutText("$i", typeface("Monospaced", 22.0))
    val dx = p.x + 26.0 * cos(a) - layout.advanceWidth / 2.0
    val dy = p.y + 26.0 * sin(a) + 8.0
    return layout.toFLines(color = vec(0.72, 0.78, 0.86, 1.0), thickness = 0.0, filled = true, stroked = false).map {
        line ->
        line.transform { q -> vec(q.x + dx, q.y + dy, q.z) }
    }
}

val implied = d.query("implied(X, Y)").rows.map {
    link((it[0] as Long).toInt(), (it[1] as Long).toInt(), vec(0.45, 0.70, 0.98, 0.20), 1.0)
}
val direct = links.map { link(it.first, it.second, vec(0.98, 0.86, 0.30, 1.0), 2.0) }

println("${links.size} stated edges, ${implied.size} implied by them")
val labels = (0 until n).flatMap { label(it) }
lines(implied + direct + (0 until n).map { dot(it) } + labels, w = 700.0, h = 350.0, fitToSize = true)
