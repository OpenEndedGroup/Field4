import afield.geometry.mesh.tetgen.*
import afield.geometry.solid.manifold.*

// The same bracket as the figure above, built in the same order — which matters more than it
// looks like it should. See "the same solid, built in a different order" under Sizing.
val part = Solid.scope {
    val foot = Solid.cube(80.0, 40.0, 15.0)
    val post = Solid.cube(15.0, 40.0, 70.0)
    val bolts = [12.0, 28.0].map {
        Solid.cylinder(40.0, 5.0, segments = 48).translated(55.0, it, -5.0)
    }
    val eye = Solid.cylinder(60.0, 6.0, segments = 48).rotated(0.0, 90.0, 0.0).translated(-20.0, 20.0, 52.0)
    ((foot + post) - Solid.union(bolts + eye)).copy()
}
val surface = part.toTriMesh()
val mesh = Tetgen.tetrahedralize(surface, targetEdgeLength = 3.0)
val quality = mesh.qualities()
val radiusEdge = mesh.radiusEdgeRatios()

// Where the worst elements are. Not "how many" — where. On a body built from Booleans the answer
// is almost always "against a feature the surface itself put there".
val worst = quality.indices.sortedBy { quality[it] }.take(400).toHashSet()
val slivers = mesh.filtered { it in worst }
/* BOX_CODE_FOLD_0 */
val sorted = quality.sorted()
println("${mesh.cellCount} elements at targetEdgeLength = 3.0")
println(
    "radius ratio     min ${"%.4f".format(sorted.first())}  " +
        "1st pct ${"%.4f".format(sorted[sorted.size / 100])}  " +
        "median ${"%.4f".format(sorted[sorted.size / 2])}  max ${"%.4f".format(sorted.last())}",
)
println("below 0.05       ${sorted.count { it < 0.05 }}   (slivers)")
println("below 0.10       ${sorted.count { it < 0.10 }}")
println()
println(
    "radius-edge      min ${"%.4f".format(radiusEdge.min())}  " +
        "(the regular tetrahedron's floor is ${"%.4f".format(Math.sqrt(6.0) / 4.0)})",
)
println(
    "                 max ${"%.4f".format(radiusEdge.max())}, " +
        "${radiusEdge.count { it > 1.2 }} above the 1.2 bound that was asked for",
)
println()
// The point of printing these together: the two measures do not rank the same elements. The worst
// element by radius-edge is a perfectly usable one, and most of the bad ones are inside the bound.
println(
    "worst by radius-edge: ${"%.4f".format(radiusEdge.max())}, whose radius ratio is " +
        "${"%.4f".format(quality[radiusEdge.indices.maxBy { radiusEdge[it] }])} — a fine element",
)
val inBound = quality.indices.filter { radiusEdge[it] <= 1.2 }
println(
    "of the ${inBound.size} elements inside the bound, ${inBound.count { quality[it] < 0.10 }} " +
        "are below radius ratio 0.10; the worst is ${"%.5f".format(inBound.minOf { quality[it] })}",
)

showChart(
    Chart(
            title = "radius ratio over ${mesh.cellCount} elements",
            xLabel = "3 r_in / r_circ",
            yLabel = "elements",
        )
        .histogram("elements", quality.toList(), bins = 40),
)
showMesh(
    slivers.boundary(),
    title = "the 400 worst elements, in place",
    caption =
        "radius ratio ${"%.4f".format(sorted.first())} to ${"%.4f".format(sorted[399])} · " +
            "densest around the three bores, and scattered everywhere else",
    view = MeshView(yawDegrees = 34.0, pitchDegrees = 22.0, width = 760, height = 420),
)
part.close()
