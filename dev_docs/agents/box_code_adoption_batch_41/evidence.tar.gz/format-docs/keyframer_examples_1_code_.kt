var opacity = 0.25f
var layers = 3

val scope = KeyframeScope().apply {
    floatTarget("outlines.opacity", { opacity }) { opacity = it }
    intTarget("outlines.layers", { layers }, 0..64) { layers = it }
}
