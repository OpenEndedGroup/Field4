import afield.geometry.mesh.tetgen.*
import afield.geometry.solid.manifold.*

// The exact distance to the surface of a 2 x 3 x 4 box centred on the origin, and to a sphere.
// One has edges, the other does not; that is the whole experiment.
fun boxDistance(x: Double, y: Double, z: Double): Double {
    val dx = abs(x) - 1.0
    val dy = abs(y) - 1.5
    val dz = abs(z) - 2.0
    val out = sqrt(max(dx, 0.0) * max(dx, 0.0) + max(dy, 0.0) * max(dy, 0.0) + max(dz, 0.0) * max(dz, 0.0))
    return out + min(max(dx, max(dy, dz)), 0.0)
}
fun sphereDistance(x: Double, y: Double, z: Double) = sqrt(x * x + y * y + z * z) - 1.5

val bounds = boundsOf(vec(-1.6, -2.1, -2.6), vec(1.6, 2.1, 2.6))

// How far the worst point of a surface sits from the body it was meant to be. Takes the flat
// coordinate array so the same measurement works on a marched TriMesh and on a TetMesh's nodes.
fun worstError(xyz: DoubleArray, distance: (Double, Double, Double) -> Double): Double {
    var worst = 0.0
    for (v in 0 until xyz.size / 3) {
        worst = max(worst, abs(distance(xyz[3 * v], xyz[3 * v + 1], xyz[3 * v + 2])))
    }
    return worst
}
fun coordinates(m: TriMesh) = DoubleArray(m.positions.size) { m.positions[it].toDouble() }
/* BOX_CODE_FOLD_0 */
val sizes = [0.4, 0.2, 0.1, 0.05]
val boxError = mutableListOf<Double>()
val sphereError = mutableListOf<Double>()
val corners = mutableListOf<Pair<String, List<Vec2>>>()

println("h      box, worst error        sphere, worst error")
for (h in sizes) {
    val b = Solid.levelSet(bounds, h) { x, y, z -> -boxDistance(x, y, z) }
    val s = Solid.levelSet(bounds, h) { x, y, z -> -sphereDistance(x, y, z) }
    boxError += worstError(coordinates(b.toTriMesh()), ::boxDistance)
    sphereError += worstError(coordinates(s.toTriMesh()), ::sphereDistance)
    println(
        "${"%.2f".format(h)}   ${"%.6f".format(boxError.last())} = " +
            "${"%.4f".format(boxError.last() / h)} h    " +
            "${"%.6f".format(sphereError.last())} = ${"%.4f".format(sphereError.last() / h)} h",
    )
    // A real cross section through the marched body, at z = 0. The rounding is 1.5% of the body at
    // h = 0.4: plain in a cross section, invisible in a render of the whole box.
    if (h >= 0.1) corners += "marched, h = $h" to b.slice(0.0).toPolygons().first()
    b.close()
    s.close()
}

// The same box through TetGen, which is handed Manifold's exact triangulation and constrains its
// output to it.
val exactBox = Solid.cube(2.0, 3.0, 4.0, center = true)
val tet = Tetgen.tetrahedralize(exactBox.toTriMesh(), targetEdgeLength = 0.25)
println()
println("TetGen at h = 0.25: ${tet.cellCount} elements, volume ${tet.volume()}")
// Only outward error counts here: an interior node is *supposed* to be inside the box.
println(
    "  worst node outside the true box: " + worstError(tet.positions) { x, y, z -> max(boxDistance(x, y, z), 0.0) },
)

/*
One corner of the true cross section, magnified. The exact outline is what TetGen is given and
what its boundary reproduces; each level set is a different rounded approximation of it.

Pass the complete, explicitly closed contours to Chart; its axes clip the visible segments.
*/
val xLo = 0.82
val xHi = 1.06
val yLo = 1.32
val yHi = 1.56
fun closedCoordinates(loop: List<Vec2>): Pair<List<Double>, List<Double>> {
    val closed = loop.toMutableList()
    if (closed.isNotEmpty()) closed.add(closed.first())
    return closed.map { it.x.toDouble() } to closed.map { it.y.toDouble() }
}
val exactCorner = closedCoordinates(exactBox.slice(0.0).toPolygons().first())
val corner = Chart(
    title = "the corner at (1.0, 1.5), in a 0.24 x 0.24 window",
    xLabel = "x",
    yLabel = "y",
    note = "halving h halves the bite the level set takes out of the corner",
)
corner.width = 780.0
corner.height = 440.0
corner.xDomain = xLo to xHi
corner.yDomain = yLo to yHi
corner.line(
    "exact, and TetGen's",
    exactCorner.first,
    exactCorner.second,
    color = vec(1.0, 0.72, 0.35, 1.0),
    thickness = 3.0,
)
// Coarsest red through finest blue, explicitly. The default palette gives three of these four
// series a warm colour and the figure becomes four orange lines.
val byResolution = [
    vec(0.95, 0.45, 0.45, 1.0),
    vec(0.55, 0.95, 0.55, 1.0),
    vec(0.45, 0.85, 1.0, 1.0),
]
corners.forEachIndexed { i, (label, points) ->
    val contour = closedCoordinates(points)
    corner.line(label, contour.first, contour.second, color = byResolution[i], thickness = 2.0)
}

// And the convergence, which is the actual finding: slope 1 on the box, slope 2 on the sphere.
val rate = Chart(
    title = "worst boundary error against cell size",
    xLabel = "cell size h",
    yLabel = "worst distance from the true surface",
    note = "log-log. The box halves when h halves; the sphere quarters.",
)
rate.width = 780.0
rate.height = 440.0
rate.xKind = ScaleKind.LOG
rate.yKind = ScaleKind.LOG
val blue = vec(0.45, 0.85, 1.0, 1.0)
val green = vec(0.55, 0.95, 0.55, 1.0)
rate
    .line("box — first order", sizes, boxError, color = blue, thickness = 2.4)
    .points("box — first order", sizes, boxError, color = blue, size = 4.5)
rate
    .line("sphere — second order", sizes, sphereError, color = green, thickness = 2.4)
    .points("sphere — second order", sizes, sphereError, color = green, size = 4.5)

// Two channels, not two displays on one: a second display on the same channel replaces the first.
display("output", corner)
display("main", rate)
exactBox.close()
