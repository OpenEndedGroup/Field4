import java.nio.file.Files

val dir = Files.createTempDirectory("keyframer-docs")
val path = dir.resolve("look.json")

val scope = KeyframeScope(schemaVersion = 1)
scope.saveKey(
    path,
    scope.Key(
        mutableMapOf(
            "gain" to 0.20f,
            "pos" to Vector3f(1f, 2f, 3f),
            "voice" to stackSLString("saw 110 *"),
        ),
    ),
    note = "first pass",
)

scope.saveKey(
    path,
    scope.Key(
        mutableMapOf(
            "gain" to 0.65f,
            "pos" to Vector3f(4f, 5f, 6f),
            "voice" to stackSLString("sin 220 * fold"),
        ),
    ),
    note = "brighter",
)

// A third save that also carries values the union cannot represent.
val lossy = scope.Key(
    mutableMapOf(
        "gain" to 0.90f,
        "enabled" to true, // a Boolean is kept
        "taps" to [1, 2, 3], // a list is not
        "absent" to null, // and neither is a null
    ),
)
scope.saveKey(path, lossy, note = "with unsupported values")

val versions = scope.keyVersions(path)
val versionRows =
    versions.joinToString("\n") { v ->
        "| ${v.index} | ${v.file.md} | ${v.note?.md ?: "—"} |"
    }

val reloaded = scope.loadKey(path)
val kept = reloaded.values.keys.sorted().joinToString(", ")
val droppedNames = lossy.values.keys.sorted().filter { it !in reloaded.values.keys }

// An older snapshot loaded into a scope that has since grown a parameter.
val newer = KeyframeScope(schemaVersion = 1)
newer.missingKey("wet", 0.5f) // applies to every file this scope loads
newer.missingKey(1, "mode", "legacy-v1") // only to files stamped schemaVersion = 1
val migrated = newer.loadKey(path, version = 0)

/* BOX_CODE_FOLD_0 */
/*
Rendered as flat text rather than through `migrated.h`. The Key's own HTML gives a Vector3f the
interactive 3D axis widget, which is lovely in a box and wrong here: it loads asynchronously and
reflowed the card mid-screenshot, so the first capture of this figure came out clipped.
*/
val migratedRows =
    migrated.values.entries
        .sortedBy { it.key }
        .joinToString("\n") { (k, v) ->
            "| ${k.md} | ${v.md} |"
        }

// The width is pinned. A `capture="box"` screenshot clips to the output card, and an
// unpinned card sized by its widest unbreakable line loses everything past the clip.
markdown(
    "persist",
    """
    #### version history after three saves

    | # | file | note |
    |---|------|------|
    $versionRows

    #### third save: what survived

    kept: **$kept**

    left out, and logged: {bad:**${droppedNames.joinToString(", ")}**}

    #### version 0, reloaded into a scope that has since grown a 'wet' parameter (${migrated.values.size} values)

    | name | value |
    |------|-------|
    $migratedRows

    #### version 0 on disk, as written
    ~~~json
${java.nio.file.Files.readString(dir.resolve("look.json.versions").resolve("000000.json"))}
    ~~~
""",
    width = 820,
)/* BOX_CODE_FOLD_1 */
