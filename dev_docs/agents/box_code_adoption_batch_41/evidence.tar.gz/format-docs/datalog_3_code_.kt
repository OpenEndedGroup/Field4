data class Take(val clip: String, val shot: String, val seconds: Int, val rating: Int)

val takes = [
    Take("a017", "wide", 42, 5),
    Take("a018", "wide", 38, 2),
    Take("a021", "close", 19, 4),
    Take("a022", "close", 22, 3),
    Take("a030", "insert", 8, 2),
    Take("a031", "insert", 11, 1),
]

val d = Datalog()
d.facts("take", takes) { [it.clip, it.shot, it.seconds, it.rating] }
d.facts("shot", [["wide"], ["close"], ["insert"]])
d.add(
    """
    #datalog
    covered(S) :- take(_, S, _, R), R >= 4.
    reshoot(S) :- shot(S), !covered(S).
    footage(S, Total, Best) :- shot(S),
        Total = sum Sec : { take(_, S, Sec, _) },
        Best  = max R   : { take(_, S, _, R) }.
""",
)

display("main", d.query("footage(S, Total, Best)"))
display("reshoot", d.query("reshoot(S)"))
