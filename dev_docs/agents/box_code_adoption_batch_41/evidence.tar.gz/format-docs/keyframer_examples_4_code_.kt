var m = Mesh()
var module = moduleHere()

module += "mainMesh" to m
renderer += module

/*
Fully qualified, and it has to be: a uniform block makes moduleHere() generate a Kotlin class of the
same (capitalised) name straight into this box's preamble, and a declaration in the box beats
any import. The block here is `look`, so the trap would bite anything called `Look`.
*/
val camera = afield.graphics.vulkan.util.Camera()
camera.at = vec(0, 0, 7)
camera.target = vec(0, 0, 0)

module.look.p = camera.p()
module.look.m = camera.m()

// A fan of WHITE triangles. Every colour in the picture comes from the tint, and nothing else.
val N = 48
m.set(3 * N, 1 * N) {
    N {
        val a0 = it / N.toDouble() * Math.PI * 2.0
        val a1 = (it + 0.62) / N.toDouble() * Math.PI * 2.0
        pos.add(
            0.0,
            0.0,
            0.0,
            2.4 * kotlin.math.cos(a0),
            2.4 * kotlin.math.sin(a0),
            0.0,
            2.4 * kotlin.math.cos(a1),
            2.4 * kotlin.math.sin(a1),
            0.0,
        )
        3 { col.add(1, 1, 1, 1) }
        tri.add(0 + 3 * it, 1 + 3 * it, 2 + 3 * it)
    }
}

/*
---- the keyframe part -------------------------------------------------------------------
`module.look` resolves to the block's live uniform Structure (Module.kt:217), so the ordinary
Structure target drives it. This is the overload to use for a module uniform.
*/
val scope = KeyframeScope()
scope.target("tint", module.look)

val cool = scope.Key(mutableMapOf("tint" to vec(0.20, 0.65, 1.00, 1.0)))
val warm = scope.Key(mutableMapOf("tint" to vec(1.00, 0.50, 0.12, 1.0)))

/*
A quarter of the way from cool to warm — NOT the midpoint. These two are nearly
complementary, so t = 0.5 blends to (0.60, 0.575, 0.56): a grey indistinguishable from an
untinted fan, which would make the picture prove nothing. t = 0.25 is (0.40, 0.6125, 0.78).
*/
scope.interpolate(cool, warm, 0.25)()
