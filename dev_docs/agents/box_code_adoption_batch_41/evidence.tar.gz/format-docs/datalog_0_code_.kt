val d = Datalog()
d.add(
    """
    #datalog
    % which module pulls in which
    imports(app, ui).    imports(app, store).
    imports(ui, util).   imports(store, util).  imports(util, log).

    needs(A, B) :- imports(A, B).
    needs(A, C) :- needs(A, B), imports(B, C).
""",
)

println("app needs " + d.query("needs(app, X)").column("X").joinToString(", "))
println("does app need log? " + d.ask("needs(app, log)"))
println("modules that need log: " + d.query("needs(A, log)").size)
