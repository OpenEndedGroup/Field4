import afield.geometry.mesh.tetgen.*
import afield.geometry.solid.manifold.*

// An L-bracket: two blocks, three bores. Sharp edges from the L, curved surfaces from the bores.
// This part is used for every measurement on this page.
val part = Solid.scope {
    val foot = Solid.cube(80.0, 40.0, 15.0)
    val post = Solid.cube(15.0, 40.0, 70.0)
    val bolts = [12.0, 28.0].map {
        Solid.cylinder(40.0, 5.0, segments = 48).translated(55.0, it, -5.0)
    }
    val eye = Solid.cylinder(60.0, 6.0, segments = 48).rotated(0.0, 90.0, 0.0).translated(-20.0, 20.0, 52.0)
    ((foot + post) - Solid.union(bolts + eye)).copy()
}

val surface = part.toTriMesh()
val mesh = Tetgen.tetrahedralize(surface, targetEdgeLength = 5.0)

/*
The cutaway: keep the elements whose centroid is behind y = 20, then take that half's skin.
The newly exposed cut face is in it, which is what makes the picture read as a slice through a
body rather than as a pile of loose triangles.
*/
val centroid = mesh.centroids()
val half = mesh.filtered { centroid[3 * it + 1] < 20.0 }

// And the same half with every element pulled 22% towards its own centre, coloured by quality.
val quality = half.qualities()
val colors = FloatArray(3 * half.cellCount)
for (t in 0 until half.cellCount) {
    val c = afield.graphics.color.Colormaps.sample("viridis", quality[t])
    colors[3 * t] = c.r.toFloat()
    colors[3 * t + 1] = c.g.toFloat()
    colors[3 * t + 2] = c.b.toFloat()
}
/* BOX_CODE_FOLD_0 */
println("Manifold  ${"%.4f".format(part.volume)} mm³, ${part.triangleCount} triangles, genus ${part.genus}")
// The surface's own digest, printed because the element count below depends on it and on nothing
// else — see "the count moves between sessions" under Sizing.
println(
    "surface   ${surface.vertexCount} vertices, ${surface.triangleCount} triangles, " +
        "digest ${surface.positions.contentHashCode()}/${surface.indices.contentHashCode()}",
)
println("TetGen    $mesh")
println("          volume ${"%.4f".format(mesh.volume())} mm³")
println("          inverted elements ${mesh.volumes().count { it <= 0.0 }}")
println()
println(
    "cutaway   ${half.cellCount} of ${mesh.cellCount} elements, " +
        "${half.boundary().triangleCount} boundary triangles",
)
println(
    "quality   min ${"%.4f".format(quality.min())}, median " + "${"%.4f".format(quality.sorted()[quality.size / 2])}",
)

// Pitch well over the horizon, because the cut plane is horizontal in this frame and a low camera
// shows the skin instead of the slice.
val view = MeshView(yawDegrees = 34.0, pitchDegrees = 58.0, distance = 2.2, width = 380, height = 320)
showMeshGrid(
    "the closed surface TetGen is given · ${surface.triangleCount} triangles" to surface,
    "half the elements, skinned · ${half.cellCount} tetrahedra" to half.boundary(),
    "the same half, elements shrunk to 0.72 · colour is radius ratio, dark is worse" to
        half.toTriMesh(shrink = 0.72, cellColors = colors),
    columns = 3,
    cellWidth = 380,
    view = view,
)
part.close()
