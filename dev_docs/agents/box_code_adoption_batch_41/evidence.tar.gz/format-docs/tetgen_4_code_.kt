import afield.geometry.mesh.tetgen.*

TetgenLibrary.isAvailable // cheap enough to branch on in a box
TetgenLibrary.describe() // "TetGen wrapper at /…/libfield_tetgen_jvm.dylib (TetGen 1.6.0)"
