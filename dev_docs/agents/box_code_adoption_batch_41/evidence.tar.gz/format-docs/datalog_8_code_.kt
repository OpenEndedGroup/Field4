ui.eval(
    "var s=document.createElement('style');s.textContent='.tick_text.ok{display:none !important}';document.head.appendChild(s);return 'setup';",
)
ui.openEditor(id)
ui.pause(700)
// Set the model rather than typing it: the region only exists once its closing triple quote does,
// and a half-typed literal has nothing to highlight.
ui.eval(
    "var q = String.fromCharCode(34).repeat(3);" +
        "var code = ['val d = Datalog()', 'd.add(' + q, '#datalog'," +
        " '% which module pulls in which', 'imports(app, ui).  imports(ui, util).'," +
        " 'needs(A, B) :- imports(A, B).', 'needs(A, C) :- needs(A, B), imports(B, C).'," +
        " 'busy(M, N) :- imports(M, _), N = count : { needs(M, _) }.'," +
        " 'orphan(M) :- imports(_, M), !imports(M, _).', q + ')'," +
        " 'display(' + q.slice(0,1) + 'main' + q.slice(0,1) + ', d.query(' + q.slice(0,1) + 'needs(app, X)' + q.slice(0,1) + '))'].join('\\n');" +
        "window.globalEditor.getModel().setValue(code); return 'set';",
)
ui.pause(1500)
