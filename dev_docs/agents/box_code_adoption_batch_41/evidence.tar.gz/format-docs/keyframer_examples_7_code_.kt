var m = Mesh()
var module = moduleHere()
module += "mainMesh" to m
renderer += module
val camera = afield.graphics.vulkan.util.Camera()
val N = 48
m.set(3 * N, 1 * N) {
    N {
        val a0 = it / N.toDouble() * Math.PI * 2.0
        val a1 = (it + 0.62) / N.toDouble() * Math.PI * 2.0
        pos.add(
            0.0,
            0.0,
            0.0,
            2.4 * kotlin.math.cos(a0),
            2.4 * kotlin.math.sin(a0),
            0.0,
            2.4 * kotlin.math.cos(a1),
            2.4 * kotlin.math.sin(a1),
            0.0,
        )
        3 { col.add(1, 1, 1, 1) }
        tri.add(0 + 3 * it, 1 + 3 * it, 2 + 3 * it)
    }
}
val scope = KeyframeScope()
scope.camera(camera)
scope.target("tint", module.look)
camera.at = vec(0, 0, 3.5)
camera.target = vec(0, 0, 0)
val poseCool = camera.pose()
camera.at = vec(-3.03, 1.0, 1.75)
camera.target = vec(0, 0, 0)
val poseWarm = camera.pose()
val cool = scope.Key(mutableMapOf("camera" to poseCool, "tint" to vec(0.20, 0.65, 1.00, 1.0)))
val warm = scope.Key(mutableMapOf("camera" to poseWarm, "tint" to vec(1.00, 0.50, 0.12, 1.0)))
scope.interpolate(cool, warm, 0.666)()
module.look.p = camera.p()
module.look.m = camera.m()
