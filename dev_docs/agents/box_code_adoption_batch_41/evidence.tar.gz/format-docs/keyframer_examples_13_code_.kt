val warm = "uv 3.0 * fbm 0.15 + [1.0,0.55,0.2] *"
val cool = "uv 8.0 * fbm 0.45 + [0.2,0.5,1.0] *"

val plan = planStackSLCodeBlend(warm, cool, CodeBlendOptions(mode = CodeBlendMode.RUNTIME))
println(
    plan.describe(),
)

/*
 stacksl blend: 3 moving site(s) of 3, 0 divergence(s) — RUNTIME -> RUNTIME
   number: 3.0 -> 8.0
   number: 0.15 -> 0.45
   vector: [1.0,0.55,0.2] -> [0.2,0.5,1.0]
 */
