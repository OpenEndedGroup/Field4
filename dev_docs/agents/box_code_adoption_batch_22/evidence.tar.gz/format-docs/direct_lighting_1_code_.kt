import afield.graphics.scene.fabricated.rtxdiSettings

val settings = study.bundle.rtxdiSettings()
settings.commitLights([IdentifiedAreaLight(42, study.lighting.emitter)])
study.lighting.enableRtxdi(RtxdiProgram.load(), settings).getOrThrow()
study.lighting.mode = DirectLighting.Mode.RTXDI
study.lighting.samples = 16
settings.temporal = true
settings.spatialSamples = 8
settings.denoisePasses = 3 // zero gives the raw estimate
