import afield.graphics.render.lighting.*

val study = DirectLightingDemo(renderer, 1280, 720)
study.lighting.samples = 32
study.lighting.mode = if (study.visibility.available) DirectLighting.Mode.RAY_QUERY else DirectLighting.Mode.UNSHADOWED
frames {
    var t = 0.0
    while (true) {
        study.animate(t)
        t += 1.0 / 60.0
        frame()
    }
}
    .end { study.close() }
