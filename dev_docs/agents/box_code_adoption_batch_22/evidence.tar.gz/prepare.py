from pathlib import Path
import json
h=Path('dev_docs/agents/box_code_adoption_batch_22');rows=[]
def edit(path,ids,fn):
 p=Path(path);before=p.read_text();after=fn(before);assert before!=after;rows.append(dict(path=path,before=before,after=after,findingIds=ids));p.write_text(after)
edit('dev_docs/agents/demos/direct_lighting/example.kt',['8af5f374ac6f-01'],lambda s:s.replace('lab = DirectLightingDemo(renderer, 1280, 720)','// Keep this run\'s study in callbacks and cleanup, even when lab is replaced.\nval ownedLab = DirectLightingDemo(renderer, 1280, 720)\nlab = ownedLab').replace('lab.','ownedLab.')+' .end { ownedLab.close() }\n')
edit('dev_docs/agents/demos/learned_from_module/example.kt',['92cb333e3cef-01'],lambda s:s.replace('lab = ShaderLearningView(renderer,source,setSourceParameter=setTime)','// Publish for inspection; this run retains the exact view it must retire.\nval ownedLab = ShaderLearningView(renderer,source,setSourceParameter=setTime)\nlab = ownedLab').replace('lab.','ownedLab.'))
edit('public/docs/direct_lighting.md',['0ba0a3800939-01'],lambda s:s.replace('''        frame()
    }
}
```''','''        frame()
    }
}.end { study.close() }
```''',1).replace('Re-running the box replaces the study:', 'Stopping the box closes its study. Re-running the box replaces the study:'))
(h/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ['mechanical.py','verify.py']:
 s=(h.parent/'box_code_adoption_batch_21'/name).read_text().replace('adoption-21','adoption-22').replace("'a8a5d6e4f'","'5895a5b9e'");(h/name).write_text(s)
