import afield.graphics.render.lighting.*
import afield.graphics.scene.fabricated.rtxdiSettings

prop<DirectLightingDemo>(lab)
// Re-executing this box replaces the experiment at a frame boundary.
fromContextWithNameOrNull<DirectLightingDemo>("lab")?.close()
// Keep this run's study in callbacks and cleanup, even when lab is replaced.
val ownedLab = DirectLightingDemo(renderer, 1280, 720)
lab = ownedLab
var cameraControl by keyCamera(renderer, ownedLab.bundle.scene.camera)

val restir = ownedLab.bundle.rtxdiSettings()
val sdkReady =
    ownedLab.visibility.available &&
        runCatching {
            ownedLab.lighting.enableRtxdi(RtxdiProgram.load(), restir).getOrThrow()
        }
            .onFailure { println("Optional RTXDI unavailable: ${it.message}") }
            .isSuccess
var useRtxdi = sdkReady
var reference = false
var temporal = true
var neighbors = 8
var lightCount = 16
var reset = false
var source = false
var shadows = ownedLab.visibility.available
var animate = true
var budget = 16
var reconstruct = true
var weight = 1f
var power = 60f
var phase = 0.0
var diagnostic = 0
controlGroup("lighting") {
    checkbox("Original renderer", initialValue = source) { source = it }
    checkbox("Ray-query shadows", initialValue = shadows) { shadows = it }
    if (sdkReady) {
        checkbox("RTXDI", initialValue = useRtxdi) { useRtxdi = it }
        checkbox("Reference estimator", initialValue = reference) { reference = it }
        checkbox("Reconstruct lighting", initialValue = reconstruct) { reconstruct = it }
        checkbox("Temporal reuse", initialValue = temporal) { temporal = it }
        slider("Spatial neighbors", min = 0.0, max = 16.0, step = 1.0, initialValue = 8.0) { neighbors = it.toInt() }
        slider("Area lights", min = 1.0, max = 128.0, step = 1.0, initialValue = 16.0) { lightCount = it.toInt() }
        button("Reset history") { if (it) reset = true }
    }
    checkbox("Animate light", initialValue = animate) { animate = it }
    slider("Samples", min = 1.0, max = 128.0, step = 1.0, initialValue = budget.toDouble()) { budget = it.toInt() }
    slider("Effect weight", initialValue = 1.0) { weight = it.toFloat() }
    slider("Radiance", min = 0.0, max = 150.0, initialValue = 60.0) { power = it.toFloat() }
    slider("Light phase", min = 0.0, max = 6.283, initialValue = 0.0) { phase = it }
    slider("View (0: lit, 9: raw)", min = 0.0, max = if (sdkReady) 9.0 else 4.0, step = 1.0, initialValue = 0.0) {
        diagnostic = it.toInt()
    }
}
displayOpen("lighting")
println("Direct lighting ready: use the lighting controls and arrow-key camera.")
// Controls publish values; Vulkan changes happen here, between frames.
frames {
    var seconds = 0.0
    while (true) {
        restir.denoisePasses = if (reconstruct) 3 else 0
        restir.temporal = temporal
        restir.spatialSamples = neighbors
        restir.shadows = shadows
        if (reset) {
            restir.resetHistory()
            reset = false
        }
        if (sdkReady)
            restir.commitLights(
                List(lightCount) { i ->
                    val a = i * 2.0 * PI / lightCount + seconds + phase
                    IdentifiedAreaLight(
                        100 + i,
                        AreaEmitter(
                            Vector3f(
                                (cos(a) * 3.0 + sin(seconds + phase) * 1.5).toFloat(),
                                4.5f,
                                (sin(a) * 2.0).toFloat(),
                            ),
                            Vector3f(0.6f, 0f, 0f),
                            Vector3f(0f, 0f, 0.6f),
                            Vector3f(power * 3f / lightCount),
                        ),
                    )
                },
            )
        ownedLab.lighting.mode =
            if (source) DirectLighting.Mode.SOURCE
            else if (useRtxdi && sdkReady) {
                if (reference) DirectLighting.Mode.RTXDI_REFERENCE else DirectLighting.Mode.RTXDI
            } else if (shadows && ownedLab.visibility.available) DirectLighting.Mode.RAY_QUERY
            else DirectLighting.Mode.UNSHADOWED
        ownedLab.lighting.view = DirectLighting.View.entries[diagnostic]
        ownedLab.lighting.samples = budget
        ownedLab.lighting.effectWeight = weight
        ownedLab.lighting.emitter.radiance.set(power)
        ownedLab.animate(seconds + phase)
        if (animate) seconds += 1.0 / 60.0
        frame()
    }
}
    .end { ownedLab.close() }
