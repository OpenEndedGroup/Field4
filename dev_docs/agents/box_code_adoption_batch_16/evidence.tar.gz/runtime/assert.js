return (async () => {
await new Promise(r => setTimeout(r, 500));
const circle = document.querySelector('svg[viewBox="0 0 320 96"] circle');
if (!circle) throw new Error('preview missing');
const attrs = Object.fromEntries(['cx','cy','r','fill','stroke-dasharray'].map(k=>[k,circle.getAttribute(k)]));
if (Math.abs(+attrs.cx-220)>0.01 || Math.abs(+attrs.cy-64)>0.01 || Math.abs(+attrs.r-24.7)>0.01) throw new Error(JSON.stringify(attrs));
if (attrs.fill !== 'rgb(128,128,128)' || attrs['stroke-dasharray'] !== 'none') throw new Error(JSON.stringify(attrs));
if (!document.body.textContent.includes('changed live')) throw new Error('label not refreshed');
return attrs;

})();
