val scene =
    Img.generateRGB(180, 132) { x, y ->
        var r = 0.10f + 0.30f * (x / 179f)
        var g = 0.12f + 0.22f * (y / 131f)
        var b = 0.34f - 0.20f * (x / 179f)
        if (x in 24..68 && y in 20..56) {
            r = 0.94f
            g = 0.86f
            b = 0.42f
        }
        if (hypot(x - 128.0, y - 46.0) <= 22.0) {
            r = 0.30f
            g = 0.80f
            b = 0.92f
        }
        if (x in 112..113 || y in 104..105) {
            r = 0.98f
            g = 0.98f
            b = 0.98f
        }
        Triple(r, g, b)
    }
val gray = scene.luma()

// Four stages of one pipeline, four different value types, one `.h` each. showRow keeps
// them in a single output channel instead of four tall ones.
val panels = [
    scene.h, // direct mode, 3 channels
    gray.sobel().dx.h, // signed -> coolwarm diverging
    gray.gaussianPyramid(4).h, // rungs at true relative scale
    gray.harrisCorners(minDistance = 6, maxCount = 20).h, // scatter, strength-coded
]
showRow("panels", panels)

println("imaging visualizers ready")
