val scene = Img.generateRGB(240, 180) { x, y -> /* … */ }
scene.h
