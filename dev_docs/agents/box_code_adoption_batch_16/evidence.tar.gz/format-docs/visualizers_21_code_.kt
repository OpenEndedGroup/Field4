data class Particle(val position: Vec3, val age: Double, val tag: String)
class Node(val name: String) {
    var next: Node? = null
}

val ring = Node("a")
ring.next = Node("b").also { it.next = ring }

val scene = linkedMapOf(
    "particle" to Particle(Vec3(1f, 2f, 0.5f), 0.25, "spark"),
    "weights" to doubleArrayOf(0.1, 0.4, 0.5),
    "many" to List(5000) { it * it },
    "ring" to ring,
)
tree("scene", scene)
