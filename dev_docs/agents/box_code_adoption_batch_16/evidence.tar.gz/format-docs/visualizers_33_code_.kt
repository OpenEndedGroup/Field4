val sampleRate = 8_000
val seconds = 5.0
val recording =
    FloatArray((sampleRate * seconds).toInt()) { i ->
        val t = i / sampleRate.toDouble()
        val chirp = sin(2.0 * PI * (105.0 * t + 72.0 * t * t))
        val low = 0.34 * sin(2.0 * PI * 47.0 * t)
        val pulse = if ((t * 2.0).toInt() % 2 == 0) 0.16 * exp(-8.0 * (t % 0.5)) else 0.0
        (0.54 * chirp + low + pulse).toFloat()
    }

displayAudioSamples(
    samples = recording,
    sampleRate = sampleRate,
    options = AudioVisualizerOptions(
        width = 1050,
        waveformHeight = 150,
        showPlayhead = true,
        initialStartSeconds = 0.8,
        initialDurationSeconds = 2.7,
        initialPositionSeconds = 1.45,
    ),
    label = "five-second synthetic recording",
)

println("recorded audio visualizer ready")
