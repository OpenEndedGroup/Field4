client
    .analysisPreview(result.id)
    .thenCombineAsync(
        client.spectralEmbeddingFrames(
            result,
            durationSeconds = 10.0,
            poolMillis = 200.0,
            hopMillis = 40.0,
        ),
    ) { preview, frames ->
        [
                SpectralEmbeddingDistance.MEL_WASSERSTEIN,
                SpectralEmbeddingDistance.LOG_MEL_COSINE,
                SpectralEmbeddingDistance.MFCC_EUCLIDEAN,
            ]
            .map { distance ->
                preview.withSpectralProjection(frames.tsne(distance = distance, dimensions = 4))
            }
    }
    .thenAccept { previews ->
        display("spaces", spectralEmbeddingPreviewDashboardHtml(previews, syncGroup = "recording"))
    }
