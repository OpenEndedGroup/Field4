val m = __m("some-marker")
m.histogram(0.42)
