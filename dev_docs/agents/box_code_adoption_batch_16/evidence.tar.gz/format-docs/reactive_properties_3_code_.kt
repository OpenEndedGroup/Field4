val width = (gain * 300).toInt()
display("main", "<div style='width:${width}px;height:14px;background:#4a90d9'></div><p>gain ${"%.2f".format(gain)}</p>")
