val tiny = linkedMapOf(
    "tempo" to 122,
    "mode" to "mixolydian",
    "active" to true,
    "notes" to ["C", "E", "G", "Bb"],
)

val big =
    (0 until 18).associate { row ->
        "row-$row" to
            (0 until 10).associate { col ->
                "c$col" to row * col
            }
    }

display(
    "hello",
    "<div style=\"padding:18px;background:#101820;color:#f2aa4c;border:1px solid #2d4a5d\">" +
        "<b>display(...)</b> can show any HTML you like." +
        "</div>",
)
display("pretty", tiny.h)
display("heavy", big.h2)

println("display helpers ready")
