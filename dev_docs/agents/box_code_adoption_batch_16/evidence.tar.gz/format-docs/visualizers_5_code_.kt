val spiral = FLine()
val steps = 140
spiral.breakNext()
for (i in 0..steps) {
    val t = i.toDouble() / steps
    val a = t * 5.0 * 2.0 * Math.PI
    val r = 8.0 + t * 60.0
    val x = 80.0 + Math.cos(a) * r
    val y = 80.0 + Math.sin(a) * r
    spiral.lineTo(x, y)
}
spiral.h
