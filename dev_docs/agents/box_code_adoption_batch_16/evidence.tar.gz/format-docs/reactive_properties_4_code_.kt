propUp<Double>(scale)
scale = 2.5
prop<Int>(runs, 0)
runs += 1
