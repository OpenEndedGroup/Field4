linkedMapOf(
        "scale (mat3)" to Matrix3f().set(2f, 0f, 0f, 0f, 3f, 0f, 0f, 0f, 1f),
        "translate (mat4)" to
            Matrix4f().identity().apply {
                set(3, 0, 5f)
                set(3, 1, -2f)
                set(3, 2, 1f)
            },
        "spin (quat)" to Quaternionf().rotateY(0.6f),
    )
    .h
