val client = FieldAudioClient()
client
    .assetByFilename("*Nancy*")
    .thenCompose { asset ->
        val region = AssetRegion(asset.id, startSeconds = 0.0, durationSeconds = 30.0)
        client.submit(multiScaleBeatAnalysis(region, scalesSeconds = [2.0, 4.0, 8.0, 16.0]))
    }
    .thenCompose(client::awaitAnalysis)
    .thenAccept { result ->
        display("analysis", analysisVisualizationHtml(result))
    }
