controlGroup("controls") {
    slider("gain", min = 0.0, max = 1.0, step = 0.01, initialValue = 0.35) {}
    vec2Control("orbit", initialValue = Vector2f(0.35f, -0.2f)) {}
    checkbox("armed", initialValue = true) {}
    stringInput("name", initialValue = "Field") {}
    colorPicker("accent", initialValue = Vector4f(0.95f, 0.45f, 0.15f, 0.85f)) {}
}

println("controls ready")
