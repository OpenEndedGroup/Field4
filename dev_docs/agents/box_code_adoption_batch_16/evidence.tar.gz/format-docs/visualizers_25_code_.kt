displayOpen("preview")
displayClear("preview")
displayClearAll()
