logs("logs") { channel("demo") }

val log = afield.ai.diagnostics.LogDispatcher
log.log(
    afield.ai.diagnostics.LogEvent(
        "demo",
        "starting a job",
        blockId = "job",
        boundary = afield.ai.diagnostics.BlockBoundary.BEGIN,
    ),
)
for (i in 1..3) log.log(afield.ai.diagnostics.LogEvent("demo", "step $i of 3", blockId = "job"))
log.log(
    afield.ai.diagnostics.LogEvent("demo", "done", blockId = "job", boundary = afield.ai.diagnostics.BlockBoundary.END),
)
