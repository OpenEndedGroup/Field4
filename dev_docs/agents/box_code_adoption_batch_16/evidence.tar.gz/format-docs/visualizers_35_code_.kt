val representation: AssetRepresentation = candidate.proxyRepresentation!!
display(
    "audio",
    representation.audioVisualizerHtml(
        options = AudioVisualizerOptions(showPlayhead = true),
    ),
)
