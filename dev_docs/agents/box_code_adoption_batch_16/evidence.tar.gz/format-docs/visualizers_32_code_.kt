var p = Vector2f(0f, 0f)
lateinit var pad: GestureHandle

// A figure eight to start from; shift-drag on the pad to record your own.
val eight = 64 { i ->
    val a = i / 63.0 * 2 * Math.PI
    i / 63.0 * 2.0 to Vector2f((0.8 * Math.sin(a)).toFloat(), (0.6 * Math.sin(2 * a)).toFloat())
}

controlGroup("gesture") {
    pad = gesture("move", initialTake = eight) { p = it }
}

val start = System.nanoTime()
loop {
    val t = (System.nanoTime() - start) / 1e9
    pad.at(t)?.let { p = it }
    pad.playhead(t)
}
