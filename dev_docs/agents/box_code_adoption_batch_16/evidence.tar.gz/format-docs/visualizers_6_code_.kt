with(Functions) {
    val fn = sin(10) over (0.0..3.0)
    fn.h
}
