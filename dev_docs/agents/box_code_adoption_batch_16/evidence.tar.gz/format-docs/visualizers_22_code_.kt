val age = scene.graphPath("particle/age")?.get()
