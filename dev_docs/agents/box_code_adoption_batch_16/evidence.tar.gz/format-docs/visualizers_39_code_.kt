val sync = "field-recording-speech"
display(
    "source",
    audio.audioVisualizerHtml(
        options = AudioVisualizerOptions(syncGroup = sync),
    ),
)

client.submit(wavlmBasePlusEmbeddingAnalysis(region, layer = 6)).thenCompose(client::awaitAnalysis).thenAccept { result
    ->
    display("WavLM", speechEmbeddingVisualizationHtml(result, syncGroup = sync))
}
