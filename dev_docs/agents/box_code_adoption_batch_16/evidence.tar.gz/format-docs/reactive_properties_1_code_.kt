prop<Int>(runs, 0)
runs += 1
display("main", "<p>bpm $bpm: a beat every ${60000 / bpm} ms (run $runs)</p>")
