(scene.luma().sobelMagnitude() * 25f).h
