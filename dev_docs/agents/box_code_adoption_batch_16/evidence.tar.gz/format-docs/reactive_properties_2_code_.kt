propDown<Double>(gain)
syncToProperty("gain", 0.5, min = 0.0, max = 1.0)
