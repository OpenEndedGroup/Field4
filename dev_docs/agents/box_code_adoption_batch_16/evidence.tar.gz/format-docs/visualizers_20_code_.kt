val scene = linkedMapOf(
    "camera" to
        linkedMapOf(
            "x" to 10,
            "y" to 20,
            "zoom" to 1.5,
            "active" to true,
        ),
    "layers" to
        [
            linkedMapOf(
                "name" to "dots",
                "visible" to true,
                "points" to [2, 4, 8, 16],
            ),
            linkedMapOf(
                "name" to "lines",
                "visible" to false,
                "style" to linkedMapOf("width" to 2, "color" to "#f2aa4c"),
            ),
        ],
    "palette" to
        linkedMapOf(
            "background" to "#101820",
            "accent" to "#f2aa4c",
        ),
)

tree("outline", scene)
column("columns", scene)

println("inspector panes ready")
