var wind = Vector2f(-0.45f, 0.30f)
var bloom = 0.62
var trails = true
var label = "wake field"
var tint = Vector4f(0.25f, 0.75f, 1.0f, 0.9f)

// Refresh after each edit. TINT controls monochrome luminance and alpha.
fun updatePreview() {
    val gray = (255 * (0.2126 * tint.x + 0.7152 * tint.y + 0.0722 * tint.z)).toInt().coerceIn(0, 255)
    val x = 160 + wind.x * 120
    val y = 48 - wind.y * 32
    val radius = 6 + bloom * 22
    val dash = if (trails) "4 3" else "none"
    markdown(
        "preview",
        """
        #### ${label.md}

        <svg width="320" height="96" viewBox="0 0 320 96" style="background:#080808;border:1px solid #555">
          <circle cx="$x" cy="$y" r="$radius" fill="rgb($gray,$gray,$gray)" fill-opacity="${tint.w}"
                  stroke="#ddd" stroke-dasharray="$dash"/>
        </svg>

        wind=(${wind.x}, ${wind.y}) · bloom=$bloom · trails=$trails
        tint=(${tint.x}, ${tint.y}, ${tint.z}, ${tint.w})
        """,
        width = 620,
    )
}

controlGroup("surface") {
    slider("bloom", min = 0.0, max = 1.0, step = 0.01, initialValue = bloom) {
        bloom = it
        updatePreview()
    }
    vec2Control("wind", initialValue = wind, xRange = -1.0 to 1.0, yRange = -1.0 to 1.0, step = 0.05) {
        wind = it
        updatePreview()
    }
    checkbox("trails", initialValue = trails) {
        trails = it
        updatePreview()
    }
    stringInput("label", initialValue = label) {
        label = it
        updatePreview()
    }
    colorPicker("tint", initialValue = tint) {
        tint = it
        updatePreview()
    }
}
// Cached controls may invoke callbacks during setup; draw once more after all are restored.
updatePreview()

println("mixed controls ready")
