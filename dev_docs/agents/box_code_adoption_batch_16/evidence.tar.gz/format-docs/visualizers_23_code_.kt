val frame = "document.querySelector('iframe.field-inspector')"
ui.waitForSelector("iframe.field-inspector", 8000.0)
ui.eval("document.body.classList.add('mode-no-editor'); return true")
ui.pause(600)
fun tree(js: String) = ui.eval("return $frame.contentWindow.$js").toString()
check("LinkedHashMap" in tree("inspectorTreeState().root"))
val at =
    ui.eval(
            """
    const f = $frame, r = f.getBoundingClientRect();
    const i = f.contentDocument.getElementById('filter').getBoundingClientRect();
    return [r.left + i.left + i.width / 2, r.top + i.top + i.height / 2].join(',');
""",
        )
        .toString()
        .trim('"')
        .split(',')
        .map { it.toDouble() }
ui.moveMouse(at[0], at[1], 6)
ui.clickAt(at[0], at[1])
ui.typeSlowly("**/name", 220)
ui.pause(500)
check("groups/1/layers/1/name" in tree("inspectorTreeState().query")) {
    tree("JSON.stringify(inspectorTreeState())") + " at " + at
}
for (i in 1..5) {
    ui.press("ArrowDown")
    ui.pause(200)
}
ui.press("Enter")
ui.pause(900)
check(tree("inspectorTreeState().selected") == "\"groups/1/layers/1/name\"") { tree("inspectorTreeState().selected") }
ui.pause(300)
