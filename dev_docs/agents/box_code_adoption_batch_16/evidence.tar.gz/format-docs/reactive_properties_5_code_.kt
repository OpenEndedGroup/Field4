propUp<Double>(scale)
prop<Int>(runs, 0)
val s = scale
val ran = named("Scale").runs
display("main", "<p>scale = $s (Scale has run $ran time)</p>")
