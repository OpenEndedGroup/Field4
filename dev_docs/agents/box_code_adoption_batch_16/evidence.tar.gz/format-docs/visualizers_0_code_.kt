value.h // the .h extension: value -> pretty HTML
display("inspect", value.h) // drop that HTML into a named output channel
box.viz(value = value) // convenience: visualize into the box's "viz" channel
