val filtered = __m("cutoff").history(rawCutoff)
