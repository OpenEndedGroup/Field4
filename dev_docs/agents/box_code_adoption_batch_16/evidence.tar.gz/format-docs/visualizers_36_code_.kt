val group = "nancy-analysis"

display(
    "source",
    representation.audioVisualizerHtml(
        options = AudioVisualizerOptions(
            initialStartSeconds = 18.0,
            initialDurationSeconds = 24.0,
            initialPositionSeconds = 18.0,
            syncGroup = group,
        ),
    ),
)

// Analysis-local 0 s corresponds to source 18 s.
display(
    "analysis",
    analysisDashboardHtml(
        [beats, mono, poly],
        syncGroup = group,
        timeOffsetSeconds = 18.0,
    ),
)
