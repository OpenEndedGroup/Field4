scene.luma().sobel().dx.h
