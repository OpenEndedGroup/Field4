ui.eval("window.toggleDependencyLayer(); localStorage.setItem('afield.dependencyLayer', '0'); return true")
for (i in 0 until 40) {
    ui.pause(250)
    if ((ui.eval("return window.dependencyLayerState().drawnPaths").toString().toDoubleOrNull() ?: 0.0) >= 3.0) break
}
ui.pause(500)
