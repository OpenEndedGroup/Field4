val sync = "recording-to-score"
display(
    "source",
    audio.audioVisualizerHtml(
        options = AudioVisualizerOptions(syncGroup = sync),
    ),
)
display(
    "score",
    analysisVisualizationHtml(
        transcription,
        syncGroup = sync,
    ),
)
