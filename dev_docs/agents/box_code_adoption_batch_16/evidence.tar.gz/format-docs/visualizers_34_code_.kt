// A browser-accessible recording. Add waveformUrl for range-aware server summaries.
displayAudio(
    AudioVisualizerSource(
        audioUrl = "/recordings/long-take.wav",
        waveformUrl = "/analysis/long-take/waveform",
        durationSeconds = 183.4,
        label = "long take",
    ),
)

// Generated or transformed mono samples; encoded as a self-contained PCM16 WAV.
displayAudioSamples(samples, sampleRate = 48_000, label = "synthesis result")

// Short existing recordings. Long files should use URLs instead of inflating box output.
displayAudioBytes(mp3Bytes, mediaType = "audio/mpeg", label = "short field recording")
