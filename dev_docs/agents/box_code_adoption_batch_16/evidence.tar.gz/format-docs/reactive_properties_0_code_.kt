propDown<Int>(bpm) = 120
